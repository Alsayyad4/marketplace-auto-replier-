/* =====================================================================
 * SubSell Marketplace Auto-Reply — content script (SIMPLE mode)
 * ---------------------------------------------------------------------
 * Takes over the Messenger Marketplace inbox and does ONE thing:
 *
 *   1. Go through every conversation in the list, one at a time.
 *   2. Open it and read the LAST message.
 *   3. If that last message is from the BUYER, ask Claude for a reply
 *      and type + send it.
 *   4. Move on. Repeat.
 *
 * One reading method: the message column is bounded by the composer box;
 * your messages sit on the right, the buyer's on the left. No vision, no
 * learned rules — on purpose. Scheduling IS unread-aware: chats showing as
 * unread (waiting buyer) jump every cooldown; idle chats rotate fairly.
 * ===================================================================== */
(() => {
  "use strict";

  // Each injected instance stamps a unique generation on the shared isolated-world
  // window. When the background re-injects after an extension update, the newest
  // instance wins and any older/orphaned one self-terminates (see scan()).
  const MY_GEN = Date.now() + ":" + Math.random();
  try { window.__subsellGen = MY_GEN; } catch (e) { /* ignore */ }
  let scanTimer = null;

  const THREAD_SELECTOR = 'a[href*="/t/"]'; // messenger.com & facebook.com thread links
  const SCAN_MS = 8000; // how often we look for the next chat to handle
  const COOLDOWN_MS = 90 * 1000; // wait before re-checking a chat we just acted on
  const IDLE_COOLDOWN_MS = 10 * 60 * 1000; // longer wait for chats where WE spoke last

  // (v0.21.43) THROTTLE-IMMUNE SLEEP. The operator's Chrome windows run MINIMIZED.
  // After a page has been hidden for 5 min, Chrome's intensive wake-up throttling
  // fires chained timers at most ONCE PER MINUTE — so every 1-s poll in this
  // script became a 60-s wait: uploads "took" ten minutes, Enter landed
  // mid-upload, replies ran late. Message delivery is NOT throttled, so on a
  // hidden page every wait ≥ 250 ms is timed by the background service worker
  // (chunks ≤ 20 s, under its 30-s idle timer); any failure falls back to a
  // plain setTimeout. Visible pages keep the plain timer.
  const rawSleep = (ms) => new Promise((r) => setTimeout(r, ms));
  async function sleep(ms) {
    ms = Math.max(0, Number(ms) || 0);
    if (ms < 50 || document.visibilityState !== "hidden") return rawSleep(ms);
    const end = Date.now() + ms;
    for (;;) {
      const left = end - Date.now();
      if (left <= 0) return;
      const chunk = Math.min(left, 20000);
      let ok = false;
      try {
        ok = await new Promise((res) => {
          try {
            chrome.runtime.sendMessage({ type: "SLEEP", ms: chunk }, (r) => { void chrome.runtime.lastError; res(!!(r && r.ok)); });
          } catch (e) { res(false); }
        });
      } catch (e) { ok = false; }
      if (!ok) await rawSleep(Math.min(left, 20000)); // background unavailable (reload/update) — plain timer
    }
  }
  const rand = (a, b) => a + Math.random() * (b - a);
  // (v0.21.71) TYPING PACE: a person needs time to type a reply, and that time
  // grows with its length. Adds min(cap, chars / speed) to the configured reply
  // delay, speed drawn from the Typing WPM range (settings wpmMin..wpmMax, ~5
  // chars per word). Pure arithmetic on an existing sleep — the send itself is
  // untouched. 0 = off. store/smoke-memory.js.
  function typingPaceMs(text, settings) {
    const cap = Math.max(0, Number(settings && settings.typingPaceMaxSec) || 0) * 1000;
    if (!cap) return 0;
    const lo = Math.max(10, Number(settings.wpmMin) || 38);
    const hi = Math.max(lo, Number(settings.wpmMax) || 78);
    const cps = (rand(lo, hi) * 5) / 60;
    const n = String(text || "").length;
    return Math.min(cap, Math.round((n / cps) * 1000));
  }
  const log = (...a) => console.log("[SubSell]", ...a);
  const safe = (fn, fb) => {
    try {
      return fn();
    } catch (e) {
      return fb;
    }
  };
  const trunc = (s, n) => (s == null ? null : String(s).length > n ? String(s).slice(0, n) : String(s));

  let busy = false;
  // Watchdog: when `busy` was set (0 = idle). If a cycle ever hangs (a DOM wait that
  // never settles, a dead message port, …) the next tick force-resets after
  // BUSY_MAX_MS instead of freezing the bot until a manual page reload.
  let busySince = 0;
  const BUSY_MAX_MS = 9 * 60 * 1000; // > max legit cycle (delay+jitter+typing+a fully streamed 3-clip set)
  let pausedForUpdate = 0; // set by PAUSE_SCANS: an update is on disk, stop starting new chats
  let pendingReply = {}; // threadId -> {buyerMessage, transcript, text, at} — billed but undelivered replies (abort recovery). In-memory only: a lost memo just falls back to a normal call.
  let cooldowns = {}; // threadId -> timestamp we may re-check it (persisted, shared across tabs)
  let lastOpened = {}; // threadId -> when THIS instance last opened it (unread re-open floor)
  let openFails = {}; // sidebar threadId -> {n, at}: consecutive failed opens (quarantine at 3; strikes decay after 2h)
  // Strikes older than 2h are stale (a bad-lag morning must not combine with one
  // later hiccup into a 6h park on a real buyer). In-memory by design.
  const openFailCount = (tid) => {
    const e = openFails[tid];
    if (!e) return 0;
    if (Date.now() - (e.at || 0) > 2 * 3600 * 1000) { delete openFails[tid]; return 0; }
    return e.n || 0;
  };
  // sidebar threadId -> the ADOPTED canonical id FB redirected it to. Group-style
  // threads open under a different /t/ id than their sidebar row; per-chat state
  // written under the adopted id (replyCounts, videoAttempts) is invisible to
  // sidebar-keyed lookups without this bridge. In-memory: repopulated on the
  // first visit after a reload, which is soon enough for the gates that use it.
  const adoptedAlias = {};
  // threadId -> suppress-until timestamp: chats whose OPEN CHAT read idle three
  // times in a row while the sidebar nudge kept claiming "waiting" (FB's
  // "X is waiting for your response" row can stay lit for hours after the chat
  // is actually resolved). Without this, such a chat re-entered the never-miss
  // ledger every scan and burned a lane-0 visit every few minutes all day
  // (a diagnostic showed one chat churning like that for 9.5 hours).
  const waitSuppress = {};
  // NEVER-MISS LEDGER: threadId -> when we FIRST saw this chat waiting for a reply.
  // Re-verified every scan; an entry is cleared ONLY when the chat is actually
  // resolved (replied / handed to human / cap-stop / turned out not waiting).
  // Persisted so reloads can't forget anyone. Chats waiting past OVERDUE_MS jump
  // to the FRONT of the queue (oldest first) — the "make sure everyone is replied".
  let waitingSince = {};
  let suspiciousReads = {}; // threadId -> consecutive sidebar-says-buyer/chat-says-idle reads
  // VIDEO-PENDING QUEUE: threadId -> when its video set was deferred (busy queue).
  // Persisted. Serviced by its own picker lane, so a deferred set is GUARANTEED to
  // be delivered minutes later — deferral is a postponement, never a cancellation.
  let videoPending = {};
  // One-click backlog catch-up (per machine): when armed, replied-to chats that
  // have NO confirmed video are re-queued for a video visit, delivered through the
  // existing aged-video lane and gated by the same chatAlreadyHasOurVideo() guard
  // that prevents duplicates. Persisted so it survives reloads; self-disarms.
  let videoCatchUp = { armed: false, at: 0 };
  let catchUpDry = 0;
  // (v0.21.47) EVIDENCE-BASED DELIVERY — per-machine attach health: consecutive
  // sets in which NO clip could be confirmed staged (no tile, and Messenger's own
  // send control never left its empty-composer state). Drives reply-first mode,
  // attach-channel rotation and the automatic video doctor. Persisted so a
  // content-script reload keeps the picture.
  let attachMiss = { streak: 0, at: 0 };
  // (v0.21.53) POWER FLAGS ARE PER-MACHINE, LOCAL ONLY — never read from the shared
  // cloud/synced settings. v0.21.48-.50 shipped `videoForeground: true` in the
  // dashboard's own DEFAULTS, so every Save in that window wrote a `true` the
  // operator never chose into the ONE cloud row the whole fleet reads. v0.21.51
  // flipped the code default to false and that stale `true` kept winning: PC-1zysp
  // reported `foreground=on fg=60(7m)` — sixty window-focus steals in seven minutes,
  // the "desktop issue". A shared row must not be able to arm behaviour that grabs
  // the desktop, so these four now live in chrome.storage.local and are set on ONE
  // machine at a time, deliberately, while someone watches it.
  let powerFlags = {};
  const POWER_KEYS = ["videoForeground", "videoPip", "videoTrustedChannels", "videoActivateTab", "videoDropRescue", "videoActivationPulse", "videoMediaPrime"];
  const powerOn = (k) => powerFlags[k] === true;
  function refreshPowerFlags() {
    safe(() => chrome.storage.local.get(POWER_KEYS, (r) => {
      if (chrome.runtime.lastError || !r) return;
      powerFlags = r;
    }));
  }
  refreshPowerFlags();
  // (v0.21.80) THE CALM COMPUTER: tell the background when a PERSON uses this page —
  // trusted input only, never while the engine itself is pressing keys (busy), at most
  // once a minute. The background then keeps every on-screen habit (un-minimize,
  // reopen, window-to-front) away from the computer for a while.
  let humanSeenAt = 0;
  function humanSeen(ev) {
    if (!ev || !ev.isTrusted || busy) return;
    const now = Date.now();
    if (now - humanSeenAt < 60000) return;
    humanSeenAt = now;
    safe(() => chrome.runtime.sendMessage({ type: "HUMAN_SEEN", what: ev.type }, () => void chrome.runtime.lastError));
  }
  for (const t of ["pointerdown", "keydown", "wheel", "mousemove"]) document.addEventListener(t, humanSeen, { capture: true, passive: true });
  const VIDEO_BLIND_RETRIES_DEFAULT = 2; // extra native attach tries per chat when nothing could be confirmed staged (setting videoRetryMax). There is NO link fallback: the demo is a video file or nothing (v0.21.60/.66).
  let lastHandled = {}; // threadId -> the buyer message we last replied to (persisted)
  // threadId -> how many TEXT replies the bot has sent in this whole conversation.
  // This is the hard per-conversation reply cap (maxRepliesPerConvo). Counted ONLY on a
  // confirmed text send, so videos and follow-ups never inflate it. Persisted, so it
  // survives convo-switching, page reloads and content-script restarts — once a chat
  // hits the cap it stays capped even when the buyer keeps asking questions.
  let replyCounts = {};
  let tick = {}; // live status shown in the popup

  // Texts WE recently sent — a hard guard so the bot never replies to its own
  // message even if alignment detection ever slips. PERSISTED so a content-script
  // reload (common on laggy Remote Desktop) doesn't re-arm the self-reply bug.
  let recentSent = [];
  const normMsg = (s) => (s || "").toLowerCase().replace(/\s+/g, " ").trim();
  // (v0.21.71) threadId -> when a sidebar row for that chat last read "You sent a
  // video." (Facebook's own words, no layout involved). The snippet only says it
  // while our clip is the chat's LAST message; the moment the buyer writes back
  // the words are gone — and a bounded retry that then found no video "in the
  // chat" (hidden tab, no geometry) could send a second copy. The scan loop sees
  // every rendered row every 8 s, so the words are remembered here (persisted,
  // 30 days) and chatServedVideo() still knows. Positive-only evidence.
  let sidebarVideoSeen = {};
  // Hydrate persisted state at boot.
  safe(() =>
    chrome.storage.local.get(["recentSent", "cooldowns", "lastHandled", "replyCounts", "waitingSince", "videoPending", "videoCatchUp", "attachMiss", "sidebarVideoSeen"], (r) => {
      if (r && Array.isArray(r.recentSent)) recentSent = r.recentSent;
      if (r && r.sidebarVideoSeen && typeof r.sidebarVideoSeen === "object") sidebarVideoSeen = r.sidebarVideoSeen;
      if (r && r.attachMiss && typeof r.attachMiss === "object") attachMiss = r.attachMiss;
      if (r && r.cooldowns && typeof r.cooldowns === "object") cooldowns = r.cooldowns;
      if (r && r.lastHandled && typeof r.lastHandled === "object") lastHandled = r.lastHandled;
      if (r && r.replyCounts && typeof r.replyCounts === "object") replyCounts = r.replyCounts;
      if (r && r.waitingSince && typeof r.waitingSince === "object") waitingSince = r.waitingSince;
      // TTL sweep (boot): ledger entries older than 24h are unservable ghosts —
      // buried, deleted, or pre-0.21.14 phantom system rows — that no visit can
      // clear and that silently forced the overdue-buyer video deferral forever.
      // A rendered, genuinely waiting buyer is re-stamped by the next scan.
      {
        const nowB = Date.now();
        for (const k of Object.keys(waitingSince)) {
          if (typeof waitingSince[k] !== "number" || nowB - waitingSince[k] > 24 * 3600 * 1000) delete waitingSince[k];
        }
      }
      if (r && r.videoPending && typeof r.videoPending === "object") videoPending = r.videoPending;
      if (r && r.videoCatchUp && typeof r.videoCatchUp === "object") videoCatchUp = r.videoCatchUp;
      // AUTOMATIC one-time backlog catch-up (v0.21.13): the operator wants ZERO
      // manual work — every machine arms the video catch-up by itself on its first
      // boot after this update. Same engine as the popup button: only ambiguous
      // old-era marks are cleared, delivery is paced through the aged-video lane,
      // every send passes the duplicate guards, and it self-disarms when drained.
      // v0.21.17 re-arm: the 0.21.13 catch-up self-disarmed within ~48s on
      // all-dotted machines (the old enqueuer skipped every dotted row, queued 0,
      // and hit the 6-dry-scan disarm) — its one-shot flag was consumed having
      // done nothing. Fresh flag = exactly one effective run under the fixed
      // enqueuer; transactional-write semantics unchanged.
      chrome.storage.local.get(["autoCatchUp01217"], (ac) => {
        if (chrome.runtime.lastError || (ac && ac.autoCatchUp01217)) return;
        armVideoCatchUp({ autoCatchUp01217: true }).catch(() => { /* retried next boot */ });
      });
      // v0.21.26 re-arm: the operator reports "most convos without videos" — the
      // backlog accumulated under the old fragile per-clip pipeline. One fresh
      // sweep through the NEW one-message engine (a set now takes ~30s, and idle
      // machines drain lane 1.5 continuously) — same guards, zero manual work.
      chrome.storage.local.get(["autoCatchUp01226"], (ac) => {
        if (chrome.runtime.lastError || (ac && ac.autoCatchUp01226)) return;
        armVideoCatchUp({ autoCatchUp01226: true }).catch(() => { /* retried next boot */ });
      });
      // v0.21.29 ONE-SHOT UNPAUSE: the 15s attach-detection window judged good
      // pastes "failed" on slow machines — chats collected 3 strikes and sat in
      // 24h attach-pauses (a diagnostic showed 20 on one machine). The window is
      // fixed now; clear the attach-pauses once so those chats retry under the
      // fixed engine immediately instead of waiting out the day.
      chrome.storage.local.get(["autoUnpause0129", "videoAttempts"], (r) => {
        if (chrome.runtime.lastError || (r && r.autoUnpause0129)) return;
        const am = (r && r.videoAttempts) || {};
        let n = 0;
        for (const k of Object.keys(am)) {
          const e = am[k];
          if (e && e.why === "attach" && (e.fails || 0) >= 1) { if (e.blindTries) am[k] = { blindTries: e.blindTries }; else delete am[k]; n++; } // (v0.21.54) the bounded-retry count is not an attach strike
        }
        chrome.storage.local.set({ videoAttempts: am, autoUnpause0129: true }, () => void chrome.runtime.lastError);
        if (n) console.debug("[SubSell] cleared", n, "attach strikes/pauses for the fixed engine");
      });
      // v0.21.34 ONE-SHOT UNPAUSE: the old hold-then-send path struck chats whose
      // 2nd/3rd clip was rejected mid-upload; under streaming delivery each clip
      // attaches on an empty, settled tray. Clear the attach-pauses once so those
      // chats retry now instead of waiting out the day (same pattern as 0.21.29).
      chrome.storage.local.get(["autoUnpause0134", "videoAttempts"], (r) => {
        if (chrome.runtime.lastError || (r && r.autoUnpause0134)) return;
        const am = (r && r.videoAttempts) || {};
        let n = 0;
        for (const k of Object.keys(am)) {
          const e = am[k];
          if (e && e.why === "attach" && (e.fails || 0) >= 1) { if (e.blindTries) am[k] = { blindTries: e.blindTries }; else delete am[k]; n++; } // (v0.21.54) the bounded-retry count is not an attach strike
        }
        chrome.storage.local.set({ videoAttempts: am, autoUnpause0134: true }, () => void chrome.runtime.lastError);
        if (n) console.debug("[SubSell] cleared", n, "attach strikes/pauses for the streaming engine");
      });
      // v0.21.38 ONE-SHOT UNPAUSE: file-API sets whose tiles rendered late were
      // judged "nothing attached" (12-30 s windows), swept, re-pasted and struck —
      // a diagnostic showed 21 chats in 24h attach-pauses on one machine. The
      // engine now streams one clip at a time, reads the composer's own staged
      // signal and adopts late tiles; clear the pauses once so those chats retry
      // under it now (same pattern as 0.21.29 / 0.21.34).
      chrome.storage.local.get(["autoUnpause0138", "videoAttempts"], (r) => {
        if (chrome.runtime.lastError || (r && r.autoUnpause0138)) return;
        const am = (r && r.videoAttempts) || {};
        let n = 0;
        for (const k of Object.keys(am)) {
          const e = am[k];
          if (e && e.why === "attach" && (e.fails || 0) >= 1) { if (e.blindTries) am[k] = { blindTries: e.blindTries }; else delete am[k]; n++; } // (v0.21.54) the bounded-retry count is not an attach strike
        }
        chrome.storage.local.set({ videoAttempts: am, autoUnpause0138: true }, () => void chrome.runtime.lastError);
        if (n) console.debug("[SubSell] cleared", n, "attach strikes/pauses for the one-clip-in-flight engine");
      });
      // ONE-TIME MIGRATION (v0.21.4): the "Add video to listing" card false-positive
      // marked chats {done:true} WITHOUT sending since the fleet reinstall. Un-mark
      // every done-flag younger than 7 days so those chats finally get their videos.
      // Chats that truly received one are still protected by the strong DOM signals
      // (their video bubbles are visible in the chat).
      chrome.storage.local.get(["migVideoMarks0214", "videoSentThreads"], (m) => {
        if (m && m.migVideoMarks0214) return;
        const vt = (m && m.videoSentThreads) || {};
        const cutoff = Date.now() - 7 * 24 * 3600 * 1000;
        let cleared = 0;
        for (const k of Object.keys(vt)) {
          const e = vt[k];
          if (e && e.done && typeof e.at === "number" && e.at > cutoff) {
            delete vt[k];
            cleared++;
          }
        }
        chrome.storage.local.set({ videoSentThreads: vt, migVideoMarks0214: true }, () => void chrome.runtime.lastError);
        if (cleared) console.debug("[SubSell] migration: cleared", cleared, "false 'video sent' marks");
      });
      // (v0.21.47) ONE-SHOT: "phantom sent" marks. Under the .43-.46 just-send
      // verdict a set whose channel staged NOTHING was still stamped {done, sent:N}
      // (Enter pressed on an empty composer; the like button read as "sent"); the
      // 20-s ground truth then wrote unseen:1 and — by law 1 — nothing ever
      // retried. Those chats never got a video. Convert every {sent>0, unseen:1}
      // mark that was never reconciled (no recon, not DOM-seen) into a BOUNDED
      // retry: the mark is dropped, the chat carries blindTries:1 (one retry
      // already used), and the catch-up arm re-queues it through the aged lane —
      // every visit still runs chatAlreadyHasOurVideo() first, so a chat that DID
      // get its clip is re-marked, never re-sent.
      chrome.storage.local.get(["autoRetry02147", "videoSentThreads", "videoAttempts"], (m) => {
        if (chrome.runtime.lastError || (m && m.autoRetry02147)) return;
        const vt = (m && m.videoSentThreads) || {};
        const am = (m && m.videoAttempts) || {};
        let n = 0;
        for (const k of Object.keys(vt)) {
          const e = vt[k];
          if (!e || !e.done || !e.unseen || e.recon || e.via === "dom" || e.link || e.gaveUp) continue;
          if (typeof e.resumeFrom === "number") continue; // a parked tail keeps its own semantics
          delete vt[k];
          videoLocked.delete(k);
          am[k] = Object.assign({}, am[k] || {}, { blindTries: 1, why: "blind", failAt: 0 });
          n++;
        }
        chrome.storage.local.set({ videoSentThreads: vt, videoAttempts: am }, () => {
          void chrome.runtime.lastError;
          armVideoCatchUp({ autoRetry02147: true }).catch(() => { /* retried next boot */ });
        });
        if (n) console.debug("[SubSell] v0.21.47: re-opened", n, "phantom 'sent' marks (no video was visible) for a bounded retry");
      });
    })
  );
  function rememberSent(t) {
    const m = normMsg(t);
    if (!m) return;
    recentSent.push(m);
    while (recentSent.length > 60) recentSent.shift();
    safe(() => chrome.storage.local.set({ recentSent }));
  }
  function persistDedup() {
    // keep the persisted maps from growing unbounded (cap ~400 threads)
    for (const map of [cooldowns, lastHandled, replyCounts, waitingSince, sidebarVideoSeen]) {
      const keys = Object.keys(map);
      if (keys.length > 400) for (const k of keys.slice(0, keys.length - 400)) delete map[k];
    }
    // (v0.21.41) the video queue keeps its OLDEST entries — those are the
    // longest-waiting chats; the old oldest-first trim silently dropped exactly them.
    {
      const pk = Object.keys(videoPending);
      if (pk.length > 2000) for (const k of pk.slice(2000)) delete videoPending[k];
    }
    safe(() => chrome.storage.local.set({ cooldowns, lastHandled, replyCounts, waitingSince, videoPending, videoCatchUp, sidebarVideoSeen }));
  }
  function clearVideoPending(id) {
    if (id && videoPending[id] != null) {
      delete videoPending[id];
      persistDedup();
    }
  }
  // A chat is RESOLVED for its current message — take it off the never-miss ledger.
  function clearWaiting(id, sid) {
    if (id && waitingSince[id] != null) delete waitingSince[id];
    if (sid && waitingSince[sid] != null) delete waitingSince[sid];
    if (id) delete suspiciousReads[id];
    if (sid) delete suspiciousReads[sid];
  }
  function isOwnEcho(msg) {
    const m = normMsg(msg);
    if (!m) return false;
    // Length floor on the EXACT match too: recentSent is GLOBAL across chats, so a
    // buyer's short greeting ("allo", "oui", "ok", "merci") must never be muted just
    // because WE once sent the same word in some other chat — that made the bot
    // ignore buyers who opened with one word. Bubble color stays the primary
    // anti-self-reply; this echo guard is for longer, distinctive texts only.
    return recentSent.some((s) => (m.length >= 10 && s === m) || (m.length > 12 && (s.includes(m) || m.includes(s))));
  }

  // Cross-tab single-flight: if the operator has >1 Messenger tab open in the SAME
  // Chrome profile, both run their own scan loop and would otherwise grab the same
  // chat and double-reply/double-video. A short storage "lease" per threadId — with
  // last-writer-wins verification and a stale timeout — ensures only one tab acts on
  // a given thread at a time. Degrades safely: a failed acquire just skips (no spam).
  const TAB_UID = safe(
    () => (crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2)),
    String(Date.now()) + ":" + Math.random()
  );
  const LOCK_MS = 120000; // a lease older than this is considered stale (crashed tab)
  async function acquireThreadLock(id) {
    const now = Date.now();
    const locks = (await getLocal(["threadLocks"])).threadLocks || {};
    const cur = locks[id];
    if (cur && cur.tab !== TAB_UID && now - (cur.at || 0) < LOCK_MS) return false; // another tab holds a fresh lease
    locks[id] = { at: now, tab: TAB_UID };
    for (const k of Object.keys(locks)) if (now - (locks[k].at || 0) > LOCK_MS) delete locks[k]; // prune stale
    await setLocal({ threadLocks: locks });
    const after = (await getLocal(["threadLocks"])).threadLocks || {};
    return !!(after[id] && after[id].tab === TAB_UID); // confirm we actually won the race
  }
  // Re-stamp a lease WE hold so it can't go stale mid-task. A legit handle (response
  // delay + typing + videos) routinely outlives LOCK_MS; without refreshing, a second
  // window could steal the lease mid-reply and double-message the buyer.
  async function refreshThreadLock(id) {
    const locks = (await getLocal(["threadLocks"])).threadLocks || {};
    if (locks[id] && locks[id].tab === TAB_UID) {
      locks[id].at = Date.now();
      await setLocal({ threadLocks: locks });
    }
  }
  async function releaseThreadLock(id) {
    const locks = (await getLocal(["threadLocks"])).threadLocks || {};
    if (locks[id] && locks[id].tab === TAB_UID) {
      delete locks[id];
      await setLocal({ threadLocks: locks });
    }
  }

  /* ---------------- popup status ---------------- */
  function setStatus(patch) {
    tick = Object.assign(
      {
        lastScanTime: null,
        url: location.href,
        marketplaceAnchorCount: 0,
        unreadCount: 0,
        currentThread: null,
        lastAction: null,
        lastReplySent: null,
        lastError: null,
      },
      tick,
      patch,
      { lastScanTime: new Date().toISOString(), url: location.href }
    );
    safe(() => chrome.storage.local.set({ debugTick: tick }));
  }

  /* ---------------- background bridge ---------------- */
  function ask(msg) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage(msg, (resp) => {
          if (chrome.runtime.lastError) resolve({ ok: false, error: chrome.runtime.lastError.message });
          else resolve(resp || { ok: false, error: "no response" });
        });
      } catch (e) {
        resolve({ ok: false, error: e.message });
      }
    });
  }

  /* ---------------- find conversations in the list ---------------- */
  function threadId(anchor) {
    const href = safe(() => anchor.getAttribute("href"), "") || "";
    const m = href.match(/\/t\/([^/?#]+)/); // /marketplace/t/<id>, /t/<id>, …
    return m ? m[1] : href;
  }
  // Is the target conversation STILL the one open on screen? The operator may click
  // another chat while the bot is in a long wait (response delay, video delay…) —
  // sending then would post into the WRONG conversation. Every send re-checks this
  // and aborts silently if the user navigated; the chat is retried next cycle.
  function stillOnThread(id) {
    return !!id && location.href.includes(id);
  }
  function anchorName(anchor) {
    const t = safe(() => anchor.innerText || anchor.textContent || "", "");
    return t.split("\n").map((s) => s.trim()).filter(Boolean)[0] || null;
  }
  function isConversation(anchor) {
    const id = safe(() => anchor.id, "") || "";
    if (/left-sidebar-button/i.test(id)) return false; // left-rail nav button
    const label = safe(() => anchor.getAttribute("aria-label"), "") || "";
    if (/^(Chats|Requests|Marketplace|Spam|Archived)\b/i.test(label)) return false; // folder buttons
    const href = safe(() => anchor.getAttribute("href"), "") || "";
    return /\/t\/[^/?#]+/.test(href);
  }
  function conversationAnchors() {
    return safe(() => Array.from(document.querySelectorAll(THREAD_SELECTOR)).filter(isConversation), []);
  }

  // Sidebar snippet heuristic: does the row's PREVIEW look like the BUYER spoke last?
  // Catches chats the operator already opened (which clears the unread style) — like
  // "Pedro sent you a message · 1h" sitting unanswered. Only affects VISIT ORDER;
  // every reply/send guard stays in charge of what actually happens.
  function snippetSuggestsBuyerLast(a) {
    const t = safe(() => a.innerText || "", "");
    if (!t) return false;
    const lines = t.split("\n").map((s) => s.trim()).filter(Boolean);
    if (lines.length < 2) return false;
    let prev = lines.slice(1).join(" ").toLowerCase();
    // Messenger now prefixes unread rows' snippet with "Unread message:" (FR:
    // "Message non lu"). That prefix defeated the ^you:/^vous: anchors below, so
    // rows where WE spoke last ("Unread message: You: …") counted as waiting
    // buyers — immortal ghost ledger entries that monopolized lane 0 (real new
    // buyers never reached, "not replying at all") and kept overdueNow true
    // (every video force-queued). Diagnosed live from two machine reports
    // 2026-08-17. Strip the UI prefix before judging; a genuine buyer message
    // is judged identically with or without it.
    prev = prev.replace(/^(?:unread messages?|messages? non lus?)\s*[:.,]?\s*/i, "");
    // OUR last message / system & UI lines → not a waiting buyer.
    // NOTE (audit 2026-08-09): terms must survive SIDEBAR TRUNCATION — "This is an
    // automated su…" evaded the full-phrase `automated suggestion` term and made 4
    // system rows count as waiting buyers (⇒ every video deferred, phantom lane-0
    // churn). Do NOT add "waiting for your response" here — that nudge is a GENUINE
    // buyer-waiting signal; rejecting it would starve real buyers off the ledger.
    // NOTE: terms must survive SIDEBAR TRUNCATION, and the "Unread message: "
    // prefix (stripped above) eats ~16 chars of the visible width — so the reject
    // terms are shortened again ("this is an autom…" is how the row actually
    // renders on the operator's machines).
    if (/^you[:\s]|^vous\s?:|you sent|vous avez envoyé|automated suggestion|this is an autom|ceci est une sugg|suggestion automati|to help identi|pour (mieux )?identifier|you can now ra|rate each other|vous pouvez (désormais|maintenant) (vous )?évaluer|started this chat|a démarré|marketplace ·|reacted .{0,4}to your|a réagi|liked your|a aimé|left the group|a quitté le groupe|joined the group|a rejoint le groupe/i.test(prev)) return false;
    return true;
  }

  // The sidebar row's OWN attribution of the last message: "Charles: How much? · 2h"
  // → { body: "How much?", media: false }. Messenger writes the sender's name
  // itself, so this is positive "the BUYER spoke last" evidence — used to rescue
  // chats where the open-chat paint/geometry read is inconclusive (defaults to
  // "me") and a real buyer was being suppressed for hours. Returns null for our
  // own rows ("You: …"), system rows, or rows without a "Name: body" shape.
  function sidebarSnippetBody(a) {
    const t = safe(() => a.innerText || "", "");
    if (!t) return null;
    const lines = t.split("\n").map((s) => s.trim()).filter(Boolean);
    if (lines.length < 2) return null;
    let s = lines.slice(1).join(" ").replace(/^(?:unread messages?|messages? non lus?)\s*[:.,]?\s*/i, "");
    const m = s.match(/^([^:]{1,60}?):\s*(.+)$/);
    if (!m) {
      // Colon-less MEDIA rows: "Mohand sent a photo." / "Mohand a envoyé une vidéo."
      // (our own "You sent…"/"Vous avez envoyé…" rows are excluded up front).
      const mm = s.match(/^(?!you\b|vous\b|toi\b|moi\b)([^:]{1,60}?)\s+(sent|a envoyé|vous a envoyé|t'a envoyé)\b.*\b(photo|video|vidéo|attachment|pièce jointe|voice|vocal|audio|gif|sticker|autocollant)/i);
      return mm ? { body: "", media: true } : null;
    }
    if (/^(you|vous|toi|moi)$/i.test(m[1].trim())) return null;
    let body = m[2].replace(/\s*[·•]\s*\d{1,3}\s?(min|m|h|hr|j|d|sem|w)\b.*$/i, "").replace(/(\.\.\.|…)\s*$/, "").trim();
    if (!body) return null;
    const media = /\b(sent|a envoyé|vous a envoyé|t'a envoyé)\b.*\b(photo|video|vidéo|attachment|pièce jointe|voice|vocal|audio|gif|sticker|autocollant)/i.test(body);
    return { body, media };
  }

  // Does this sidebar row show as UNREAD (buyer waiting)? Two independent signals:
  // (1) Messenger's blue unread dot — a tiny, perfectly round, blue-painted element;
  // (2) bold preview text — unread rows render the name AND snippet at weight >= 600.
  // Used only to PRIORITIZE (a false positive costs one harmless visit, never a
  // duplicate reply — lastHandled/caps still gate everything downstream).
  function isUnreadAnchor(a) {
    const els = safe(() => a.querySelectorAll("span,div"), []);
    for (const el of els) {
      const r = safe(() => el.getBoundingClientRect(), null);
      if (!r || r.width < 6 || r.width > 16 || Math.abs(r.width - r.height) > 3) continue;
      const cs = safe(() => getComputedStyle(el), null);
      if (!cs) continue;
      const radius = parseFloat(cs.borderRadius) || 0;
      const m = (cs.backgroundColor || "").match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);
      if (radius >= r.width / 2 - 1 && m && +m[3] > 150 && +m[3] > +m[1] + 40) return true; // blue dot
    }
    let bold = 0;
    for (const el of safe(() => a.querySelectorAll("span"), [])) {
      if (el.children.length) continue;
      const t = safe(() => (el.textContent || "").trim(), "");
      if (!t) continue;
      const w = parseInt(safe(() => getComputedStyle(el).fontWeight, "400"), 10) || 400;
      if (w >= 600 && ++bold >= 2) return true;
    }
    return false;
  }

  /* ---------------- read the OPEN conversation ---------------- */
  function getMain() {
    return document.querySelector('[role="main"]');
  }
  function findComposer() {
    const main = getMain() || document;
    return (
      main.querySelector('[contenteditable="true"][role="textbox"]') ||
      main.querySelector('div[aria-label][contenteditable="true"]') ||
      main.querySelector('[contenteditable="true"]')
    );
  }
  async function waitForComposer(ms) {
    const t = ms || 6000;
    const start = Date.now();
    while (Date.now() - start < t) {
      const c = findComposer();
      if (c) return c;
      await sleep(300);
    }
    return null;
  }

  // Things that are NOT chat messages (menus, the listing card, system notices).
  // Multi-word phrases are matched as a prefix; SHORT single words must match EXACTLY
  // (so a real buyer message like "Sent it yet?" or "Mute point…" isn't dropped).
  const NOISE = [
    "privacy & support", "privacy and support", "customize chat", "chat members",
    "media, files and links", "media files and links", "rate seller", "more options",
    "you sent", "view profile", "view seller profile", "see listing",
  ];
  const NOISE_EXACT = new Set([
    "marketplace", "mute", "search", "block", "enter", "sent", "delivered",
    "seen", "active now", "report", "archive", "vu", "distribué", "envoyé",
  ]);
  function isNoise(text) {
    const t = text.trim().toLowerCase().replace(/\s+/g, " ");
    if (!t) return true;
    // Price / spec CARD text only — the old prefix forms ("^\$\d", "^\d+gb")
    // ate real buyer messages ("$300 possible?", "128gb still available?") and
    // those chats never got a reply.
    if (/^ca\$/.test(t)) return true; // "CA$420 · …" listing card
    if (/^\$\s?\d[\d.,\s]*$/.test(t)) return true; // bare amount ONLY — "$300 cash?" survives
    if (/^\d+\s*(go|gb|tb)\b[^a-z0-9]*$/.test(t)) return true; // "128 GB ·" card — "128gb still available?" survives
    // Time/date HEADERS only. Buyers type compact times ("18h30", "demain 14h30",
    // "dimanche 13h00") when scheduling a visit — those must NOT be noise, and
    // the old "^(mon|…)" / "^(…|hier|aujourd)" prefixes ate real FR messages
    // ("mon budget c'est 300", "hier j'ai vu l'annonce").
    if (/^\d{1,2}\s*:\s*\d{2}\s*(a\.?m\.?|p\.?m\.?)?$/.test(t)) return true; // bare "7:11 pm"
    if (/^\d{1,2}\s+h\s+\d{2}$/.test(t)) return true; // FR header "19 h 11" (buyers type "19h11")
    if (/^(mon(day)?|tue(s(day)?)?|wed(nesday)?|thu(rs(day)?)?|fri(day)?|sat(urday)?|sun(day)?)\s*,?\s+(at\s+)?\d{1,2}\s*(:\s*\d{2}\s*(a\.?m\.?|p\.?m\.?)?|h\s+\d{2})$/.test(t)) return true; // "Sat 7:11 PM" headers — "saturday works for me" survives
    if (/^(yesterday|today|hier|aujourd['’]hui)\s*(at|à)?\s*\d{1,2}\s*[:h]\s*\d{2}/.test(t)) return true; // "Today at 7:11" / "aujourd’hui à 19 h 11"
    if (/^(yesterday|today|hier|aujourd['’]hui)$/.test(t)) return true; // bare relative-date header
    if (/^to help identify/.test(t) || t.includes("meta may use technology")) return true; // Meta footer
    // Facebook system / rating prompts — NOT real buyer messages (don't reply to these).
    if (/^you can now rate/.test(t)) return true; // "You can now rate each other"
    if (/^people (may|can) rate/.test(t)) return true; // "People may rate one another based on…"
    if (/^rate /.test(t)) return true; // "Rate Zachary" / "Rate seller" button
    if (/started this chat/.test(t)) return true; // "X started this chat"
    if (/^mark as sold$/.test(t)) return true;
    if (/^view buyer/.test(t)) return true; // "View buyer" / "View buyer profile"
    if (/automated suggestion/.test(t)) return true; // "This is an automated suggestion."
    if (/waiting for your response/.test(t)) return true; // "X is waiting for your response."
    if (/add video to listing|update listing/.test(t)) return true;
    if (/allow other buyers|part of your marketplace listing/.test(t)) return true;
    if (/^message sent$/.test(t)) return true;
    if (/ sent you a (message|video|photo|gif)/.test(t)) return true; // "X sent you a message"
    // Group-membership system rows (this fleet's chats are "Group chat: …"):
    // "A contact left the group.", joins, renames, FR equivalents. NOT buyer
    // messages — replying to one sent Claude's meta-commentary to a buyer.
    if (/left the group|a quitté le groupe|joined the group|a rejoint le groupe|added .{1,60} to the group|removed .{1,60} from the group|named the group|nommé le groupe|created the group|a créé le groupe/.test(t)) return true;
    if (/^more options$|^view listing$|^see listing$/.test(t)) return true;
    // Facebook "Send a quick response" card + its preset reply buttons (seller options,
    // NOT buyer messages).
    if (/send a quick response|tap a response|réponse rapide|envoyer une réponse/.test(t)) return true;
    // NOTE: "is this (still) available" is deliberately NOT in this list — that
    // exact text is also the buyer's REAL standard opener (Facebook sends it as
    // their first message); filtering it meant those chats never got a reply.
    // The preset CHIPS with that text are excluded structurally instead (the
    // closest('[role="button"]…') check in readConversation).
    if (/^(yes, are you interested|in talks|sorry,? it'?s not available|yes,? it'?s available|when can you)/.test(t)) return true;
    // FRENCH equivalents of the system/UI lines above (operator runs FR accounts too).
    if (/suggestion automatis/.test(t)) return true; // "Ceci est une suggestion automatisée"
    if (/attend (ta|votre) réponse/.test(t)) return true; // "X attend ta/votre réponse"
    if (/vous a envoyé un|t'a envoyé un/.test(t)) return true; // "X vous a envoyé un message"
    if (/a démarré (cette|la) discussion|a lancé cette conversation/.test(t)) return true;
    if (/ajouter (une |la )?vidéo|mettre à jour l'annonce|voir l'acheteur|marquer comme vendu/.test(t)) return true;
    if (/^(lun|mar|mer|jeu|ven|sam|dim)\.?,?\s+(à\s+)?\d{1,2}\s*[:h]\s*\d{2}/.test(t)) return true; // FR day headers ("sam. 19:11") — day word + TIME required, so "mardi je peux passer" survives
    return NOISE_EXACT.has(t) || NOISE.some((n) => t === n || t.startsWith(n));
  }

  // Is this text node inside OUR (seller) message bubble? Facebook paints the
  // SELLER's bubbles blue / a blue-purple gradient and the BUYER's a neutral gray.
  // Color is far more reliable than geometry (immune to window width, the right
  // panel being open, wide bubbles, zoom, Remote-Desktop lag). We only ever use
  // this to declare "me" — it never declares "buyer" — so it can only PREVENT the
  // bot from replying to its own message, never cause a new misread.
  // TRI-STATE: true = ours (blue/gradient), false = the buyer's (neutral gray),
  // null = can't tell. "null" must NEVER be treated as "buyer" by callers — that was
  // the bug that made ambiguity default to a reply. Theme-agnostic (works in dark mode).
  function looksLikeOurBubble(el) {
    let node = el;
    for (let i = 0; i < 12 && node && node.nodeType === 1; i++) {
      const cs = safe(() => getComputedStyle(node), null);
      if (cs) {
        const radius = Math.max(
          parseFloat(cs.borderTopLeftRadius) || 0,
          parseFloat(cs.borderTopRightRadius) || 0,
          parseFloat(cs.borderBottomLeftRadius) || 0,
          parseFloat(cs.borderBottomRightRadius) || 0
        );
        if (radius >= 8) {
          // This is the rounded message bubble. Decide from its paint.
          if (/gradient/i.test(cs.backgroundImage || "")) return true; // our outgoing bubble is a gradient
          const m = (cs.backgroundColor || "").match(/rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*(?:,\s*([\d.]+))?/);
          if (!m) return null; // no solid bg → unknown
          const r = +m[1], g = +m[2], b = +m[3], a = m[4] == null ? 1 : +m[4];
          if (a < 0.2) return null; // transparent / not painted yet → unknown
          if (b > r + 20 && b > g + 12 && b >= 120) return true; // blue-dominant → us
          if (Math.abs(r - g) < 18 && Math.abs(g - b) < 22) return false; // neutral gray → the buyer's
          return null; // colored but not clearly blue → unknown
        }
      }
      node = node.parentElement;
    }
    return null; // never found a bubble → unknown
  }

  // (v0.21.73) THE CHAT'S OWN TITLE IS NOT A MESSAGE. A Marketplace chat is named
  // "Buyer · listing headline", and Messenger prints that title (and the buyer's
  // name, and the headline alone) as plain unpainted text INSIDE the thread: the
  // intro block above the first message, the sender label above a bubble in
  // group-style threads. The reader took those for lines of the conversation, so
  // the model answered the ADVERT (operator, Oct 5 2026: "answering very random ai
  // answers based on headlines of marketplace posts") — and once echoed the title
  // back to a buyer as a follow-up (the TITLE-ECHO GUARD in maybeFollowUp).
  // Judged by TEXT against the chat's known label, and only for a block that is
  // NOT a painted bubble: a buyer who really types the headline does it in a gray
  // bubble, and the sidebar's own attribution still wins (namedBySidebar).
  // Pure — store/smoke-teach.js runs it.
  function labelLike(text, name) {
    const t = normMsg(text), full = normMsg(name);
    if (!t || full.length < 3) return false;
    if (t === full) return true;
    const cut = full.indexOf("·");
    const who = cut > 0 ? full.slice(0, cut).trim() : "";
    const item = cut > 0 ? full.slice(cut + 1).trim() : "";
    // the label cut short by the header, or carrying a suffix
    if (t.length >= 8 && (full.startsWith(t) || t.startsWith(full))) return true;
    if (who && t === who) return true; // the sender label above a bubble (group-style threads)
    if (item.length >= 4 && t === item) return true; // the listing headline alone (the intro card)
    if (item.length >= 8) {
      if (t.length >= 8 && item.startsWith(t)) return true; // the headline cut short
      if (t.startsWith(item)) { // the headline plus what a card adds: "· CA$650", "- sold"
        const rest = t.slice(item.length).trim();
        if (!rest || /^[·•|(\-–—]/.test(rest) || /^(ca)?\$/.test(rest)) return true;
      }
    }
    return false;
  }
  let openLabel = { id: "", sid: "", name: "" }; // the chat handleThread opened last
  function noteOpenThread(id, sid, name) { openLabel = { id: id || "", sid: sid || "", name: name || "" }; }
  // The label of the chat that is open RIGHT NOW ("" = unknown: nothing is judged).
  function openThreadName() {
    const href = location.href;
    if (openLabel.name && ((openLabel.id && href.includes(openLabel.id)) || (openLabel.sid && href.includes(openLabel.sid)))) return openLabel.name;
    // Opened by hand, or by a path that never went through handleThread: the
    // sidebar row whose link is the open chat carries the same label.
    for (const a of conversationAnchors()) {
      const tid = threadId(a);
      if (tid && href.includes(tid)) return anchorName(a) || "";
    }
    return "";
  }

  // Returns the conversation as [{ role:"buyer"|"me", text }] oldest→newest, or [].
  function readConversation(hint) {
    const main = getMain();
    const composer = findComposer();
    if (!main || !composer) return []; // not a loaded thread → read nothing
    const c = composer.getBoundingClientRect();
    const cLeft = c.left, cRight = c.right, top = c.top; // messages live above the input

    // Pass 1 — collect candidate message text nodes (filtered) with their rects.
    const cands = [];
    const seen = new Set();
    let nodes = safe(() => Array.from(main.querySelectorAll('[role="row"] [dir="auto"]')), []);
    if (!nodes.length) nodes = safe(() => Array.from(main.querySelectorAll('[dir="auto"]')), []);
    for (const el of nodes) {
      if (safe(() => el.querySelector('[dir="auto"]'), null)) continue; // leaf text only
      if (safe(() => el.closest("a[href]"), null)) continue; // skip links (listing card, profile)
      // Skip anything inside a button/menu — Facebook's "Send a quick response" preset
      // buttons (Yes, are you interested? / Sorry, it's not available. …) and other UI
      // chips look like gray left-aligned bubbles but are NOT buyer messages.
      if (safe(() => el.closest('[role="button"],[role="menuitem"],button'), null)) continue;
      const text = safe(() => (el.innerText || el.textContent || "").trim(), "");
      if (!text || isNoise(text)) continue;
      const r = safe(() => el.getBoundingClientRect(), null);
      if (!r || r.width <= 0 || r.height <= 0) continue;
      const cx = r.left + r.width / 2;
      if (cx < cLeft - 60 || cx > cRight + 60) continue; // roughly the message column
      if (r.top >= top) continue; // above the composer only
      const key = text + "@" + Math.round(r.top);
      if (seen.has(key)) continue;
      seen.add(key);
      cands.push({ el, text, r });
    }

    // Pass 1.5 — MEDIA bubbles (photos/videos/stickers have no text node). A buyer
    // whose LAST message is just a picture used to be invisible: the chat read as
    // "we spoke last" and was parked forever — one of the "never replied" causes.
    // Avatars and inline emoji are tiny (<48px); composer upload previews use
    // blob: URLs; the listing card sits inside a link — all skipped.
    const mediaCands = [];
    const mediaEls = safe(() => Array.from(main.querySelectorAll('[role="row"] img, [role="row"] video')), []);
    for (const el of mediaEls) {
      const src = safe(() => el.getAttribute("src") || "", "");
      if (src.startsWith("blob:")) continue; // upload preview in the tray, not a message
      if (safe(() => el.closest("a[href]"), null)) continue; // listing card / profile links
      if (safe(() => el.closest('[role="button"],[role="menuitem"],button'), null)) continue;
      const r = safe(() => el.getBoundingClientRect(), null);
      if (!r || r.width < 48 || r.height < 48) continue;
      const cx = r.left + r.width / 2;
      if (cx < cLeft - 60 || cx > cRight + 60) continue;
      if (r.top >= top) continue;
      const key = "[attachment]@" + Math.round(r.top / 40); // merge poster+player of one bubble
      if (seen.has(key)) continue;
      seen.add(key);
      mediaCands.push({ el, r });
    }
    if (!cands.length && !mediaCands.length) return [];

    // The real message column = the span of the bubbles themselves. Self-calibrating,
    // so role detection no longer depends on the composer's exact width/position.
    let colLeft = Infinity, colRight = -Infinity;
    for (const k of cands) {
      if (k.r.left < colLeft) colLeft = k.r.left;
      if (k.r.right > colRight) colRight = k.r.right;
    }
    for (const k of mediaCands) {
      if (k.r.left < colLeft) colLeft = k.r.left;
      if (k.r.right > colRight) colRight = k.r.right;
    }

    // Pass 2 — classify each bubble. A message is the BUYER's ONLY with positive
    // evidence (neutral-gray bubble, or — if color is unknown — clearly hugging the
    // left). Everything ambiguous is treated as "me" so the bot can never reply to
    // its own message. This is the core anti-self-reply rule.
    // SYSTEM rows (v0.21.37): Facebook injects unpainted, CENTERED blocks into
    // the thread — "X started this chat", "X is waiting for your response", the
    // Marketplace "automated suggestion" cards, date dividers. The known ones
    // are filtered by text; the unknown ones used to fall through the
    // ambiguous⇒"me" rule and made a chat read "you spoke last" right after a
    // real buyer message ("Mohand: Bonjour · 1h" sat unanswered + suppressed).
    // A block that is unpainted AND centered AND narrower than the column is
    // never one of OUR bubbles (ours hug the right edge, and are painted) nor
    // the buyer's (they hug the left) — drop it. Every entry also records its
    // `paint` so the sidebar rescue below can tell a CONFIRMED own bubble from
    // an ambiguous one.
    const colW = Math.max(1, colRight - colLeft);
    // Centering is judged against the block's OWN [role="row"] box — Facebook's
    // rows span the whole column for every author. The candidate span above
    // collapses onto the system block itself in a first-contact chat (no own
    // bubble rendered yet), where the rightmost block could never read as
    // centered; the row box has no such blind spot. No trustworthy row box →
    // hug = null → the old rules apply unchanged.
    const rowBox = (el) => {
      const row = safe(() => el.closest('[role="row"]'), null);
      const b = row && safe(() => row.getBoundingClientRect(), null);
      return b && b.width > 100 && b.width >= colW ? b : null;
    };
    const hugOf = (r, el) => {
      const b = rowBox(el);
      if (!b) return null;
      const L = b.left, R = b.right, W = Math.max(1, R - L);
      const gap = (R - r.right) - (r.left - L); // > 0 hugs left (buyer), < 0 hugs right (ours)
      if (Math.abs(gap) <= 30 && r.width < W * 0.6) return "center";
      return gap > 30 ? "left" : gap < -30 ? "right" : null;
    };
    // Never drop the very text the sidebar attributes to the buyer (confirmed path).
    const hb = hint && !hint.media ? normMsg(hint.body || "") : "";
    const namedBySidebar = (t) => hb.length >= 2 && (normMsg(t) === hb || normMsg(t).startsWith(hb));
    const label = openThreadName(); // (v0.21.73) this chat's own title — never a message
    const out = [];
    for (const { el, text, r } of cands) {
      const ours = looksLikeOurBubble(el); // true | false | null
      const hug = hugOf(r, el);
      let role;
      if (isOwnEcho(text) || ours === true) {
        role = "me"; // our own message
      } else if (ours === false) {
        role = "buyer"; // neutral-gray bubble = the buyer's (ours are blue/gradient)
      } else if (hug === "center" && !namedBySidebar(text)) {
        continue; // unpainted centered block = Facebook system row / card, not a message
      } else {
        // color inconclusive → only call it the buyer when it CLEARLY hugs the left
        role = (colRight - r.right) - (r.left - colLeft) > 30 ? "buyer" : "me";
      }
      // (v0.21.73) An UNPAINTED block whose text is the chat's own title (or the
      // buyer's name, or the listing headline) is Messenger's furniture. It is
      // marked, not skipped, so the read an older build made can be rebuilt below.
      const title = ours === null && !!label && !namedBySidebar(text) && labelLike(text, label);
      out.push({ role, text, top: r.top, paint: ours === true || isOwnEcho(text) ? true : ours, hug, title });
    }
    // Media bubbles carry no paint to read, so the SAME rule applies: buyer only
    // with positive evidence (clearly hugging the left); centered = system card
    // (listing thumbnails in suggestion cards); ambiguous = "me".
    for (const { el, r } of mediaCands) {
      const ours = looksLikeOurBubble(el); // usually null for media
      const hug = hugOf(r, el);
      let role;
      if (ours === true) role = "me";
      else if (ours === false) role = "buyer";
      else if (hug === "center") continue;
      else role = (colRight - r.right) - (r.left - colLeft) > 30 ? "buyer" : "me";
      out.push({ role, text: "[attachment]", top: r.top, paint: ours, hug });
    }
    out.sort((a, b) => a.top - b.top);
    // (v0.21.73) The title blocks leave the conversation. The unfiltered read rides
    // along for ONE purpose: turnFromConvo rebuilds the dedupe key an older build
    // wrote for this same message (it counted the title as a line), so the update
    // can never make a chat that was already answered look new.
    if (out.some((e) => e.title)) {
      const clean = out.filter((e) => !e.title);
      clean.legacy = out;
      return clean;
    }
    return out;
  }
  // The buyer message to answer: the last bubble, and only if it's the buyer's.
  // `hint` (optional) = the sidebar's own attribution of the last message (see
  // sidebarSnippetBody): when the open-chat read is inconclusive and defaulted
  // the last bubble to "me", but its text is exactly what the sidebar attributes
  // to the BUYER by name, that bubble IS the buyer's — Messenger says so.
  function turnFromConvo(convo, hint) {
    // Our own demo clips render as trailing "me [attachment]" bubbles — never
    // let them hide a buyer message whose TEXT reply still needs to go out.
    // (Kept when the sidebar says the buyer's LATEST message is media: then the
    // last attachment is theirs and the rescue below adopts it.)
    if (!(hint && hint.media)) {
      while (
        convo.length &&
        convo[convo.length - 1].role === "me" &&
        convo[convo.length - 1].text === "[attachment]"
      )
        convo.pop();
    }
    if (!convo.length) return null;
    let last = convo[convo.length - 1];
    if (last.role !== "buyer") {
      if (!hint) return null;
      // SIDEBAR-CONFIRMED rescue (v0.21.37, generalized): Messenger's own row says
      // the buyer wrote `hint.body` last. Walk back over the trailing entries that
      // are NOT a confirmed own bubble (paint !== true — i.e. ambiguous/system-ish
      // blocks Facebook rendered after the buyer's message) looking for that
      // text; stop the moment a PAINTED own bubble is met (then we truly spoke
      // last). A match is the buyer's latest message: adopt it and drop what
      // follows it, so the transcript/dedupe key see the real conversation.
      const hb = normMsg(hint.body || "");
      const matches = (e) =>
        (e.text !== "[attachment]" && hb.length >= 2 && (normMsg(e.text) === hb || normMsg(e.text).startsWith(hb))) ||
        (!!hint.media && e.text === "[attachment]");
      let found = -1;
      for (let i = convo.length - 1, steps = 0; i >= 0 && steps < 6; i--, steps++) {
        const e = convo[i];
        // A real buyer bubble: adopt it ONLY if it is the message the sidebar names.
        // A different one means the named (newer) message isn't rendered/readable
        // yet → null, and the 2-min suspicious re-check handles the slow load.
        if (e.role === "buyer") { if (matches(e)) found = i; break; }
        if (e.paint === true) break; // confirmed OUR bubble → we spoke last, no rescue
        // A right-hugging TEXT bubble measured against its own row is ours by
        // construction (buyers hug left) even when unpainted — never step over
        // it, or our own "ok" could be adopted as the buyer's "ok".
        if (e.text !== "[attachment]" && e.hug === "right") break;
        if (matches(e)) { found = i; break; }
      }
      if (found < 0) return null;
      convo.length = found + 1; // drop the unconfirmed blocks after the buyer's message
      last = convo[found];
      last.role = "buyer"; // sidebar-confirmed: Messenger attributes this message to the buyer
    }
    // Dedupe key = what WE last said + how many buyer TEXT bubbles followed + the
    // buyer's text. lastHandled keyed on the text alone meant a buyer who repeated
    // the same words later ("ok", "?") was skipped forever. TEXT bubbles only —
    // media rendering varies between opens and must not re-fire handled messages.
    let lastMine = "";
    let trailing = 0;
    for (let i = convo.length - 1; i >= 0; i--) {
      if (convo[i].text === "[attachment]") continue;
      if (convo[i].role === "me") {
        lastMine = convo[i].text;
        break;
      }
      trailing++;
    }
    const buyerMessage =
      last.text === "[attachment]"
        ? "(the buyer sent a photo/video attachment with no text)"
        : last.text;
    const transcript = convo.slice(-12).map(convoLine).join("\n");
    const dedupeKey = lastMine + "\u0001" + trailing + "\u0001" + last.text;
    // (v0.21.73) The key an older build wrote for this same message: it read the
    // chat's title block as a line (ours, or one more of the buyer's), so its
    // "what we last said" / "how many buyer bubbles since" differ from the key
    // above. handleThread accepts either — the update never re-answers a chat.
    let legacyKey = null;
    if (convo.legacy) {
      const all = convo.legacy;
      const end = all.indexOf(last);
      if (end >= 0) {
        let lm = "", tr = 0;
        for (let i = end; i >= 0; i--) {
          if (all[i].text === "[attachment]") continue;
          if (all[i].role === "me") { lm = all[i].text; break; }
          tr++;
        }
        const k = lm + "\u0001" + tr + "\u0001" + last.text;
        if (k !== dedupeKey) legacyKey = k;
      }
    }
    return {
      buyerMessage,
      transcript,
      legacyKey,
      // (v0.21.71) a wider read for the thread memory only (the model still gets the
      // 12 lines above): the memory must see an older reply that scrolled out of
      // those 12, or it could take a repeated "ok" for one already answered.
      memTranscript: convo.slice(-40).map(convoLine).join("\n"),
      dedupeKey,
    };
  }
  // One bubble = one line. A bubble's innerText can hold newlines; unflattened, a
  // buyer bubble "Salut\nYou: …" would read as a line of OURS to everything that
  // parses these transcripts (the memory line, the answered check).
  const convoLine = (m) => (m.role === "buyer" ? "Buyer: " : "You: ") + String(m.text || "").replace(/\s*\n\s*/g, " ");
  function buyerSpokeLast() {
    return turnFromConvo(readConversation(), null);
  }
  function buyerSpokeLastConfirmed(hint) {
    return turnFromConvo(readConversation(hint), hint);
  }
  // Transcript regardless of who spoke last (used for smart follow-ups on quiet chats).
  // `n` (v0.21.71) = how many bubbles; the memory reads 40, the model keeps 12.
  function fullTranscript(n) {
    const convo = readConversation();
    if (!convo.length) return null;
    return convo.slice(-(n || 12)).map(convoLine).join("\n");
  }
  // How many times WE (the bot) spoke in a row at the very end of the chat.
  // 0 = buyer spoke last; 1 = we replied once; 2+ = we've already followed up.
  // This is the anti-spam cap: read straight from the conversation, never a counter
  // that can drift out of sync.
  function botTailCount() {
    const convo = readConversation();
    let n = 0;
    for (let i = convo.length - 1; i >= 0; i--) {
      // Media bubbles don't count: our demo clips must not eat the follow-up
      // budget (pre-media-detection behavior counted text messages only), and a
      // buyer photo (rare "buyer" media) still ends our tail.
      if (convo[i].text === "[attachment]") {
        if (convo[i].role === "me") continue;
        break;
      }
      if (convo[i].role === "me") n++;
      else break;
    }
    return n;
  }

  /* ---------------- type + send (and VERIFY it sent) ---------------- */
  function composerText(el) {
    return safe(
      () =>
        (el.innerText || el.textContent || "")
          .replace(/[\u200b-\u200d\ufeff]/g, "") // zero-width chars Lexical injects
          .replace(/[\u00a0\u2009\u202f]/g, " ") // nbsp / thin / narrow no-break
          .trim(),
      ""
    );
  }
  function insertText(el, str) {
    el.focus();
    if (!safe(() => document.execCommand("insertText", false, str), false)) {
      safe(() => {
        el.dispatchEvent(new InputEvent("beforeinput", { inputType: "insertText", data: str, bubbles: true, cancelable: true }));
        el.dispatchEvent(new InputEvent("input", { inputType: "insertText", data: str, bubbles: true }));
      });
    }
  }
  function pressEnter(el) {
    el.focus();
    // keydown only (Lexical sends on keydown); shiftKey:false so it's a SEND, not a
    // soft line-break. Don't dispatch keypress/keyup — that caused double handling.
    el.dispatchEvent(
      new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, which: 13, shiftKey: false, bubbles: true, cancelable: true })
    );
  }
  function clickSend() {
    const main = getMain() || document;
    // Only ever click a real SEND control (the label filter below). When nothing is
    // staged, Messenger shows like/mic instead of Send, so this naturally no-ops —
    // and it still works for a video-only send (empty text but an attachment staged).
    const els = safe(() => Array.from(main.querySelectorAll('[role="button"]')), []);
    for (const b of els) {
      const al = (safe(() => b.getAttribute("aria-label"), "") || "").toLowerCase();
      if (!al) continue;
      if (LIKE_CTL_RE.test(al) && !SEND_CTL_RE.test(al)) continue; // never the like/thumb control ("Send a 👍", "Envoyer un pouce…")
      if (/voice|vocal|clip|audio|micro|record|enregistr/.test(al)) continue; // mic / voice clip
      if (/like|j'?aime|sticker|autocollant|gif|emoji|r[ée]action/.test(al)) continue; // like/sticker/gif
      if (!(/\bsend\b/.test(al) || /press enter to send/.test(al) || /entr[eé]e pour envoyer/.test(al) || /envoyer un message/.test(al) || /^envoyer\b/.test(al))) continue;
      safe(() => b.click());
      return true;
    }
    return false;
  }
  async function composerEmptied(el, ms) {
    const t = ms || 2500;
    const start = Date.now();
    while (Date.now() - start < t) {
      await sleep(150);
      if (!composerText(el)) return true; // composer clears = message actually sent
    }
    return false;
  }
  async function typeAndSend(el, text) {
    const want = String(text).replace(/\s*\n\s*/g, " ").trim();
    if (!want) return false;
    // Compare ignoring invisible chars Lexical injects, so a CORRECT long/multiline
    // reply isn't falsely rejected (which used to make the bot silently never reply).
    const norm = (s) =>
      (s || "").replace(/[\u200b-\u200d\ufeff]/g, "").replace(/[\u00a0\u2009\u202f]/g, " ").replace(/\s+/g, " ").trim();
    const clear = () => {
      el.focus();
      safe(() => document.execCommand("selectAll", false, null));
      safe(() => document.execCommand("delete", false, null));
    };
    const setWhole = () => {
      // Insert the ENTIRE message in ONE operation. Typing word-by-word raced and
      // jumbled/duplicated on Messenger's editor over a laggy Remote Desktop.
      clear();
      safe(() => document.execCommand("insertText", false, want));
    };

    setWhole();
    await sleep(350);
    if (norm(composerText(el)) !== norm(want)) {
      setWhole(); // one clean retry
      await sleep(450);
    }
    // If the box still isn't EXACTLY the intended message, bail — never send a
    // duplicated/garbled message to a customer.
    if (norm(composerText(el)) !== norm(want)) {
      clear();
      setStatus({ lastError: "compose mismatch — skipped to avoid a duplicate/garbled send" });
      return false;
    }

    // Send ONCE. The box clearing = it sent. Wait generously (laggy Remote Desktop),
    // and only escalate to the Send button if the box STILL holds exactly our text —
    // so we can NEVER fire a second send / a stray sticker after it already went.
    const hrefAtSend = location.href; // (v0.21.71) the Send click below must never land in a chat the operator switched to meanwhile
    pressEnter(el);
    if (await composerEmptied(el, 5000)) return true;
    if (norm(composerText(el)) === norm(want)) {
      // (v0.21.58) …but first check the Enter did not ALREADY send it. On these
      // laggy Remote-Desktop machines Messenger can post the message while the
      // composer still shows the text for another moment; clicking Send then posts
      // it a SECOND time — the operator's "sometimes double texting". If our exact
      // message is already the last thing in the conversation, it went out: stop.
      const alreadyDelivered = () => safe(() => {
        const cv = readConversation() || [];
        const last = cv.length ? cv[cv.length - 1] : null;
        return !!(last && last.role === "me" && norm(last.text || "") === norm(want));
      }, false);
      if (alreadyDelivered()) {
        setStatus({ lastAction: "reply already delivered — skipped the duplicate send" });
        return true;
      }
      // (v0.21.71) One more beat before the click. On these machines the composer
      // can clear, or our bubble render, a moment AFTER the 5-s window closed —
      // and the click would then be the second copy. Re-read both once more, and
      // never click if the box no longer holds exactly our text.
      await sleep(2500);
      if (!composerText(el)) return true;
      if (alreadyDelivered()) {
        setStatus({ lastAction: "reply already delivered — skipped the duplicate send" });
        return true;
      }
      if (norm(composerText(el)) !== norm(want)) return !composerText(el);
      if (location.href !== hrefAtSend) return false; // another chat is open now — a click would post ITS draft; the memo replays ours next cycle
      clickSend();
      if (await composerEmptied(el, 4000)) return true;
    }
    // Ambiguous (box neither cleared nor still our exact text) — do NOT blind-resend.
    return !composerText(el);
  }

  /* ---------------- demo video (optional, ONCE per chat) ---------------- */
  function getLocal(keys) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(keys, (r) => resolve(r || {}));
      } catch (e) {
        resolve({});
      }
    });
  }
  function setLocal(obj) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.set(obj, () => resolve());
      } catch (e) {
        resolve();
      }
    });
  }
  function dataUrlToFile(dataUrl, name, type) {
    const b64 = dataUrl.slice(dataUrl.indexOf(",") + 1);
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes], name || "demo.mp4", { type: type || "video/mp4" });
  }
  /* ---- ONE-MESSAGE VIDEO SETS (v0.21.26) ----------------------------------
   * Clips are ATTACHED to the composer one after another (each verified by
   * new-element identity), then the WHOLE SET is sent with a single Enter as
   * one message. No per-clip sends, no between-clip waits, no partial-set
   * windows — the set either rides one message or records exactly which tail
   * is missing. AUDIT FIX (2026-07-29) preserved: paste into the focused
   * composer first → drag-drop → file input last, never the listing card's
   * own "Add video to listing" uploader. */
  const VIDEO_PREVIEW_SEL = 'img[src^="blob:"], [role="progressbar"], video, [aria-label*="remove" i][aria-label*="attach" i], [aria-label*="supprimer" i][aria-label*="jointe" i]';
  const VIDEO_REMOVE_SEL = '[aria-label*="remove" i][aria-label*="attach" i], [aria-label*="supprimer" i][aria-label*="jointe" i]';
  // TRAY elements = preview-ish elements NOT inside a MESSAGE row ([role="row"]
  // holds a just-sent clip's media, which must never count in attach math). A
  // row that CONTAINS the composer is the composer's own wrapper, not a message
  // row — previews inside it still count.
  function trayQuery(sel) {
    const main = getMain() || document;
    const composer = findComposer();
    const notInRow = (el) => {
      const r = safe(() => el.closest('[role="row"]'), null);
      return !r || safe(() => !!composer && r.contains(composer), false);
    };
    return safe(() => Array.from(main.querySelectorAll(sel)).filter(notInRow), []);
  }

  // (v0.21.58) THE DETECTOR WAS BLIND, AND THAT IS WHY CLIPS PILED UP.
  // An operator photo of a live composer showed SEVEN staged clips sitting in the
  // attachment strip while every counter reported 0 tiles. So the attach has been
  // working for weeks; we simply could not see it, "retried", stacked another
  // copy, and never sent any of them — and a later Enter would ship the whole pile
  // ("the tool double sending videos"). The cause is in the selectors above:
  // VIDEO_REMOVE_SEL demands an aria-label containing BOTH "remove" AND "attach"
  // (or "supprimer" AND "jointe"). Messenger's little × is labelled "Remove" /
  // "Supprimer" / "Retirer" — so it matched nothing, on any build, ever.
  // The fix stops trusting wording and DOM scope, and anchors on geometry instead:
  // the attachment strip is the band directly above the textbox, in the composer's
  // own column, and never inside a message row. Searched document-wide so a
  // portal-rendered strip is found too.
  const TRAY_BAND_UP = 280;   // how far above the textbox the strip can reach
  const REMOVE_ANY_RE = /remove|supprimer|retirer|enlever|delete|annuler|discard|×/i;
  function trayBand() {
    const c = findComposer();
    const cr = c ? safe(() => c.getBoundingClientRect(), null) : null;
    if (!cr || !cr.height) return null;
    return { c, top: cr.top - TRAY_BAND_UP, bottom: cr.top + 8, left: cr.left - 100, right: cr.right + 140 };
  }
  function inBand(el, band) {
    const r = safe(() => el.getBoundingClientRect(), null);
    if (!r || !r.width || !r.height) return false;
    if (r.bottom > band.bottom || r.top < band.top) return false;      // the strip sits just above the textbox
    if (r.right < band.left || r.left > band.right) return false;      // and in the composer's column
    const row = safe(() => el.closest('[role="row"]'), null);          // never a sent message
    if (row && !safe(() => band.c && row.contains(band.c), false)) return false;
    return true;
  }
  function trayWide(kind) {
    const band = trayBand();
    if (!band) return [];
    const out = [];
    const seen = new Set();
    const push = (el) => { if (!seen.has(el)) { seen.add(el); out.push(el); } };
    if (kind === "remove") {
      for (const b of safe(() => Array.from(document.querySelectorAll('[role="button"][aria-label], button[aria-label], [role="button"][title], button[title]')), [])) {
        const al = ((safe(() => b.getAttribute("aria-label"), "") || "") + " " + (safe(() => b.getAttribute("title"), "") || "")).trim();
        if (!REMOVE_ANY_RE.test(al)) continue;
        const r = safe(() => b.getBoundingClientRect(), null);
        if (!r || r.width > 56 || r.height > 56) continue;              // the little ×, not a toolbar button
        if (!inBand(b, band)) continue;
        push(b);
      }
      return out;
    }
    for (const el of safe(() => Array.from(document.querySelectorAll('img, video, [role="progressbar"]')), [])) {
      const r = safe(() => el.getBoundingClientRect(), null);
      if (!r) continue;
      const isBar = safe(() => el.getAttribute("role"), "") === "progressbar";
      if (!isBar && (r.width < 24 || r.height < 24 || r.width > 260 || r.height > 260)) continue; // thumbnail-sized
      if (!inBand(el, band)) continue;
      push(el);
    }
    return out;
  }
  const union = (a, b) => { const o = a.slice(); for (const x of b) if (o.indexOf(x) === -1) o.push(x); return o; };
  const trayEls = () => union(trayQuery(VIDEO_PREVIEW_SEL), trayWide("preview"));
  const trayRemoveBtns = () => union(trayQuery(VIDEO_REMOVE_SEL), trayWide("remove"));
  // Remove ONLY attachments beyond the first `expectedGood` — POSITION-based,
  // not node-identity-based: React re-creates DOM nodes freely, so a Set of
  // "known" buttons could mistake a re-rendered GOOD clip for a stray and
  // remove it. Attachments append in order, so extras are always the TAIL.
  // THREE passes with settle gaps: a paste can render its preview (and even its
  // remove button) many seconds late on throttled tabs.
  async function sweepTrayExtras(expectedGood) {
    for (let pass = 0; pass < 3; pass++) {
      const btns = trayRemoveBtns();
      for (let k = btns.length - 1; k >= expectedGood; k--) safe(() => btns[k].click());
      await sleep(pass === 2 ? 1200 : 2500);
      // One confirming re-check after a clean pass is enough (keeps the late-render
      // protection, saves ~3.7 s per call on the synthetic ladder).
      if (pass >= 1 && trayRemoveBtns().length <= expectedGood) return;
    }
  }
  // PRE-ENTER EXACTNESS (v0.21.38): the tray must hold exactly `expected` tiles
  // (the known head + the ONE clip just attached) before Enter. A surplus is a
  // late-rendered copy from an earlier attempt (PC-mnbbd: SEVEN tiles piled up,
  // one Enter would have sent them all). Attachments render in the order they
  // entered the composer's state, so an older stray sits BEFORE the clip we just
  // added: trim from the first non-known slot, keeping the newest (ours). Returns
  // true when the tray is exact, false when a surplus would not go away — the
  // caller must NOT send then.
  async function trimTraySurplus(expected) {
    for (let pass = 0; pass < 3; pass++) {
      const btns = trayRemoveBtns();
      if (btns.length <= expected) return true;
      safe(() => btns[Math.max(0, expected - 1)].click());
      await sleep(pass === 2 ? 1200 : 2000);
    }
    return trayRemoveBtns().length <= expected;
  }
  // RENDER-INDEPENDENT "something is staged" signal (v0.21.38). Messenger swaps
  // the composer bar's rightmost control the instant its state holds content:
  // empty → the like/thumb button, staged or typed → the Send button. That swap
  // is a plain React commit (no file decode, no thumbnail), so it lands even on
  // machines where the preview TILE renders 30-60 s late or not at all while the
  // window is occluded (PC-mnbbd: every strategy judged "nothing attached", then
  // all of them rendered at once). We compare the control's aria-label BEFORE
  // and AFTER a dispatch — a change means staged, in any language.
  function composerSendControl() {
    const composer = findComposer();
    if (!composer) return null;
    const cr = safe(() => composer.getBoundingClientRect(), null);
    if (!cr || !cr.height) return null;
    const main = getMain() || document;
    let best = null, bestLeft = -Infinity;
    for (const b of safe(() => Array.from(main.querySelectorAll('[role="button"][aria-label], button[aria-label]')), [])) {
      const r = safe(() => b.getBoundingClientRect(), null);
      if (!r || !r.width || !r.height) continue;
      if (r.bottom < cr.top - 8 || r.top > cr.bottom + 8) continue; // same band as the textbox
      if (r.left < cr.right - 4) continue; // to its RIGHT (never the tray's remove buttons above)
      if (r.left > bestLeft) { bestLeft = r.left; best = b; }
    }
    return best;
  }
  const sendControlLabel = () => {
    const b = composerSendControl();
    return b ? (safe(() => b.getAttribute("aria-label"), "") || "").trim().toLowerCase() : "";
  };
  // The empty-composer control is the LIKE/thumb button ("Send a like",
  // "Envoyer un j'aime", "Send a 👍"…); the staged one is Send ("Press Enter to
  // send", "Envoyer"). A baseline is accepted only when it reads like the former.
  const LIKE_CTL_RE = /like|j'?aime|pouce|thumb|^send an? \S+$|^envoyer un \S+$/i;
  const SEND_CTL_RE = /press enter|entr[eé]e pour|^send$|^envoyer$|envoyer un message/i;
  // true = the control changed since the empty-composer baseline (staged),
  // false = unchanged (nothing staged), null = signal unavailable right now.
  function stagedPerControl(baseline) {
    if (!baseline) return null;
    const now = sendControlLabel();
    if (!now) return null;
    return now !== baseline;
  }
  // Which attach channel produced the last attachVideo verdict (for the 🩺 trace),
  // and the empty-composer control label it started from (blind-send baseline).
  let lastAttachVia = "-";
  let lastAttachCtlBase = "";
  // Attach ONE clip (no send). knownCount = how many attachments are already
  // legitimately in the tray; tid = the thread this clip belongs to. Returns:
  // true (new preview verified), false (provably nothing new attached, extras
  // cleaned — safe to RE-ATTEMPT this clip later), "dirty" (unverifiable
  // leftover — treat the clip as attempted, never re-attempt), "navigated"
  // (the operator switched chats mid-attach — nothing may be trusted or sent;
  // any stray the paste created in the NEW chat's tray is best-effort removed).
  // Attachments still UPLOADING in the tray (progressbars). Some FB builds /
  // slow machines reject a new paste while an upload is running — the direct
  // cause of "clip 1-2 attach, clip 3 always fails" on those machines.
  const trayUploads = () => safe(() => trayQuery('[role="progressbar"]').length, 0);
  // BULK ATTACH (v0.21.31 — the big speed win): hand ALL clips to the composer
  // in ONE paste, exactly like a human dragging three files at once. Facebook
  // then uploads them in PARALLEL instead of one-after-another, which is the
  // difference between ~15s and ~45s for a 3-clip set — and it removes the
  // per-clip settle waits entirely. Returns the number of NEW previews verified
  // (0 = nothing landed, caller falls back to the one-by-one path), or
  // "navigated" when the operator switched chats mid-attach.
  async function attachVideosBulk(filesArr, tid, pathsArr) {
    const composer = findComposer();
    if (!composer) return 0;
    composer.focus();
    if (tid && !stillOnThread(tid)) return "navigated";
    const before = new Set(trayEls());
    const beforeBtns = new Set(trayRemoveBtns());
    // (v0.21.38) The Chrome file API no longer runs here: a multi-file set whose
    // tiles render late leaves up to N strays behind, and the per-clip fallback
    // then stacked copies on top (the PC-mnbbd pile). With the file API usable
    // the engine streams ONE clip at a time instead (attachVideo) — at most one
    // clip in flight per chat, always the next one due, so any late tile is
    // adopted or trimmed, never doubled. This synthetic multi-paste stays for
    // machines without the file API. `pathsArr` is kept for signature stability.
    void pathsArr;
    const dtAll = () => {
      const dt = new DataTransfer();
      for (const f of filesArr) dt.items.add(f);
      return dt;
    };
    const fired = safe(() => {
      const ev = new ClipboardEvent("paste", { bubbles: true, cancelable: true });
      Object.defineProperty(ev, "clipboardData", { value: dtAll() });
      composer.dispatchEvent(ev);
      return true;
    }, false);
    if (!fired) return 0;
    // Wait for ALL previews. Bounded generously — uploads run in parallel, so
    // this is one wait for the whole set instead of one per clip.
    const want = filesArr.length;
    const start = Date.now();
    let seen = 0;
    while (Date.now() - start < 45000) {
      await sleep(700);
      if (tid && !stillOnThread(tid)) {
        for (const b of trayRemoveBtns()) if (!beforeBtns.has(b)) safe(() => b.click());
        return "navigated";
      }
      seen = trayEls().filter((el) => !before.has(el)).length;
      if (seen >= want) return want;
      // FAIL FAST (v0.21.32): a live diagnostic showed Facebook's composer takes
      // ZERO files from a synthetic multi-file paste on at least some builds
      // (attach-trace "bulk:0") — and this probe then burned ~50s per set before
      // the fallback. If NOTHING has appeared within 10s, multi-paste is
      // unsupported here: bail immediately to the one-by-one path.
      if (seen === 0 && Date.now() - start > 10000) return 0;
    }
    await sleep(6000); // late-render grace — a slow machine may still be painting
    seen = trayEls().filter((el) => !before.has(el)).length;
    return Math.min(seen, want);
  }
  // Verdicts (v0.21.38): true (tile verified), "blind" (Messenger's composer
  // reports content staged — the send control flipped — but no tile rendered
  // yet; send it, never dispatch another copy), "unverified" (the browser
  // accepted the file-API set, no tile and no control signal — a late render
  // can't be ruled out, so the clip is treated as attempted: skip-forward, the
  // resume visit adopts its tile if it shows up), false / "dirty" / "navigated"
  // as before. `file` may be a LAZY loader {lazy:true, load()} — on-disk clips
  // no longer haul their base64 through the message channel unless a synthetic
  // strategy actually needs the File.
  async function attachVideo(file, knownCount, tid, diskPath, opts) {
    lastAttachVia = "-";
    lastAttachRx = "-"; // (v0.21.67) the legacy ladder has no reaction probe — never report a stale code
    lastAttachHeld = false;
    lastAttachDupOf = "";
    const composer = findComposer();
    if (composer) composer.focus();
    // "aborted" (v0.21.41) = navigated away BEFORE anything was dispatched: the
    // clip was never touched, the caller resumes AT it (not after it).
    if (tid && !stillOnThread(tid)) return "aborted";
    // (v0.21.67) THE MEDIA GATE FIRST — on a hidden page that has never played
    // media Chrome parks the clip's decode and Messenger never stages it. Probe,
    // and prime the frame when parked (see ensureMediaGate). Local
    // videoMediaPrime:false turns it off. Never blocks an attach.
    if (powerFlags.videoMediaPrime !== false) { try { await ensureMediaGate(); } catch (e) { /* never blocks an attach */ } }
    if (tid && !stillOnThread(tid)) return "aborted";
    let fileObj = file && file.lazy ? null : file;
    const ensureFile = async () => {
      if (fileObj) return fileObj;
      if (file && file.lazy) { try { fileObj = await file.load(); } catch (e) { fileObj = null; } }
      return fileObj;
    };
    // CHROME FILE API FIRST (v0.21.36) when the clip is on disk. Runs as
    // strategy 0; the synthetic strategies keep their old order/windows behind it.
    const useCdp = !!diskPath && cdpUsableNow() && !!composer && !composerText(composer);
    const firstPasteIdx = useCdp ? 1 : 0;
    // The render-independent staged signal is trustworthy only from an EMPTY,
    // draft-free composer: with a known head or typed text the control already
    // shows Send and cannot flip again.
    // …and only when the control we found IS the like/thumb button (its label
    // says so): any other button that happens to sit rightmost in the band
    // would never flip and would silently disable the signal — or worse, flip
    // for its own reasons. No recognizable like button ⇒ no signal (tile only).
    let ctlBase = knownCount === 0 && composer && !composerText(composer) ? sendControlLabel() : "";
    if (ctlBase && !(LIKE_CTL_RE.test(ctlBase) && !SEND_CTL_RE.test(ctlBase))) ctlBase = "";
    lastAttachCtlBase = ctlBase; // the send path compares against it in blind mode
    // OPTIMISTIC PIPELINING (v0.21.32): the next clip is pasted immediately,
    // WHILE the previous clip is still uploading — most FB builds accept it,
    // which makes the uploads overlap instead of running one after another
    // (this was the remaining 30-60s). Builds that reject a mid-upload paste
    // fail the first short detection window; the loop then waits the uploads
    // out and pastes AGAIN (second attempt below) with the long window — the
    // proven v0.21.29 behavior, just demoted from "always" to "fallback".
    const dtFor = (f) => {
      const dt = new DataTransfer();
      dt.items.add(f);
      return dt;
    };
    const attempts = [];
    let pasteFnRef = null; // the synthetic paste, also used as the last just-send channel
    let inputFnRef = null; // (v0.21.54) the pure-DOM file-input assignment, offered to just-send as "dom"
    let btnFnRef = null;   // (v0.21.57) Messenger's own picker, caught by the page shim
    if (useCdp) {
      const cdpFn = async () => {
        setStatus({ lastAction: "attaching video via Chrome file API…" });
        const r = await ask({ type: "CDP_SET_FILES", paths: [diskPath] });
        if (r && r.ok) return true;
        // The set command itself failed late (timeout / detach): the files MAY be
        // in — count it as dispatched (truthy) so no second copy is ever pasted;
        // the wait/send decides from there.
        if (r && r.maybeSet) { setStatus({ videoLast: "file API: set command timed out — treating the clip as handed over" }); return "maybe"; }
        if (r && r.missing) forgetDiskPaths([diskPath]); // deleted on disk — background re-downloads
        noteCdpFail(r);
        return false; // nothing reached the composer's input → synthetic strategies are safe
      };
      cdpFn.isCdp = true;
      cdpFn.via = "cdp";
      attempts.push(cdpFn);
    }
    if (composer) {
      const pasteFn = async () => {
        const f = await ensureFile();
        if (!f) return false;
        const ev = new ClipboardEvent("paste", { bubbles: true, cancelable: true });
        Object.defineProperty(ev, "clipboardData", { value: dtFor(f) });
        composer.dispatchEvent(ev);
        return true;
      };
      pasteFn.via = "paste";
      pasteFnRef = pasteFn;
      attempts.push(pasteFn); // optimistic — fired even while a previous upload runs
      if (trayUploads() > 0) attempts.push(pasteFn); // settled retry — only for the case it was written for (an upload running at ladder start)
      const dragFn = async () => {
        const f = await ensureFile();
        if (!f) return false;
        const dt = dtFor(f);
        for (const t of ["dragenter", "dragover", "drop"]) {
          const ev = new DragEvent(t, { bubbles: true, cancelable: true });
          Object.defineProperty(ev, "dataTransfer", { value: dt });
          composer.dispatchEvent(ev);
        }
        return true;
      };
      dragFn.via = "drag";
      attempts.push(dragFn);
    }
    const inputFn = async () => {
      // Last resort: a file input — but ONLY one that is not part of the listing
      // card's own uploader (the input whose surrounding text says "add video to
      // listing"/"update listing" belongs to the LISTING, not the chat).
      const f = await ensureFile();
      if (!f) return false;
      const inputs = Array.from(document.querySelectorAll('input[type="file"]')).filter((inp) => {
        const wrap = safe(() => inp.closest("div,form,section"), null);
        const t = safe(() => ((wrap && wrap.innerText) || "").toLowerCase(), "");
        return !/add (a |your )?videos? to( your| the)? listing|update( your)? listing|mettre à jour|modifier (l|votre annonce)|ajoute[rz]? (une |la |des )?vid/.test(t);
      });
      const input = inputs[inputs.length - 1]; // composer attachments render late in the DOM
      if (!input) return false;
      input.files = dtFor(f).files;
      input.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    };
    inputFn.via = "input";
    inputFnRef = inputFn; // (v0.21.54) also offered to just-send as the "dom" channel
    attempts.push(inputFn);

    // (v0.21.57) "btn" — let MESSENGER open its own picker, and catch it in the page.
    // Every other channel guesses which <input type=file> to fill. On this build
    // there is nothing to guess at until the composer's attach button is pressed,
    // which is why input/dom/drop/paste all report ok and stage nothing. Here we
    // arm a MAIN-world shim (background: pageArmFileShim) that replaces
    // HTMLInputElement.prototype.click and window.showOpenFilePicker, then click
    // Messenger's own attach control. Messenger creates its input, clicks it, and
    // the shim hands over the clip instead of opening anything — so the file lands
    // in the input Messenger is actually listening to, and NO dialog can appear,
    // because the code paths that raise one are the ones we replaced.
    // A plain .click() is enough: React's onClick does not care about isTrusted,
    // and user activation is only needed to OPEN a dialog, which we never do.
    const btnFn = async () => {
      const f = await ensureFile();
      if (!f) return false;
      const target = findAttachControl();
      if (!target) { setStatus({ videoLast: "attach button not found in the composer" }); return false; }
      let url = null;
      try {
        url = URL.createObjectURL(f);
        const armMsg = { type: "ARM_FILE_SHIM", url, name: f.name, mime: f.type, ms: 20000 };
        let armed = await ask(armMsg);
        if (armed && !armed.ok && armed.legacyWaitMs > 0) {
          // (v0.21.77) once, right after the update: the previous build's shim is still
          // winding down (its timer cannot be cancelled). Wait it out (≤ 21 s) rather
          // than hand this clip to a channel that cannot stage it on this build.
          setStatus({ lastAction: "waiting for the previous build's file shim to expire…" });
          const until = Date.now() + Math.min(armed.legacyWaitMs, 22000) + 250;
          while (Date.now() < until) { await sleep(500); if (tid && !stillOnThread(tid)) return false; }
          armed = await ask(armMsg);
        }
        if (!(armed && armed.ok)) { setStatus({ videoLast: "could not arm the page file shim: " + trunc((armed && armed.error) || "?", 60) }); return false; }
        // (v0.21.77) the previous clip's shim was still alive — before .77 it was
        // RENEWED and handed Messenger that previous clip again (the double clip /
        // missing clip of a set). Counted for the 🩺 ("[rearm=N]" on btn).
        if (armed.replaced) bumpChannelStats("btn", (e) => { e.rearm = (e.rearm || 0) + 1; e.rearmAt = Date.now(); });
        safe(() => target.el.click());
        if (target.more) {
          // compact bar: the attach item lives inside the "+" menu
          let item = null;
          for (let i = 0; i < 8 && !item; i++) { await sleep(300); item = findAttachMenuItem(); }
          if (!item) { await ask({ type: "SHIM_STATUS", disarm: true }); return false; }
          safe(() => item.click());
        }
        // Did Messenger actually reach a file input? This is the one fact that
        // separates "the build ignores us" from "we never triggered its picker".
        let st = null;
        for (let i = 0; i < 10; i++) {
          await sleep(400);
          const r = await ask({ type: "SHIM_STATUS" });
          st = (r && r.status) || null;
          if (st && st.fired > 0) break;
        }
        // (v0.21.77) Messenger clicked its input (seen) but the hand-over had not run
        // yet — it runs 60 ms after the click, later on a throttled tab: a moment more.
        if (st && !st.fired && st.seen > 0 && !st.err) {
          for (let i = 0; i < 4 && !(st && st.fired > 0); i++) {
            await sleep(400);
            const r = await ask({ type: "SHIM_STATUS" });
            st = (r && r.status) || st;
          }
        }
        if (!st || !st.fired) {
          // (v0.21.77) moving on to another channel: SPEND the shim — a late click, or a
          // hand-over still scheduled, must not put this clip in behind the next
          // channel's copy (the shim stays: still no dialog). The page answers with its
          // counters as of the spend: a hand-over that ran just before it IS this
          // channel's dispatch.
          const sp = await ask({ type: "SHIM_STATUS", spend: true });
          const st2 = sp && sp.status && typeof sp.status === "object" ? sp.status : null;
          if (st2 && st2.fired > 0) st = st2;
        }
        lastShimFired = st ? st.fired : 0;
        lastShimSeen = st ? st.seen : 0;
        if (st && st.info) {
          // (v0.21.67) which input Messenger clicked (in DOM? React-owned? accept=)
          // and whether its handler READ input.files after our change event —
          // persisted on the btn channel so a 6-h reload cannot lose it.
          lastShimInfo = st.info;
          const pk = (st.info.connected ? "inDOM" : "detached") + "/" + (st.info.react ? "react" : "native") + (st.info.filesRead != null ? "/read" + st.info.filesRead : "") + (st.info.accept ? "/accept:" + trunc(st.info.accept, 16) : "");
          bumpChannelStats("btn", (e) => { e.picker = pk; e.pickerAt = Date.now(); });
        }
        if (st && st.swallowed > 0) bumpChannelStats("btn", (e) => { e.swallowed = (e.swallowed || 0) + st.swallowed; }); // Messenger clicked its input again: no second copy went in
        // (v0.21.77) EXACT evidence: the shim records the size of the file it handed
        // over; any other size than this clip's is a wrong hand-over (🩺 "[wrongfile=N]")
        if (st && st.fired > 0 && st.info && st.info.size > 0 && f.size > 0 && st.info.size !== f.size) {
          bumpChannelStats("btn", (e) => { e.wrongFile = (e.wrongFile || 0) + 1; e.wrongFileAt = Date.now(); });
          setStatus({ videoLast: "the page shim handed over " + st.info.size + " bytes for a " + f.size + "-byte clip" });
        }
        if (!st || !st.fired) {
          setStatus({ videoLast: "clicked attach but Messenger never opened a file picker (seen=" + ((st && st.seen) || 0) + (st && st.err ? ", shim error: " + trunc(st.err, 40) : "") + ")" });
          return false;
        }
        return true;
      } catch (e) { return false; }
      finally { if (url) setTimeout(() => safe(() => URL.revokeObjectURL(url)), 30000); }
    };
    btnFnRef = btnFn;

    // JUST-SEND MODE (v0.21.43, operator: "just send the videos"). The verdict
    // engine below PREDICTS whether a clip attached by watching the tray during
    // the upload — and on this fleet's throttled windows the prediction kept
    // being wrong. The early versions that worked did no prediction: attach,
    // wait, Enter. This is that, with the modern attach: exactly ONE dispatch per
    // clip (the file API; if that CALL fails — nothing reached the composer — one
    // paste, never the drag/input ladder that stacked copies), then a wait that
    // ends early when a tile is visible with its upload done, otherwise a fixed
    // budget. (v0.21.47) Returns true (tile seen), "blind" (Messenger's send
    // control flipped — staged, tile pending), "none" (control still reads
    // empty with an empty tray — provably nothing staged; the chat is retried),
    // "unverified" (dispatched, no signal available — never counted, never
    // re-dispatched this visit), false (nothing could dispatch). The old
    // "assume" verdict is gone: it stamped chats "sent" with nothing attached.
    // Afterwards the engine checks the GROUND TRUTH (a video visible in the
    // chat). Never a second copy of a clip into the same tray.
    if (opts && opts.justSend) {
      const beforeEls0 = new Set(trayEls());
      const beforeBtns0 = new Set(trayRemoveBtns());
      const tileNow = () => trayEls().some((el) => !beforeEls0.has(el));
      const canCdp = !!diskPath && cdpUsableNow() && !!composer && !composerText(composer);
      // ATTACH CHANNELS (v0.21.45): "chooser" (trusted click on the attach button
      // with the file chooser intercepted — the input Messenger itself creates
      // gets the file), "drop" (trusted drag-and-drop of the real file onto the
      // composer), "input" (set a persistent input directly), "paste" (synthetic).
      // (v0.21.47) EVIDENCE, NOT ASSUMPTION. The old block returned "assume" when a
      // channel merely DISPATCHED and nothing showed, and the caller then pressed
      // Enter blind and stamped the chat "sent" — on a build where the channel
      // stages nothing that burned every chat with no video and no retry (the
      // "always failing" report). Now the verdict comes from Messenger's own
      // state: a tile (true), the send control flipped from like to Send
      // ("blind" — staged, tile pending), or the control STILL reading like with
      // an empty tray ("none" — provably nothing staged, duplicate-safe to try the
      // next channel now and to retry the chat later). Only when that signal is
      // unavailable is a dispatched-but-unseen clip "unverified" (never counted,
      // never re-dispatched in this visit — the flush Enter + bounded retry policy
      // in maybeSendVideo take it from there).
      const pref = await getAttachPref();
      // (v0.21.51 SAFE MODE) the TRUSTED channels — a real click on Messenger's
      // attach button ("chooser") and a real file drop ("drop") — are OFF unless
      // the dashboard's videoTrustedChannels is on: on a build where the dialog
      // interception does not apply, that click opens a real Windows "Open"
      // dialog on the machine, and an uncaught drop makes the tab open the file
      // (the operator's "opening random files"). Default = the quiet channels:
      // the persistent input via the file API, then the synthetic paste.
      const trusted = powerOn("videoTrustedChannels"); // (v0.21.53) per-machine local flag, never the shared cloud row
      // (v0.21.53) DROP RESCUE. v0.21.51 put "chooser" and "drop" behind ONE switch
      // after real Windows "Open" dialogs appeared on the desktop — but only
      // "chooser" can do that: it is the one channel that clicks the attach button
      // with Page.setInterceptFileChooserDialog armed. "drop" dispatches a trusted
      // drag-and-drop through CDP; it opens no dialog and touches no window. Lumping
      // them together removed the only working fallback: PC-1zysp shows the persistent
      // input going missing ("composer file input not found", err=130) while the
      // synthetic paste has NEVER staged a clip on this build (paste:136d/0t) — so
      // every chat there ends at the link. Drop is therefore allowed, but only once
      // this machine has proven the quiet channels dead (two sets with nothing
      // confirmed). A machine where "input" works never reaches it. Local
      // `videoDropRescue: false` turns it off.
      const dropRescue = !trusted && powerFlags.videoDropRescue !== false && (attachMiss.streak || 0) >= 2;
      // (v0.21.54) "dom" — the pure-DOM file-input assignment (`input.files = …` +
      // a change event). It is the strategy the legacy ladder has always carried and
      // that worked before .45, it needs NO debugger (no infobar), opens nothing, and
      // it has no locality rule at all: it takes the LAST non-listing
      // `input[type=file]` in the document. The CDP "input" channel, by contrast,
      // demands the input be within 160 px of the composer or inside its 8 nearest
      // ancestors AND score >= 7 — which is why PC-1zysp logs "composer file input
      // not found" 130 times while the DOM path was never even tried (it only ran
      // when videoJustSend === false, and just-send is the default). Quiet by
      // construction, so it sits in the default order right after the CDP attempt.
      // (v0.21.57) "btn" leads the quiet order: it is the only channel that fills
      // the input Messenger actually created, it opens no dialog and moves no
      // window, and on a build that makes its input on demand it is the only one
      // that can work at all.
      const ALL = trusted
        ? ["btn", "chooser", "drop", "input", "dom", "paste"]
        : (dropRescue ? ["btn", "input", "dom", "drop", "paste"] : ["btn", "input", "dom", "paste"]);
      let order = pref && ALL.indexOf(pref.channel) !== -1 ? [pref.channel].concat(ALL.filter((c) => c !== pref.channel)) : ALL.slice();
      // (v0.21.54) when the file API is unusable/parked only the CDP channels are
      // impossible — "dom" needs no debugger, so it must survive this filter (it used
      // to be dropped with them, which is how a parked machine was left with paste alone).
      // "btn" and "dom" need no debugger, so they survive a file-API park.
      if (!canCdp) order = order.filter((c) => c === "paste" || c === "dom" || c === "btn");
      if (!order.length) order = ["btn", "dom", "paste"];
      // No learned channel and the last set(s) on this machine showed nothing:
      // rotate the starting channel so a dead first channel is not tried first forever.
      if (!pref && (attachMiss.streak || 0) > 0 && order.length > 1) {
        const k = attachMiss.streak % order.length;
        order = order.slice(k).concat(order.slice(0, k));
      }
      // (v0.21.67) USER-ACTIVATION PULSE — an OPT-IN EXPERIMENT (local
      // videoActivationPulse:true), keys only (F16, then Shift) through the
      // debugger, before a channel that needs no debugger. The media gate above
      // is the fix; activation is not a term of Chrome's media deferral. Kept so a
      // machine can test the remaining hypothesis (a gesture-gated uploader).
      if (powerOn("videoActivationPulse") && !userActivated() && cdpAvailable() && order.length && order[0] !== "input" && order[0] !== "drop" && order[0] !== "chooser") {
        setStatus({ lastAction: "giving the page a user activation before the clip (experiment)…" });
        const a = await Promise.race([ask({ type: "CDP_ACTIVATE" }), sleep(15000).then(() => null)]);
        lastActPulse = { at: Date.now(), how: a ? (a.how || "err:" + trunc(a.error || "?", 30)) : "no answer", ok: !!(a && a.ok), after: userActivated() };
        setStatus({ videoLast: "user activation: " + lastActPulse.how + (lastActPulse.after ? " ✓" : " — page still reports none") });
      }
      // (v0.21.67) THE REACTION PROBE: watch what Messenger does with the clip
      // (MAIN world, auto-restored). A clip Messenger HOLDS (rxHeld) gets no
      // second channel on top and ends "unverified" (paced fresh retry) rather
      // than "none"; a clip it REJECTED (rxRejected) is "none" as before. Armed
      // only when the clip's exact byte size is known — never a guess.
      const rxSize = (diskPath && diskSizeByPath[diskPath]) || (fileObj && fileObj.size) || 0;
      const rxArmed = rxSize > 0 ? await Promise.race([ask({ type: "ARM_RX_PROBE", size: rxSize, ms: 150000 }), sleep(6000).then(() => null)]) : null;
      const rxOn = !!(rxArmed && rxArmed.ok);
      const rxRead = async () => { if (!rxOn) return null; const r = await Promise.race([ask({ type: "RX_STATUS" }), sleep(6000).then(() => null)]); return r && r.ok && r.status ? r.status : null; };
      // Every exit reads the probe once more, records the channel's code (a healthy
      // machine's signature is what a dead one is compared against) and disarms.
      // (v0.21.77) EVIDENCE, never a verdict: Messenger did nothing with THIS clip's
      // bytes but minted a URL for a blob the size of ANOTHER clip of the set ⇒ it
      // was handed that clip again (the stale-shim double of .76 and before). Shown
      // as "dup:clipK" in the attach trace; the send decision is unchanged.
      const rxDupOf = (s, ch) => {
        if (ch !== "btn" || !(lastShimFired > 0)) return ""; // only a hand-over that happened can have handed the wrong clip
        if (!s || !Array.isArray(s.otherSizes) || !s.otherSizes.length) return "";
        if ((s.objUrl || 0) + (s.vidSrc || 0) + (s.meta || 0) + (s.read || 0) + (s.up || 0) > 0) return ""; // it handled OUR clip
        const sizes = Array.isArray(opts.setSizes) ? opts.setSizes : [];
        for (let k = 0; k < sizes.length; k++) {
          if (k === opts.slot || !(sizes[k] > 0)) continue;
          if (Math.abs(sizes[k] - (s.expect || 0)) < 4096) continue; // the same bytes as ours (a clip listed twice)
          if (s.otherSizes.some((z) => Math.abs(z - sizes[k]) < 4096)) return "clip" + (k + 1);
        }
        return "";
      };
      const rxFinish = async (ch, verdict) => {
        const s = await rxRead();
        const code = rxCode(s);
        if (code !== "-") { lastAttachRx = code; noteChannelRx(ch, code, false); }
        lastAttachDupOf = rxDupOf(s, ch);
        if (rxOn) ask({ type: "RX_STATUS", disarm: true });
        return verdict;
      };
      let held = null; // the channel whose clip Messenger read but never staged
      lastAttachRx = "-";
      const JUST_SEND_WAIT_MS = 75000;
      const CHANNEL_WINDOW_MS = 20000;
      const t0 = Date.now();
      let lastTick = Date.now();
      const tick = () => { if (opts.onTick && Date.now() - lastTick > 30000) { lastTick = Date.now(); try { opts.onTick(); } catch (e) { /* bookkeeping only */ } } };
      // Messenger's own staged signal, from the like-type baseline captured on the
      // empty composer: flipped TO a send-type control = staged; still like-type =
      // nothing staged (a mere re-label of the like button is not a flip).
      const likeType = (l) => !!l && LIKE_CTL_RE.test(l) && !SEND_CTL_RE.test(l);
      const flippedToSend = () => { if (!ctlBase) return false; const l = sendControlLabel(); return !!l && l !== ctlBase && !likeType(l) && !composerText(composer); };
      const stillEmptyPerControl = () => { if (!ctlBase) return false; const l = sendControlLabel(); return !!l && likeType(l); };
      const signalOk = !!ctlBase;
      // Escalate to the next channel only while the control PROVES the previous
      // one put nothing in (signal available and still like-type) — nothing staged
      // means nothing to duplicate. No signal ⇒ one dispatch only (law 1).
      let escalate = signalOk;
      let dispatched = null;
      let prefDispatchFailed = false;
      let maybeIn = false; // a file-API set command timed out: the file MAY be in
      for (const ch of order) {
        if (tid && !stillOnThread(tid)) return dispatched ? "navigated" : "aborted";
        // never a second channel on top of anything: signal lost/flipped, a tile, or an upload in the tray
        if (dispatched && (!stillEmptyPerControl() || trayRemoveBtns().length > 0 || trayUploads() > 0)) break;
        let fired = false;
        if (ch === "paste") {
          try { fired = pasteFnRef ? !!(await pasteFnRef()) : false; } catch (e) { fired = false; }
        } else if (ch === "dom") {
          try { fired = inputFnRef ? !!(await inputFnRef()) : false; } catch (e) { fired = false; }
        } else if (ch === "btn") {
          try { fired = btnFnRef ? !!(await btnFnRef()) : false; } catch (e) { fired = false; }
        } else {
          const r = await ask({ type: "CDP_SET_FILES", paths: [diskPath], channel: ch });
          if (r && r.ok) fired = true;
          else if (r && r.maybeSet) { fired = true; maybeIn = true; escalate = false; } // the file MAY be in: never a second channel on top
          else {
            if (r && r.missing) forgetDiskPaths([diskPath]);
            // (v0.21.54) EVERY non-ok result goes through noteCdpFail. The old guard
            // only passed "denied"/"unavailable"/"permission", so the commonest
            // failure of all — "composer file input not found" — never reached the
            // 3-strike park: cdpStrikes stayed 0, cdpUsableNow() stayed true, and the
            // machine paid a full chrome.debugger.attach (one "SubSell is debugging
            // this browser" flash) per clip for a channel that had failed 130 times
            // in a row. It also made the escalating park added in .53 dead code.
            noteCdpFail(r);
            setStatus({ videoLast: "attach via " + ch + " not possible here: " + trunc((r && r.error) || "?", 70) });
          }
        }
        if (!fired) { if (pref && ch === pref.channel) prefDispatchFailed = true; continue; }
        dispatched = ch;
        lastAttachVia = ch;
        noteChannelStat(ch, "dispatched");
        setStatus({ lastAction: "clip handed to the composer (" + ch + ") — waiting for the upload…" });
        const w0 = Date.now();
        const windowMs = escalate ? CHANNEL_WINDOW_MS : JUST_SEND_WAIT_MS;
        let seenAt = 0;
        let flippedAt = 0;
        while (Date.now() - w0 < windowMs) {
          await sleep(1000); tick();
          if (tid && !stillOnThread(tid)) {
            for (const b of trayRemoveBtns()) if (!beforeBtns0.has(b)) safe(() => b.click()); // de-stray the wrong chat
            return "navigated";
          }
          const seen = tileNow();
          if (seen && !seenAt) { seenAt = Date.now(); noteChannelStat(ch, "tile"); await rememberAttachPref(ch); }
          if (seen && trayUploads() === 0 && Date.now() - seenAt > 2000) return await rxFinish(ch, true); // tile visible, upload done
          if (!seen && flippedToSend()) { if (!flippedAt) flippedAt = Date.now(); escalate = false; if (Date.now() - flippedAt > 45000) break; } // staged per Messenger: no further channel, give the tile 45 s
        }
        if (tileNow()) return await rxFinish(ch, true); // visible (upload may still run — the caller waits it out)
        if (flippedToSend()) { noteChannelStat(ch, "blind"); await rememberAttachPref(ch); return await rxFinish(ch, "blind"); } // staged for sure, tile pending — send on the control alone
        // (v0.21.67) Nothing shows — but did Messenger READ the clip? Then it holds
        // it (decoding, validating, uploading) and a second channel would stage a
        // second copy: stop escalating, wait the budget out. A decode ERROR on our
        // clip means it was rejected — the next channel stays duplicate-safe.
        {
          const rxS = await rxRead();
          const codeS = rxCode(rxS);
          if (codeS !== "-") { lastAttachRx = codeS; noteChannelRx(ch, codeS, false); }
          if (rxHeld(rxS)) {
            held = ch;
            escalate = false;
            setStatus({ videoLast: "Messenger took the clip via " + ch + " (" + codeS + ") but has not staged it yet — waiting, never a second copy" });
          } else if (rxRejected(rxS)) {
            setStatus({ videoLast: "Messenger tried the clip via " + ch + " and its decode failed (" + codeS + ") — nothing staged" });
          }
        }
        if (!escalate) break;
        noteChannelStat(ch, "none"); // control still says empty: this channel put nothing in — the next one is duplicate-safe
      }
      if (!dispatched) {
        // no channel could even dispatch — clean failure, retried later; a learned
        // channel that can no longer dispatch (button renamed…) is forgotten after 3
        await notePrefMiss(); // (v0.21.54) see below — a pref that cannot dispatch is exactly what this counts
        return false;
      }
      // (v0.21.54) A LEARNED CHANNEL THAT CAN NO LONGER DISPATCH MUST BE FORGOTTEN.
      // notePrefMiss used to be reachable only when NO channel dispatched, or when
      // the pref itself dispatched. On PC-1zysp the pref ("input") failed every time
      // while paste always dispatched, so both guards missed: attachPref stayed
      // {channel:"input"} for ever, "input" was tried first on every single clip,
      // and the miss-streak rotation is gated on `!pref` so it could never help.
      if (prefDispatchFailed) await notePrefMiss();
      // Nothing visible yet: spend the rest of the budget (a late tile / flip still counts).
      while (Date.now() - t0 < JUST_SEND_WAIT_MS) {
        await sleep(1000); tick();
        if (tid && !stillOnThread(tid)) return "navigated";
        if (tileNow()) { noteChannelStat(dispatched, "tile"); await rememberAttachPref(dispatched); return await rxFinish(dispatched, true); }
        if (flippedToSend()) { noteChannelStat(dispatched, "blind"); await rememberAttachPref(dispatched); return await rxFinish(dispatched, "blind"); }
      }
      if (pref && dispatched === pref.channel) await notePrefMiss();
      // (v0.21.67) the final reading of the probe (a late decode still counts)
      {
        const rxF = await rxRead();
        const codeF = rxCode(rxF);
        if (codeF !== "-") { lastAttachRx = codeF; if (rxHeld(rxF) && !held) held = dispatched; }
        lastAttachDupOf = rxDupOf(rxF, dispatched);
        if (rxOn) ask({ type: "RX_STATUS", disarm: true });
      }
      // Decide from Messenger's state, never assume: the control still reads
      // like-type with an empty tray and no upload ⇒ nothing was staged.
      // (v0.21.67) …unless Messenger READ the clip: then it is held, not absent —
      // "unverified" (a fresh, paced retry that sweeps any late tile first; never
      // a second copy in this visit) instead of "none".
      if (held) {
        lastAttachHeld = true;
        noteChannelRx(held, lastAttachRx, true);
        noteChannelStat(dispatched, "unverified");
        setStatus({ videoLast: "clip handed over via " + held + " and read by Messenger (" + lastAttachRx + ") but never staged — retrying on a later visit" });
        return "unverified";
      }
      if (!maybeIn && stillEmptyPerControl() && trayRemoveBtns().length === 0 && trayUploads() === 0) {
        noteChannelStat(dispatched, "none");
        return "none";
      }
      noteChannelStat(dispatched, "unverified");
      return "unverified";
    }

    // Try each strategy IN ORDER; require a NEW preview element to appear before
    // trusting it (identity, not count-delta — immune to simultaneous changes).
    let attached = false;
    let anyFired = false; // did ANY strategy dispatch into this composer?
    let strategyIdx = 0;
    let lastBeforeEls = new Set();
    for (const attempt of attempts) {
      // A previous strategy's paste may have rendered too late for its window —
      // clean the EXTRAS (never the known-good clips) before escalating, or the
      // next strategy would stage a second copy and one Enter sends both.
      if (strategyIdx > 0 && trayRemoveBtns().length > knownCount) await sweepTrayExtras(knownCount);
      // Escalating past the optimistic paste: settle any running uploads first
      // (some FB builds reject a paste mid-upload — the retry then lands).
      if (strategyIdx > 0 && trayUploads() > 0) {
        const tS = Date.now();
        while (Date.now() - tS < 60000 && trayUploads() > 0) {
          if (tid && !stillOnThread(tid)) return anyFired ? "navigated" : "aborted";
          await sleep(1000);
        }
      }
      // Navigating away mid-attach means any further paste would land in the
      // WRONG chat's composer — stop before dispatching, and if a stray already
      // appeared in the new chat's tray, remove it immediately (fresh node
      // identities are reliable milliseconds after render).
      const beforeBtns = new Set(trayRemoveBtns());
      if (tid && !stillOnThread(tid)) return anyFired ? "navigated" : "aborted";
      const beforeEls = new Set(trayEls());
      lastBeforeEls = beforeEls;
      const uploadsAtDispatch = trayUploads();
      // (the strategies are async: the file API round-trips to the background,
      // the synthetic ones may have to load the File first)
      let fired = false;
      try { fired = !!(await Promise.resolve(safe(attempt, false))); } catch (e) { fired = false; }
      if (!fired) { strategyIdx++; continue; }
      anyFired = true;
      lastAttachVia = attempt.via || "-";
      // Window sizing: the OPTIMISTIC paste fails fast (12s) when uploads were
      // running at dispatch — if this build rejects mid-upload pastes we want to
      // move to the settle-and-retry quickly, not burn 30s. The settled retry
      // keeps the LONG 30s window (throttled/RDP machines render previews
      // 20-30s late; a short window there judged good attaches "failed", swept
      // them away and struck the chat — the v0.21.29 lockout bug). The file API
      // strategy gets 45s when the staged signal can shortcut it, 60s when it
      // cannot (a tile is then the only evidence, and it can be a minute late).
      const windowMs = attempt.isCdp ? (ctlBase ? 45000 : 60000) : strategyIdx === firstPasteIdx ? (uploadsAtDispatch > 0 ? 12000 : 30000) : strategyIdx === firstPasteIdx + 1 ? 30000 : 12000;
      const start = Date.now();
      let navigated = false;
      let blind = false;
      // The control also flips when the OPERATOR types: a flip counts as staged
      // only while the textbox is still empty (otherwise Enter would ship their
      // half-typed text along with the clip).
      const flipped = () => ctlBase && stagedPerControl(ctlBase) === true && !composerText(composer);
      while (Date.now() - start < windowMs) {
        await sleep(1000);
        if (tid && !stillOnThread(tid)) { navigated = true; break; }
        if (trayEls().some((el) => !beforeEls.has(el))) {
          attached = true;
          break;
        }
        if (flipped()) { blind = true; break; } // staged per the composer, tile pending
      }
      if (blind && !attached) {
        // The composer holds the clip — give its tile a short chance to show
        // (it is the better evidence), then proceed on the control alone.
        const tB = Date.now();
        while (Date.now() - tB < 10000) {
          await sleep(1000);
          if (tid && !stillOnThread(tid)) { navigated = true; break; }
          if (trayEls().some((el) => !beforeEls.has(el))) { attached = true; break; }
        }
      }
      if (navigated) {
        for (const b of trayRemoveBtns()) if (!beforeBtns.has(b)) safe(() => b.click()); // de-stray the wrong chat
        return "navigated";
      }
      if (attached) {
        if (attempt.isCdp) noteCdpVerified(false);
        break; // this strategy worked — stop trying others
      }
      if (blind) {
        if (attempt.isCdp) noteCdpVerified(true);
        return "blind"; // staged for sure, invisible so far — NEVER dispatch another copy
      }
      if (attempt.isCdp) {
        // The browser accepted the set, yet neither a tile nor the composer's
        // own control showed anything for the whole window. A late render (or a
        // lagging control) cannot be ruled out, and a second dispatch into this
        // tray is exactly how tiles piled up — so NEVER fall through to the
        // synthetic strategies here (the v0.21.36 rule, kept): the clip counts
        // as attempted (skip-forward), the reply's Enter flushes it if it was
        // staged invisibly, and the resume visit adopts its tile if it renders
        // late. Two of these in a row park the file API so the synthetic path
        // gets the NEXT set instead.
        noteCdpUnverified();
        return "unverified";
      }
      strategyIdx++;
    }
    if (!attached) {
      // LATE-RENDER GRACE before declaring failure: one more beat — a paste that
      // rendered after the last window is a SUCCESS, not a stray to sweep.
      await sleep(8000);
      if (trayEls().some((el) => !lastBeforeEls.has(el))) {
        await sleep(1200);
        return true;
      }
      if (ctlBase && stagedPerControl(ctlBase) === true && !composerText(composer)) return "blind"; // flipped late
      await sweepTrayExtras(knownCount);
      if (trayRemoveBtns().length > knownCount) return "dirty"; // unverifiable leftover — never re-attempt
      return false; // provably nothing new attached — re-attempting later cannot duplicate
    }
    await sleep(1200); // let the upload begin before the next paste
    return true;
  }
  // ONE Enter sends everything attached (+ click-Send fallback). Attach + send-
  // attempt = delivered (the v0.12.3 law): detach confirmation stays best-effort
  // because a false "not sent" used to trigger retries → duplicate videos.
  async function sendAttachedVideos(blindBaseline, tid) {
    const composer2 = findComposer();
    const previews = trayEls().length || 1;
    if (composer2) pressEnter(composer2);
    const s2 = Date.now();
    // Every wait below stops the moment the operator opens another chat: a
    // Send click there would ship THEIR draft to another buyer.
    const gone = () => tid && !stillOnThread(tid);
    if (blindBaseline) {
      // BLIND SEND (v0.21.38): no tile to watch, and the upload may still be
      // running (Enter is queued by Messenger until it completes). "Sent" = the
      // send control back in its empty-composer state (the like button — any
      // like-type label, not only the exact baseline string); allow the upload time.
      // ("assume" = no baseline at all: tray emptied or a like-type label = sent)
      const backToLike = () => {
        const l = sendControlLabel();
        return (blindBaseline !== "assume" && l === blindBaseline) || (!!l && LIKE_CTL_RE.test(l) && !SEND_CTL_RE.test(l));
      };
      while (Date.now() - s2 < 90000) {
        await sleep(1000);
        if (gone()) return true;
        if (trayEls().length < previews && trayUploads() === 0) return true;
        if (backToLike()) return true;
      }
      if (gone()) return true;
      clickSend();
      const s3 = Date.now();
      while (Date.now() - s3 < 20000) {
        await sleep(1000);
        if (gone() || backToLike()) return true;
      }
      return true; // attach + send attempt = delivered (the v0.12.3 law)
    }
    while (Date.now() - s2 < 8000) {
      await sleep(400);
      if (gone()) return true;
      if (trayEls().length < previews) return true; // confirmed gone = sent
    }
    if (gone()) return true;
    clickSend(); // fallback for layouts where Enter doesn't send
    await sleep(1500);
    return true;
  }
  // SEND WHAT IS STAGED (v0.21.43 — the rebuilt send step). The failure the
  // operator sees most is "the clip is attached in the chat and never goes out":
  // Enter was pressed while the upload was still running (Messenger does not
  // reliably queue it, and on a MINIMIZED window uploads and rendering are
  // slow), and nothing ever pressed again. This loop keeps going until the tray
  // is EMPTY: wait out uploads (up to 4 min — never press mid-upload), then
  // rounds of Enter → Send button → click-focus-Enter, 12 s apart. Pressing on
  // a tray that already emptied is a no-op, so the rounds can never send a
  // second copy. blind = nothing visible to watch (an "assume" attach): three
  // rounds, "sent" when the like button is back or after the rounds.
  // Returns "sent", "stuck" (tile still there after 6 rounds) or "navigated".
  async function sendStagedClip(tid, blind, onTick) {
    const gone = () => tid && !stillOnThread(tid);
    const likeBack = () => { const l = sendControlLabel(); return !!l && LIKE_CTL_RE.test(l) && !SEND_CTL_RE.test(l); };
    const sendCtl = () => SEND_CTL_RE.test(sendControlLabel());
    // "Uploading" = a progressbar in the composer's OWN band (just above the
    // textbox). Messenger's list-paging spinners are progressbars too, far above
    // — a stuck one of those must never hold the send.
    const uploading = () => {
      const bars = trayQuery('[role="progressbar"]');
      if (!bars.length) return false;
      const c = findComposer();
      const cr = c ? safe(() => c.getBoundingClientRect(), null) : null;
      if (!cr) return true;
      return bars.some((el) => { const r = safe(() => el.getBoundingClientRect(), null); return !!r && r.bottom <= cr.top + 8 && cr.top - r.top < 420; });
    };
    let lastTick = Date.now();
    const tick = () => { if (onTick && Date.now() - lastTick > 30000) { lastTick = Date.now(); try { onTick(); } catch (e) { /* bookkeeping only */ } } };
    const waitUploads = async (capMs) => {
      const w0 = Date.now();
      while (Date.now() - w0 < capMs && uploading()) {
        if (gone()) return false;
        await sleep(1000); tick();
      }
      return !gone();
    };
    // Never press mid-upload (Messenger drops it) — but a spinner that never ends
    // must not hold the clip forever: after 150 s press anyway.
    if (!(await waitUploads(150000))) return "navigated";
    const t0 = Date.now();
    let rounds = 0;
    // The tray right before the first press. "Sent" = the tray SHRANK (a persistent
    // blob image / listing video outside the rows can keep it from ever being 0).
    // "Grew" = a late stray from an earlier attempt rendered — ours was pressed once;
    // stop pressing and let the caller's settle sweep leftovers (never send a stray).
    let baseline = trayEls().length;
    while (Date.now() - t0 < 5 * 60 * 1000) {
      if (gone()) return "navigated";
      const c = findComposer();
      // (v0.21.48) rounds alternate synthetic and TRUSTED presses: a real Enter /
      // a real click on Send delivered through the debugger protocol is exactly
      // what Lexical gets from a human, and it is a user activation for the page.
      const step = rounds % 4;
      if (step === 1) { if (!(await cdpPress("enter"))) { if (sendCtl()) clickSend(); else if (c) pressEnter(c); } }
      else if (step === 2) { if (sendCtl()) clickSend(); else if (c) pressEnter(c); } // the Send button — only while the control IS Send
      else if (step === 3) { if (!(await cdpPress("click"))) { if (c) { safe(() => c.click()); safe(() => c.focus()); pressEnter(c); } } }
      else if (c) pressEnter(c);
      else if (sendCtl()) clickSend();
      rounds++;
      setStatus({ lastAction: "sending the staged clip (attempt " + rounds + ")…" });
      const tW = Date.now();
      let uploadResumed = false;
      while (Date.now() - tW < 12000) {
        await sleep(1000); tick();
        if (gone()) return "navigated";
        if (uploading()) { uploadResumed = true; break; } // the press queued behind a (re)started upload — wait it out
        const n = trayEls().length;
        if (blind ? (likeBack() || n < baseline) : (n < baseline || (n === 0 && trayRemoveBtns().length === 0))) return "sent";
        if (!blind && n > baseline) return "sent"; // grew: a stray rendered — pressed once, leave the rest to the settle sweep
      }
      if (uploadResumed) { if (!(await waitUploads(150000))) return "navigated"; baseline = trayEls().length; continue; }
      // (v0.21.48) a blind clip is "sent" ONLY when the control went back to like
      // or the tray shrank — never by round count (that read an upload that had
      // not even started as delivered). Whatever stays staged is "stuck": the
      // staged-clip watcher keeps pressing until it leaves.
      if (blind && rounds >= 4) return "stuck";
      if (!blind && rounds >= 8) return "stuck";
    }
    return "stuck";
  }
  // "Uploading" = a progressbar in the composer's OWN band (just above the
  // textbox). Messenger's list-paging spinners are progressbars too, far above.
  function uploadingInBand() {
    const bars = trayQuery('[role="progressbar"]');
    if (!bars.length) return false;
    const c = findComposer();
    const cr = c ? safe(() => c.getBoundingClientRect(), null) : null;
    if (!cr) return true;
    return bars.some((el) => { const r = safe(() => el.getBoundingClientRect(), null); return !!r && r.bottom <= cr.top + 8 && cr.top - r.top < 420; });
  }
  // (v0.21.48) TRUSTED press through the debugger protocol: "enter" focuses the
  // composer and sends a real Enter; "click" clicks the Send control at its
  // centre (the background re-finds it in the page). Either is a user
  // activation for the page — which lifts Chrome's deferred media load on a
  // hidden tab, the reason an attached clip's upload used to wait for a click.
  async function cdpPress(mode) {
    if (!cdpAvailable()) return false;
    if (!powerOn("videoTrustedChannels")) return false; // (v0.21.51) quiet by default: synthetic presses only
    try {
      const r = await Promise.race([ask({ type: "CDP_SEND", mode }), sleep(15000).then(() => null)]);
      return !!(r && r.ok);
    } catch (e) { return false; }
  }
  // (v0.21.48) STAGED-CLIP WATCHER — the "obligatory send". Field report: a clip
  // sits attached in the composer, its upload only starts when the operator
  // clicks the page (Chrome defers media loading and pauses rendering in a
  // hidden/occluded tab), and once it finishes nobody presses Send. Every scan
  // tick — and the moment the tab becomes visible — this looks at the OPEN chat:
  // a clip WE handed over (a recent in-flight / stuck / retry mark for this chat),
  // no text typed by anyone, upload finished ⇒ press send (synthetic Enter →
  // trusted Enter → Send button → trusted click), one press per 15 s, counted
  // delivered when the tile leaves. An upload still running on a hidden tab ⇒
  // bring the window to the front so it can run. Never touches an attachment
  // the operator staged (no mark of ours ⇒ not ours).
  // (v0.21.50) AUTOMATIC PICTURE-IN-PICTURE — the gesture-free "keep awake".
  // Chrome keeps a page PAINTING (animation frames tick, media loads, no
  // "disable rendering" optimisation) for as long as the page owns a
  // Picture-in-Picture window — the same rule that keeps a captured tab alive.
  // PiP needs a user activation, and a trusted click the extension dispatches
  // itself through the debugger protocol (CDP_ACTIVATE) IS one. So for the
  // length of a video set on a hidden/minimized tab a tiny always-on-top PiP
  // window shows "SubSell · envoi vidéo…" and closes when the set ends. Nothing
  // to click; works with the window minimized and the mouse anywhere. Chrome
  // allows one PiP window at a time per browser — another profile's set simply
  // takes it over (the first upload keeps running; the page shim covers the rest).
  let pipVideo = null, pipCanvas = null, pipTimer = null, pipSince = 0;
  function pipDraw(label) {
    try {
      const g = pipCanvas.getContext("2d");
      g.fillStyle = "#17171c"; g.fillRect(0, 0, 320, 180);
      g.fillStyle = "#ffffff"; g.font = "bold 22px system-ui, Segoe UI, sans-serif"; g.fillText("SubSell", 18, 44);
      g.fillStyle = "#8ec5ff"; g.font = "15px system-ui, Segoe UI, sans-serif";
      g.fillText("Envoi de la vidéo démo…", 18, 82);
      g.fillStyle = "#d0d0d8"; g.fillText(trunc(label || "", 30), 18, 108);
      const s = Math.max(0, Math.round((Date.now() - pipSince) / 1000));
      g.fillStyle = "#7a7a88"; g.font = "13px system-ui, Segoe UI, sans-serif";
      g.fillText("ne pas fermer · " + Math.floor(s / 60) + ":" + String(s % 60).padStart(2, "0"), 18, 156);
    } catch (e) { /* cosmetic */ }
  }
  async function enterPipForSet(label) {
    try {
      if (!document.pictureInPictureEnabled || !HTMLVideoElement.prototype.requestPictureInPicture) return false;
      if (document.pictureInPictureElement && document.pictureInPictureElement === pipVideo) { pipDraw(label); return true; }
      // the activation: a trusted click on the composer (or a harmless Shift key)
      const act = await Promise.race([ask({ type: "CDP_ACTIVATE", reason: "pip" }), sleep(12000).then(() => null)]); // (v0.21.67) reason:"pip" keeps the composer-click rung this opt-in path always had
      if (!(act && act.ok)) { setStatus({ videoLast: "no trusted activation for picture-in-picture (" + trunc((act && act.error) || "no answer", 60) + ")" }); return false; }
      if (!pipCanvas) { pipCanvas = document.createElement("canvas"); pipCanvas.width = 320; pipCanvas.height = 180; }
      pipSince = Date.now();
      pipDraw(label);
      if (!pipVideo || !pipVideo.isConnected) {
        pipVideo = document.createElement("video");
        pipVideo.muted = true; pipVideo.playsInline = true; pipVideo.autoplay = true;
        pipVideo.setAttribute("aria-hidden", "true");
        pipVideo.style.cssText = "position:fixed;left:-9999px;top:-9999px;width:2px;height:2px;opacity:0;pointer-events:none;";
        pipVideo.srcObject = pipCanvas.captureStream(2);
        (document.body || document.documentElement).appendChild(pipVideo);
      }
      try { await pipVideo.play(); } catch (e) { /* muted autoplay is allowed; ignore */ }
      if (pipVideo.readyState < 1) {
        await new Promise((r) => { const t = setTimeout(r, 2500); pipVideo.addEventListener("loadedmetadata", () => { clearTimeout(t); r(); }, { once: true }); });
      }
      await pipVideo.requestPictureInPicture();
      if (pipTimer) clearInterval(pipTimer);
      pipTimer = setInterval(() => pipDraw(label), 1000);
      safe(() => chrome.storage.local.get(["pipN"], (r) => { if (chrome.runtime.lastError) return; chrome.storage.local.set({ pipN: ((r && r.pipN) || 0) + 1, pipAt: Date.now() }, () => void chrome.runtime.lastError); }));
      return true;
    } catch (e) {
      setStatus({ videoLast: "picture-in-picture refused (" + trunc((e && e.message) || e, 60) + ") — using window focus instead" });
      safe(() => chrome.storage.local.get(["pipFail"], (r) => { if (chrome.runtime.lastError) return; chrome.storage.local.set({ pipFail: { n: (((r && r.pipFail) || {}).n || 0) + 1, at: Date.now(), why: trunc((e && e.message) || e, 80) } }, () => void chrome.runtime.lastError); }));
      return false;
    }
  }
  async function exitPipForSet() {
    try {
      if (pipTimer) { clearInterval(pipTimer); pipTimer = null; }
      if (document.pictureInPictureElement && document.pictureInPictureElement === pipVideo) await document.exitPictureInPicture();
      if (pipVideo) { try { pipVideo.pause(); } catch (e) { /* ignore */ } }
    } catch (e) { /* best effort */ }
  }
  let pipHoldTimer = null;
  const stagedSweep = {}; // threadId -> {at, n, mutedUntil, fgAt}
  let lastSettings = {};
  async function sweepStagedClip(trigger) {
    try {
      const m = location.href.match(/\/t\/([^/?#]+)/);
      if (!m) return;
      const id = m[1];
      const btns = trayRemoveBtns();
      if (!btns.length) return;
      const c = findComposer();
      if (!c || composerText(c)) return; // an operator draft is theirs to send
      const now = Date.now();
      const sw = stagedSweep[id] || (stagedSweep[id] = { at: 0, n: 0, mutedUntil: 0, fgAt: 0 });
      if (sw.mutedUntil > now) return;
      const st = await getLocal(["videoSentThreads", "videoAttempts", "threadLocks"]);
      const vt = st.videoSentThreads || {};
      const mk = vt[id] || (adoptedAlias[id] != null ? vt[adoptedAlias[id]] : null);
      const at = (st.videoAttempts || {})[id];
      const recent = (t) => typeof t === "number" && now - t < 6 * 3600 * 1000;
      // ours = a set in flight / left stuck / a partial tail / a bounded-retry chat.
      // A plain confirmed mark is NOT enough: an attachment the operator staged
      // later in a served chat must never be sent by us.
      // (v0.21.67) a given-up chat counts too: a copy that surfaces late on it
      // (the tab finally shown) is ours — trimmed to one and sent, not left for
      // the next text reply's Enter.
      // (v0.21.72) …but NOT a chat whose marker says "the first clip is confirmed,
      // the rest follows" (noAdopt): a tile surfacing there is a late COPY of the
      // clip the buyer already has — the engine's next visit sweeps it, the watcher
      // must never send it.
      const ours = !!((mk && recent(mk.at) && !mk.noAdopt && (mk.via === "lock" || mk.stuck || mk.unverifiedTail || mk.gaveUp || typeof mk.resumeFrom === "number"))
        || (at && (recent(at.failAt) || recent(at.claimAt))));
      if (!ours) return;
      const lk = (st.threadLocks || {})[id];
      if (lk && lk.tab !== TAB_UID && now - (lk.at || 0) < LOCK_MS) return; // another tab is working this chat right now
      if (uploadingInBand()) {
        // The upload is running — or waiting to run: a hidden tab may never let
        // it start. Bring the window to the front (once a minute per chat).
        if (document.visibilityState !== "visible" && now - sw.fgAt > 60000) {
          sw.fgAt = now;
          ask({ type: "VIS_SHIM", on: true, hold: 120000 }); // (v0.21.49) the page reads "visible" + frames tick, 2 min
          // (v0.21.50) keep the page painting through a PiP window for 2 min (no
          // click needed); window focus only if PiP is refused
          // (v0.21.51) PiP / window focus only when the dashboard turned them on
          const pipOk = powerOn("videoPip") ? await enterPipForSet("upload en cours…") : false;
          if (pipOk) {
            if (pipHoldTimer) clearTimeout(pipHoldTimer);
            pipHoldTimer = setTimeout(() => { pipHoldTimer = null; if (!busy) exitPipForSet(); }, 120000);
            setStatus({ lastAction: "watcher: a clip is uploading on a hidden tab — keeping the page awake (picture-in-picture)" });
          } else if (powerOn("videoForeground")) {
            ask({ type: "VIDEO_FOREGROUND", on: true, hold: 120000 });
            setStatus({ lastAction: "watcher: a clip is uploading on a hidden tab — bringing the window to the front" });
          }
        }
        return;
      }
      if (now - sw.at < 15000) return;
      sw.at = now; sw.n++;
      // (v0.21.67) EXACTLY ONE before any press. The engine keeps at most one clip
      // of ours in flight per chat; more tiles here are copies that surfaced late
      // (a hidden tab finally shown — the strongest confirmation of the media-gate
      // diagnosis, so the pile is RECORDED for the 🩺). Trim to the newest first —
      // a pile must never ride the watcher's Enter ("double sending videos"). One
      // FRESH read decides both the trim and the press (the count read before the
      // storage await above is stale by now).
      const n0 = trayRemoveBtns().length;
      if (n0 > 1) {
        safe(() => chrome.storage.local.get(["attachPile"], (rP) => {
          if (chrome.runtime.lastError) return;
          const p = (rP && rP.attachPile) || {};
          p.n = (p.n || 0) + 1; p.max = Math.max(p.max || 0, n0); p.at = Date.now();
          p.vis = document.visibilityState + (safe(() => document.hasFocus(), false) ? "/focus" : ""); p.via = lastAttachVia || "-";
          chrome.storage.local.set({ attachPile: p }, () => void chrome.runtime.lastError);
        }));
        if (!(await trimTraySurplus(1))) { setStatus({ lastAction: "watcher: " + n0 + " staged copies would not trim to one — not sending a pile" }); return; }
      }
      const before = trayRemoveBtns().length;
      if (before !== 1) return; // 0: nothing to send; >1: a copy landed during the trim — next tick decides
      const step = sw.n % 4;
      setStatus({ lastAction: "watcher: sending a staged clip (" + trigger + ", try " + sw.n + ")" });
      if (step === 1) { if (!(await cdpPress("enter"))) pressEnter(c); }
      else if (step === 2) { if (!clickSend()) pressEnter(c); }
      else if (step === 3) { if (!(await cdpPress("click"))) { safe(() => c.click()); safe(() => c.focus()); pressEnter(c); } }
      else pressEnter(c);
      await sleep(6000);
      if (!stillOnThread(id)) return;
      if (uploadingInBand()) return; // the press queued behind a (re)started upload — next tick
      const afterN = trayRemoveBtns().length;
      if (afterN < before) {
        const n = before - afterN;
        const vt2 = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        const cur = vt2[id];
        let partial = false;
        let restQueued = false; // (v0.21.72) the watcher sent the first clip of a set that has more
        if (cur && cur.done) {
          cur.sent = (cur.sent || 0) + n;
          delete cur.stuck; delete cur.unverifiedTail;
          cur.at = now;
          partial = typeof cur.resumeFrom === "number" && cur.resumeTotal != null && cur.resumeFrom < cur.resumeTotal;
          if (!partial && cur.via === "lock" && typeof cur.resumeFrom !== "number") delete cur.via;
          if (!partial && cur.gaveUp) delete cur.gaveUp;
        } else {
          vt2[id] = { done: true, at: now, sent: n, recon: 1, via: "watch" }; // a retry-state chat: served now
          // (v0.21.72) …except that the tile just sent on a retry-state chat is the
          // ONE clip the engine handed over blind (videoAttempts.blindKey) — not
          // the whole set. This stamp used to close the chat after its first clip.
          // Credit that clip in the ledger; when the dashboard set holds clips this
          // chat was never handed, leave a resume marker for them (never adopting
          // another tile) and keep the chat on the pending queue.
          try {
            if (at && at.blindKey && lastSettings && lastSettings.videoCompleteSet !== false) {
              const cfgW = (Array.isArray(lastSettings.demoVideoUrls) ? lastSettings.demoVideoUrls.filter((v) => v && v.url) : []).map(clipIdsOf);
              const bi = cfgW.findIndex((ci) => ci.indexOf(at.blindKey) >= 0);
              if (bi >= 0) {
                const ledW = await clipLedgerPut(id, (e) => clipMark(e, cfgW[bi], "s", now));
                const owW = clipOwed(ledW, cfgW);
                if (owW.owed.length > 0) {
                  vt2[id] = { done: true, at: now, owner: TAB_UID, resumeFrom: owW.owed[0], resumeTotal: cfgW.length, sent: owW.sentN, recon: 1, noAdopt: 1 };
                  restQueued = true;
                }
              }
            }
          } catch (e) { /* the plain "served" stamp above stands */ }
        }
        await setLocal({ videoSentThreads: vt2 });
        // (v0.21.72) keep the clip ledger in step with the mark: the tile that just
        // left was a clip the engine had handed over (tried) — it is sent now.
        try {
          const vcW = (await getLocal(["videoClips"])).videoClips || {};
          const eW = vcW[id];
          if (eW && eW.t && Object.keys(eW.t).length) {
            eW.s = eW.s || {};
            for (const k of Object.keys(eW.t)) { eW.s[k] = now; delete eW.t[k]; }
            eW.at = now;
            await setLocal({ videoClips: vcW });
          }
        } catch (e) { /* bookkeeping only — the send itself is done */ }
        if (restQueued) {
          // the retry state must not outlive the credit (its failAt would keep this
          // watcher armed for a late copy); the rest of the set stays queued
          const amR = (await getLocal(["videoAttempts"])).videoAttempts || {};
          if (amR[id]) { delete amR[id]; await setLocal({ videoAttempts: amR }); }
          if (videoPending[id] == null && (adoptedAlias[id] == null || videoPending[adoptedAlias[id]] == null)) { videoPending[id] = now; persistDedup(); }
          videoLocked.delete(id);
        } else if (!partial) {
          const am = (await getLocal(["videoAttempts"])).videoAttempts || {};
          if (am[id]) { delete am[id]; await setLocal({ videoAttempts: am }); }
          clearVideoPending(id);
          if (adoptedAlias[id] != null) clearVideoPending(adoptedAlias[id]);
          videoLocked.add(id);
        }
        sw.n = 0;
        noteAttachMiss(false);
        vstat("watcher sent " + n + " staged demo clip(s) in the open chat ✓");
        ask({ type: "LOG_EVENT", entry: { thread: safe(() => (document.title || "").replace(/\s*[|·—-]\s*Messenger.*$/i, "").trim(), "") || id, threadId: id, buyer: "(demo video)", action: "video", reply: n + " staged demo clip(s) sent by the watcher (upload had finished, nobody had pressed send)" } });
      } else if (sw.n >= 12) {
        sw.mutedUntil = now + 6 * 3600 * 1000;
        sw.n = 0;
        vstat("watcher: a staged clip in the open chat would not send after 12 tries — leaving it (check the chat)");
      }
    } catch (e) { /* the watcher must never break the scan */ }
  }
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState !== "visible" || busy) return;
    busy = true; busySince = Date.now();
    sweepStagedClip("visible").catch(() => { /* logged inside */ }).then(() => { busy = false; busySince = 0; });
  });
  // After a streamed send: let a QUEUED Enter (pressed mid-upload) fire — never
  // touch the tray while a progressbar is visible — then clear whatever is left.
  // A tile still there once the send has cleared is a late-rendered stray from an
  // earlier attempt; adopting it into the NEXT clip's message is how a buyer got
  // the same clip twice, so it is removed. (No second send attempt here: the
  // v0.12.3 law — attach + one send attempt = delivered; retries on a false "not
  // sent" were the original duplicate-video bug.) Only an unremovable tile is
  // carried as "known" (it rides the next Enter). Returns the tiles left.
  async function settleTrayAfterSend(tid) {
    const t0 = Date.now();
    while (Date.now() - t0 < 90000 && trayUploads() > 0) {
      if (tid && !stillOnThread(tid)) return trayRemoveBtns().length;
      await sleep(1000);
    }
    // Still uploading after 90 s (a big clip on a slow uplink) with the Enter
    // queued behind it: NEVER sweep — carry it as known; the queued Enter delivers
    // it and trimTraySurplus keeps the next Enter exact.
    if (trayUploads() > 0) return trayRemoveBtns().length;
    const t1 = Date.now();
    while (Date.now() - t1 < 6000 && trayRemoveBtns().length > 0) await sleep(500);
    if (trayRemoveBtns().length > 0 && !(tid && !stillOnThread(tid))) await sweepTrayExtras(0);
    return trayRemoveBtns().length;
  }
  // Belt-and-suspenders: does THIS open chat already show a video on our side?
  // A sent video renders as a thumbnail with a play button and a small duration
  // badge ("0:16"). Facebook renders that badge as a plain overlay span (NOT a
  // [dir="auto"] text node) and shows no real <video> element until you press play
  // — so we must scan broadly for the badge, not just [dir="auto"]. If the
  // persistent "already sent" flag is ever lost, this still stops us re-sending.
  function chatAlreadyHasOurVideo() {
    const main = getMain();
    const composer = findComposer();
    if (!main || !composer) return false;

    // NOTE (audit 2026-07-29): the old check (0) — matching Facebook's "Add video to
    // listing / Update listing" card TEXT anywhere in [role=main] — was a confirmed
    // FALSE-POSITIVE: FB shows that card/nudge in conversations where we never sent
    // a video, so every fresh chat was marked done-without-sending ("videos not
    // sending at all", fleet-wide after the storage-wiping reinstall). REMOVED.
    // Only the strong, row-scoped signals below may declare a chat served.
    const c = safe(() => composer.getBoundingClientRect(), null);
    if (!c) return false;
    const top = c.top;
    const mid = c.left + c.width / 2; // column midpoint (NOT window center — panel-proof)
    // (a) An actual <video> element on our side (present once the clip renders).
    // Hardened (audit 2026-08-09): the old test degraded to `center-x > composer
    // midpoint` because looksLikeOurBubble() is null for unpainted media wrappers —
    // an autoplaying LISTING clip (shared listing / collapsed listing header inside
    // a [role=row] in GROUP threads) or a buyer clip in a narrow window then marked
    // text-only chats "already sent" (operator screenshot: Jing Jr.). Now:
    // message-media size floor, listing-link exclusion, and side decided by
    // RIGHT-ANCHORING against the ROW rect (our bubbles are flush-right; buyer
    // media is gutter-inset left) — never against the composer's toolbar-inset box.
    const vids = safe(() => Array.from(main.querySelectorAll('[role="row"] video')), []);
    for (const v of vids) {
      const r = safe(() => v.getBoundingClientRect(), null);
      if (!r || r.top >= top || r.width < 80 || r.height < 80) continue;
      if (safe(() => v.closest('a[href*="/marketplace/"]'), null)) continue; // inside a listing link
      const rowEl0 = safe(() => v.closest('[role="row"]'), null);
      if (!rowEl0) continue;
      if (safe(() => rowEl0.querySelector('a[href*="/marketplace/"]'), null)) continue; // row carries a listing link
      const paint = looksLikeOurBubble(v);
      if (paint === false) continue; // painted gray → the buyer's
      if (paint === true) return true; // painted blue/gradient → ours
      const rowR = safe(() => rowEl0.getBoundingClientRect(), null);
      if (!rowR) continue;
      const rightGap = rowR.right - r.right, leftGap = r.left - rowR.left;
      if (rightGap <= 64 && leftGap > rightGap + 40) return true; // flush-right in its row → ours
    }
    // (b) The duration badge ("0:16", "1:03"). It's a small overlay element on the
    //     thumbnail — usually NOT [dir="auto"] — so scan every leaf element in the
    //     message rows for one whose OWN text is exactly mm:ss and is badge-sized.
    const leaves = safe(() => Array.from(main.querySelectorAll('[role="row"] span, [role="row"] div')), []);
    for (const n of leaves) {
      if (n.childElementCount !== 0) continue; // the badge itself, not a wrapper
      // mm:ss inside [dir="auto"] is TEXT (our "5:30" reply, 24h-locale time
      // dividers like "14:32" on FR accounts) — never a duration badge. Those
      // false matches were marking fresh chats "already has video" on FR machines.
      if (safe(() => n.closest('[dir="auto"]'), null)) continue;
      const t = safe(() => (n.textContent || "").trim(), "");
      if (!/^\d{1,2}:\d{2}$/.test(t)) continue; // a video duration badge
      const r = safe(() => n.getBoundingClientRect(), null);
      if (!r || r.top >= top || r.width <= 0 || r.width > 90) continue; // small badge, in the msg area
      // A real duration badge OVERLAYS a media thumbnail. Find a large media element
      // in the same row whose rect contains the badge center, and decide the side
      // from THAT rect — never from the tiny badge rect (spoofable by buyer
      // voice-note durations and buyer clips in narrow windows/panel-open layouts).
      const rowEl = safe(() => n.closest('[role="row"]'), null);
      if (!rowEl) continue;
      // Hardened (audit 2026-08-10): listing-link exclusions + side decided by
      // paint or ROW-rect right-anchoring on the MEDIA rect — the old composer-
      // midpoint test with null-paint pass-through matched listing/buyer media.
      if (safe(() => n.closest('a[href*="/marketplace/"]'), null)) continue; // badge inside a listing link
      if (safe(() => rowEl.querySelector('a[href*="/marketplace/"]'), null)) continue; // row carries a listing link
      const rowR = safe(() => rowEl.getBoundingClientRect(), null);
      if (!rowR) continue;
      const bcx = r.left + r.width / 2, bcy = r.top + r.height / 2;
      const medias = safe(() => Array.from(rowEl.querySelectorAll('video, img, [style*="background-image"]')), []);
      for (const mEl of medias) {
        const mr = safe(() => mEl.getBoundingClientRect(), null);
        if (!mr || mr.width < 80 || mr.height < 80) continue; // avatars/emoji/stickers are smaller
        if (bcx <= mr.left || bcx >= mr.right || bcy <= mr.top || bcy >= mr.bottom) continue; // badge not on this thumbnail
        const paint = looksLikeOurBubble(mEl);
        if (paint === false) continue; // painted gray → the buyer's
        if (paint === true) return true; // painted blue/gradient → ours
        const rightGap = rowR.right - mr.right, leftGap = mr.left - rowR.left;
        if (rightGap <= 64 && leftGap > rightGap + 40) return true; // flush-right in its row → ours
      }
    }
    return false;
  }

  // (v0.21.53) RENDER-INDEPENDENT "a video of ours is already in this chat".
  // chatAlreadyHasOurVideo() above is entirely GEOMETRIC: it needs a >=80x80 media
  // rect, a duration badge whose centre lies inside it, and a row-rect
  // right-anchoring test. This fleet's Messenger tabs are hidden/minimized nearly
  // all the time; Chrome then does not lay the page out and every
  // getBoundingClientRect() degrades — so the detector answered "no video" for
  // EIGHTEEN chats whose own sidebar row read "You sent a video." (PC-1zysp,
  // 2026-09-17: chat-seen=0 chat-unseen=18, eight rows saying exactly that, and
  // the Activity log carrying "1/1 demo video(s) sent" for them).
  // Facebook writes that snippet itself, as TEXT, with no layout involved — so it
  // survives a hidden tab. POSITIVE-ONLY evidence: a match means a video of ours
  // is in that chat; no match means nothing (the buyer may have written since).
  // Only "video" wording counts — "You sent a photo." must never match.
  const WE_SENT_VIDEO_RE = /\byou sent a video\b|\bvous avez envoy[ée]e? une vid[ée]o\b/i;
  function rowText(a) {
    // innerText is the RENDERED text and can come back empty on an unrendered
    // tab; textContent is parsed from the DOM and always there.
    const t = safe(() => a.innerText || "", "");
    return t || safe(() => a.textContent || "", "");
  }
  function sidebarSaysWeSentVideo(id, sidebarKey) {
    if (!id && !sidebarKey) return false;
    const want = new Set([id, sidebarKey, adoptedAlias[id], adoptedAlias[sidebarKey]].filter(Boolean));
    for (const a of safe(() => conversationAnchors(), [])) {
      const rid = threadId(a);
      if (!rid || !want.has(rid)) continue;
      if (WE_SENT_VIDEO_RE.test(rowText(a))) return true;
    }
    // (v0.21.71) …or it said so at an earlier scan (the words vanish from the row
    // the moment the buyer writes back; the scan loop remembers them 30 days).
    const nowS = Date.now();
    for (const k of want) {
      const at = sidebarVideoSeen[k];
      if (typeof at === "number" && nowS - at < 30 * 24 * 3600 * 1000) return true;
    }
    return false;
  }
  // The union of both signals: geometry when the page is actually rendered,
  // Facebook's own words when it is not.
  function chatServedVideo(id, sidebarKey) {
    return safe(chatAlreadyHasOurVideo, false) || sidebarSaysWeSentVideo(id, sidebarKey);
  }

  // FROZEN pre-2026-08-10 <video>-branch detector (v0.21.10-13 behavior) — used
  // ONLY by the false-mark divergence probe in maybeSendVideo: if THIS fires while
  // the hardened detector does not, the false-positive source of an old mark is
  // identified live in the DOM and the mark is safe to clear. Never marks chats.
  function legacyChatVideoDetect() {
    const main = getMain();
    const composer = findComposer();
    if (!main || !composer) return false;
    const c = safe(() => composer.getBoundingClientRect(), null);
    if (!c) return false;
    const top = c.top;
    const mid = c.left + c.width / 2;
    const vids = safe(() => Array.from(main.querySelectorAll('[role="row"] video')), []);
    for (const v of vids) {
      const r = safe(() => v.getBoundingClientRect(), null);
      if (!r || r.top >= top || r.width <= 0) continue;
      if (!safe(() => v.closest('[role="row"]'), null)) continue;
      const paint = looksLikeOurBubble(v);
      if (paint === true) return true;
      if (paint !== false && r.left + r.width / 2 > mid) return true;
    }
    return false;
  }
  const VIDEO_DETECTOR_FIX_TS = Date.parse("2026-08-10T00:00:00Z"); // marks written before this used the weaker <video> branch
  const BADGE_FIX_TS = Date.parse("2026-08-10T06:00:00Z"); // marks written before this may come from the buggy badge branch

  // FROZEN pre-fix BADGE-branch detector (composer-midpoint side test with
  // null-paint pass-through — the FP source until 2026-08-10). Used ONLY by the
  // divergence probe: firing while the hardened detector stays silent identifies
  // a false mark's source live in the DOM. Never marks chats.
  function legacyBadgeDetect() {
    const main = getMain();
    const composer = findComposer();
    if (!main || !composer) return false;
    const c = safe(() => composer.getBoundingClientRect(), null);
    if (!c) return false;
    const top = c.top;
    const mid = c.left + c.width / 2;
    const leaves = safe(() => Array.from(main.querySelectorAll('[role="row"] span, [role="row"] div')), []);
    for (const n of leaves) {
      if (n.childElementCount !== 0) continue;
      if (safe(() => n.closest('[dir="auto"]'), null)) continue;
      const t = safe(() => (n.textContent || "").trim(), "");
      if (!/^\d{1,2}:\d{2}$/.test(t)) continue;
      const r = safe(() => n.getBoundingClientRect(), null);
      if (!r || r.top >= top || r.width <= 0 || r.width > 90) continue;
      const rowEl = safe(() => n.closest('[role="row"]'), null);
      if (!rowEl) continue;
      const bcx = r.left + r.width / 2, bcy = r.top + r.height / 2;
      const medias = safe(() => Array.from(rowEl.querySelectorAll('video, img, [style*="background-image"]')), []);
      for (const mEl of medias) {
        const mr = safe(() => mEl.getBoundingClientRect(), null);
        if (!mr || mr.width < 80 || mr.height < 80) continue;
        if (bcx <= mr.left || bcx >= mr.right || bcy <= mr.top || bcy >= mr.bottom) continue;
        if (looksLikeOurBubble(mEl) !== false && mr.left + mr.width / 2 > mid) return true;
      }
    }
    return false;
  }

  // Send the stored demo video(s) to the current chat — ONCE per chat, a set delay
  // after the text reply (default 10s). Supports MULTIPLE videos, sent in order.
  // Demo-video state machine. Goal: send the configured clip(s) EXACTLY once per chat
  // (with the first-video delay + the between-videos delay), CONFIRM they actually
  // landed, RETRY later if a send genuinely failed (backoff, capped — no spam), and
  // NEVER resend once a video is confirmed in the chat.
  // ---- Chrome FILE API attach (v0.21.36): real files via the debugger protocol ----
  // See background.js cdpSetFiles(). A hard failure parks the path for a while so a
  // machine without the permission/file access doesn't burn seconds on every clip.
  let cdpDisabledUntil = 0;
  let cdpStrikes = 0; // consecutive TRANSIENT misses (input not found / no preview)
  let cdpInputMissRounds = 0; // (v0.21.53) escalating park while the composer input stays missing; any verified attach resets it
  let cdpSetToken = 0; // bumped per video set; a miss skips the file API for the REST of that set only
  let cdpFailedSetToken = -1;
  const cdpAvailable = () => Date.now() > cdpDisabledUntil;
  const cdpUsableNow = () => cdpAvailable() && cdpFailedSetToken !== cdpSetToken;
  // (v0.21.41) Parks are ROUTING decisions (file API vs. paste), never delivery
  // decisions — so they are short: a failed file-API call costs well under a
  // second, while a park sends every clip down the minutes-long synthetic ladder.
  function noteCdpFail(r) {
    const err = (r && r.error) || "no response";
    if (r && r.fileAccess === "denied") {
      cdpDisabledUntil = Date.now() + 15 * 60 * 1000; // re-probed every 15 min so a flipped toggle is picked up within the shift
      vstat("file API blocked: turn ON 'Allow access to file URLs' for SubSell in chrome://extensions — using fallback attach");
      return;
    }
    if (r && r.missing) {
      // This clip's file is gone from disk (verified by the pre-set probe, nothing
      // touched the composer): the background re-downloads it; THIS clip goes
      // synthetic, the other clips' paths are independent and stay on the file API.
      setStatus({ videoLast: "clip file missing on disk — re-downloading; paste attach for this clip" });
      return;
    }
    if (/unavailable|permission/i.test(err)) {
      cdpDisabledUntil = Date.now() + 2 * 60 * 1000; // API not granted yet (reload pending) — the probe is free
    } else if (/input not found|no preview/i.test(err)) {
      // Transient CHAT state (composer holding a draft, stuck preview): the next
      // clip retries the file API after the tray settles; three in a row park 2 min.
      // (v0.21.53) But when the composer's input is simply GONE on this Messenger
      // build, a 2-minute park means re-probing for ever: PC-1zysp logged err=130,
      // all of them "composer file input not found", and every one of those attaches
      // the debugger and flashes the "SubSell is debugging this browser" bar across
      // the operator's desktop. Park in steps — 2 min, then 10, then 30 — so a
      // genuinely transient state still recovers fast while a missing input goes
      // quiet and the run falls through to the drop rescue / the link.
      if (++cdpStrikes >= 3) {
        cdpStrikes = 0;
        cdpInputMissRounds = Math.min((cdpInputMissRounds || 0) + 1, 3);
        cdpDisabledUntil = Date.now() + [2, 10, 30][cdpInputMissRounds - 1] * 60 * 1000;
      }
    } else if (/message port closed|could not establish connection|receiving end does not exist|^no response$/i.test(err)) {
      cdpFailedSetToken = cdpSetToken; // background restart: nothing reached the composer — retry next set
    } else {
      cdpDisabledUntil = Date.now() + 2 * 60 * 1000; // attach/detach/timeout/protocol errors
    }
    setStatus({ videoLast: "file API attach failed: " + trunc(err, 80) + " — falling back to paste" });
  }
  // ATTACH CHANNEL PREFERENCE (v0.21.45): the channel that last produced a VISIBLE
  // clip on this machine (drop / chooser / input / paste). Learned per machine;
  // forgotten after 3 sets in a row with no tile, or 3 sets with no video visible
  // in the chat — the channels are then tried in turn again.
  async function getAttachPref() {
    const p = (await getLocal(["attachPref"])).attachPref;
    return p && p.channel ? p : null;
  }
  async function rememberAttachPref(channel) {
    const p = (await getLocal(["attachPref"])).attachPref || {};
    await setLocal({ attachPref: { channel, at: Date.now(), hits: (p.channel === channel ? (p.hits || 0) : 0) + 1, misses: 0 } });
  }
  async function notePrefMiss() {
    const p = (await getLocal(["attachPref"])).attachPref;
    if (!p || !p.channel) return;
    const misses = (p.misses || 0) + 1;
    if (misses >= 3) { await setLocal({ attachPref: null }); setStatus({ videoLast: "attach channel '" + p.channel + "' stopped showing clips — re-learning" }); }
    else await setLocal({ attachPref: Object.assign({}, p, { misses }) });
  }
  // (v0.21.57) Messenger's own attach control, found the same way the page-world
  // finder does it: a labelled button inside the composer bar's subtree, in the
  // composer's horizontal band. "more" marks the compact "+" menu, whose attach
  // item is found by findAttachMenuItem after it opens.
  const ATTACH_RE = /attach|joindre|jointe|fichier|pi[èe]ce|\bfile\b|photo|m[ée]dia|upload|t[ée]l[ée]vers|image|vid[ée]o/i;
  const ATTACH_BAD_RE = /sticker|autocollant|gif|emoji|like|j'?aime|pouce|thumb|voice|vocal|audio|micro|record|enregistr|press enter|entr[eé]e pour|^send$|^envoyer$|listing|annonce|call|appel/i;
  const ATTACH_MORE_RE = /more actions|plus d.actions|ouvrir plus|open more|more options|plus d.options/i;
  let lastShimFired = 0, lastShimSeen = 0, lastShimInfo = null;
  // (v0.21.67) the last activation pulse this tab asked for (an opt-in experiment),
  // the last reaction-probe code (see background pageArmReactionProbe) and whether
  // the last attach ended "held" — for the 🩺 and for the engine's routing.
  let lastActPulse = null;
  let lastAttachRx = "-";
  let lastAttachHeld = false;
  let lastAttachDupOf = ""; // (v0.21.77) "clipK" = the probe saw clip K's bytes handed over, never this clip's
  const userActivated = () => safe(() => !!(navigator.userActivation && navigator.userActivation.hasBeenActive), false);
  const rxCode = (s) => (s && s.armed !== undefined && s.objUrl !== undefined
    ? "o" + (s.objUrl || 0) + "v" + (s.vidSrc || 0) + "m" + (s.meta || 0) + "e" + (s.err || 0) + "r" + (s.read || 0) + "u" + (s.up || 0)
    : "-");
  // Messenger tried OUR clip and its decode FAILED (a media error, no metadata): the
  // clip was rejected, not held — the next channel is duplicate-safe.
  const rxRejected = (s) => !!s && (s.err || 0) > 0 && (s.meta || 0) === 0;
  // Messenger HOLDS our clip: an object URL for it, its metadata decoded, an upload
  // body, or repeated byte reads. One lone read (a header sniff) is telemetry only.
  const rxHeld = (s) => !!s && !rxRejected(s) && ((s.objUrl || 0) > 0 || (s.meta || 0) > 0 || (s.up || 0) > 0 || (s.read || 0) >= 2);

  // ---- (v0.21.67) THE MEDIA GATE ----
  // Chrome PARKS every media load of a page that is HIDDEN and has NEVER PLAYED
  // MEDIA (prerender::DeferMediaLoad, reached through ChromeContentRendererClient::
  // DeferMediaLoad on every desktop build; released only when the page is shown or
  // when the frame has played media before — user activation is not a term of it).
  // Messenger decodes a clip through a <video> on a blob: URL before it stages the
  // attachment, so on such a page every hand-over is accepted and parked: nothing
  // staged, nothing to see, and the next channel adds another copy (PC-qwafy: five
  // channels, 261 hand-overs, the send control never left "send a like", doctor
  // vis=hidden/focus; the .58 photo: seven tiles surfacing at once when the operator
  // finally connected). Two things, both inside this frame, no debugger, no UI:
  //  - mediaGateOpen(): loads a 52-byte silent WAV in an <audio>. loadedmetadata (or
  //    error) within the wait means loads run; silence means they are parked.
  //  - primeMedia(): plays a MediaStream in a muted element. A MediaStream player is
  //    built without the defer callback, and its play() marks the FRAME as having
  //    played media — after which every later clip load in this document runs,
  //    hidden or not. Proven by re-probing the gate, never assumed.
  const TINY_WAV_URL = (() => {
    try {
      const n = 8, b = new Uint8Array(44 + n);
      const w = (o, s) => { for (let i = 0; i < s.length; i++) b[o + i] = s.charCodeAt(i); };
      const u32 = (o, v) => { b[o] = v & 255; b[o + 1] = (v >> 8) & 255; b[o + 2] = (v >> 16) & 255; b[o + 3] = (v >>> 24) & 255; };
      const u16 = (o, v) => { b[o] = v & 255; b[o + 1] = (v >> 8) & 255; };
      w(0, "RIFF"); u32(4, 36 + n); w(8, "WAVE"); w(12, "fmt "); u32(16, 16); u16(20, 1); u16(22, 1); u32(24, 8000); u32(28, 8000); u16(32, 1); u16(34, 8); w(36, "data"); u32(40, n);
      for (let i = 0; i < n; i++) b[44 + i] = 128;
      let s = ""; for (let i = 0; i < b.length; i++) s += String.fromCharCode(b[i]);
      return "data:audio/wav;base64," + btoa(s);
    } catch (e) { return ""; }
  })();
  const mediaGate = { state: "?", at: 0, primed: "-", probes: 0, primes: 0, provenHidden: false }; // this document's gate, as last probed
  const hideEl = (el) => { try { el.setAttribute("aria-hidden", "true"); el.style.cssText = "position:fixed;left:-9999px;top:-9999px;width:2px;height:2px;opacity:0;pointer-events:none;"; } catch (e) { /* cosmetic */ } };
  // true = a media load completed (loads run), false = nothing happened within the
  // wait (parked), null = could not probe.
  async function mediaGateOpen(waitMs) {
    if (!TINY_WAV_URL) return null;
    let a = null;
    try {
      a = document.createElement("audio");
      a.muted = true; a.preload = "auto";
      const done = new Promise((res) => {
        a.addEventListener("loadedmetadata", () => res(true), { once: true });
        a.addEventListener("error", () => res(true), { once: true }); // an error is a load that RAN
      });
      a.src = TINY_WAV_URL;
      try { a.load(); } catch (e) { /* ignore */ }
      mediaGate.probes++;
      return await Promise.race([done, sleep(waitMs || 3000).then(() => false)]);
    } catch (e) { return null; }
    finally { try { if (a) { a.removeAttribute("src"); a.load(); } } catch (e) { /* ignore */ } }
  }
  const primeEls = [];
  let primeCtx = null;
  // Returns how the frame was made to play media ("stream-audio" | "stream-canvas"),
  // or "-". With verify=true only a re-probed OPEN gate counts as success.
  async function primeMedia(verify) {
    const parent = document.body || document.documentElement;
    const played = async (el) => {
      let ok = false;
      try { ok = await Promise.race([Promise.resolve(el.play()).then(() => true, () => false), sleep(3000).then(() => false)]); } catch (e) { ok = false; }
      return ok || safe(() => el.paused === false, false);
    };
    const proven = async () => (verify ? !!(await mediaGateOpen(3000)) : true);
    // (a) an audio-only MediaStream: needs no frames and no gesture (muted)
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) {
        if (!primeCtx) primeCtx = new AC();
        const dest = primeCtx.createMediaStreamDestination();
        const el = document.createElement("audio");
        el.muted = true; hideEl(el);
        el.srcObject = dest.stream;
        parent.appendChild(el); primeEls.push(el);
        if ((await played(el)) && (await proven())) return "stream-audio";
      }
    } catch (e) { /* next */ }
    // (b) a canvas stream with a frame requested by hand (no rendering needed)
    try {
      const cv = document.createElement("canvas"); cv.width = 16; cv.height = 16;
      const g = cv.getContext("2d"); if (g) { g.fillStyle = "#000"; g.fillRect(0, 0, 16, 16); }
      if (cv.captureStream) {
        const stream = cv.captureStream(0);
        const track = stream.getVideoTracks()[0];
        const v = document.createElement("video");
        v.muted = true; v.playsInline = true; hideEl(v);
        v.srcObject = stream;
        parent.appendChild(v); primeEls.push(v);
        const frame = () => { try { if (g) g.fillRect(0, 0, 1, 1); if (track && track.requestFrame) track.requestFrame(); } catch (e) { /* ignore */ } };
        frame();
        const pl = played(v);
        frame();
        if ((await pl) && (await proven())) return "stream-canvas";
      }
    } catch (e) { /* give up */ }
    return "-";
  }
  let mediaGateBusy = null;
  // Once per document: probe while hidden, prime when parked (re-tried every 10 min
  // while it stays closed). On a visible page loads run anyway — prime unverified so
  // they still run later, when the page is hidden; the first hidden probe proves it.
  async function ensureMediaGate() {
    if (mediaGateBusy) return mediaGateBusy;
    // The runner may return synchronously (gate already decided): the busy slot is
    // therefore cleared by THIS frame after awaiting it, never inside the runner —
    // a runner-side clear ran before the slot was even assigned and froze it for good.
    const run = mediaGateRun();
    mediaGateBusy = run;
    try { await run; } finally { if (mediaGateBusy === run) mediaGateBusy = null; }
  }
  async function mediaGateRun() {
    {
      try {
        const now = Date.now();
        const hidden = document.visibilityState !== "visible";
        if (mediaGate.state === "open" && mediaGate.provenHidden) return;
        if (mediaGate.state === "closed" && now - mediaGate.at < 10 * 60 * 1000) return;
        if (!hidden) {
          if (mediaGate.primed === "-") { mediaGate.primes++; mediaGate.primed = await primeMedia(false); }
          mediaGate.state = "open"; mediaGate.at = Date.now();
          return;
        }
        const open = await mediaGateOpen(3000);
        mediaGate.at = Date.now();
        if (open === null) { mediaGate.state = "?"; return; }
        if (open) { mediaGate.state = "open"; mediaGate.provenHidden = true; return; }
        mediaGate.state = "closed"; mediaGate.primes++;
        setStatus({ lastAction: "this page's media loads are parked (hidden tab) — priming it so the clip can load…" });
        const how = await primeMedia(true);
        mediaGate.at = Date.now();
        if (how !== "-") {
          mediaGate.primed = how; mediaGate.state = "open"; mediaGate.provenHidden = true;
          setStatus({ videoLast: "media gate opened (" + how + ") — clips can load on this hidden tab now" });
        } else {
          mediaGate.primed = "-";
          setStatus({ videoLast: "media gate still closed after priming — this window must be shown once for clips to load" });
        }
      } catch (e) { /* diagnostics must never disturb the bot */ }
      finally {
        safe(() => chrome.storage.local.set({ videoMediaGate: { state: mediaGate.state, at: mediaGate.at, primed: mediaGate.primed, probes: mediaGate.probes, primes: mediaGate.primes, hidden: mediaGate.provenHidden, vis: document.visibilityState } }, () => void chrome.runtime.lastError));
      }
    }
  }
  function findAttachControl() {
    const main = getMain();
    const c = findComposer();
    if (!main || !c) return null;
    const cr = safe(() => c.getBoundingClientRect(), null);
    if (!cr) return null;
    const up = [];
    for (let nEl = c.parentElement, i = 0; nEl && nEl !== main && i < 8; nEl = nEl.parentElement, i++) up.push(nEl);
    let best = null, moreBtn = null;
    for (const b of safe(() => Array.from(main.querySelectorAll('[role="button"][aria-label], button[aria-label]')), [])) {
      if (!up.some((u) => u.contains(b))) continue;
      const r = safe(() => b.getBoundingClientRect(), null);
      if (!r || !r.width || !r.height) continue;
      if (r.bottom < cr.top - 60 || r.top > cr.bottom + 60) continue;
      const al = safe(() => b.getAttribute("aria-label"), "") || "";
      if (ATTACH_MORE_RE.test(al)) { if (!moreBtn) moreBtn = b; continue; }
      if (!ATTACH_RE.test(al) || ATTACH_BAD_RE.test(al)) continue;
      if (!best || r.left < safe(() => best.getBoundingClientRect().left, 1e9)) best = b;
    }
    if (best) return { el: best, more: false };
    return moreBtn ? { el: moreBtn, more: true } : null;
  }
  function findAttachMenuItem() {
    for (const root of safe(() => Array.from(document.querySelectorAll('[role="menu"], [role="dialog"], [role="listbox"]')), [])) {
      for (const it of safe(() => Array.from(root.querySelectorAll('[role="menuitem"], [role="menuitemradio"], [role="option"], [role="button"]')), [])) {
        const t = ((safe(() => it.getAttribute("aria-label"), "") || "") + " " + (safe(() => it.innerText, "") || "")).trim();
        if (!ATTACH_RE.test(t) || ATTACH_BAD_RE.test(t)) continue;
        const r = safe(() => it.getBoundingClientRect(), null);
        if (r && r.width && r.height) return it;
      }
    }
    return null;
  }

  // (v0.21.47) Per-channel outcome counters for the 🩺 line: how often each
  // channel dispatched, showed a tile, flipped the send control (blind), showed
  // nothing (none) or could not be judged (unverified). Fire-and-forget.
  // (v0.21.67) SERIALISED: two back-to-back read-modify-writes on this key used to
  // race (both reads saw the old value, the second write won) — the rx/held fields
  // were lost on every escalating step. One promise chain, still fire-and-forget.
  let channelStatsQ = Promise.resolve();
  function bumpChannelStats(ch, mutate) {
    channelStatsQ = channelStatsQ.then(() => new Promise((res) => {
      const ok = safe(() => {
        chrome.storage.local.get(["attachChannelStats"], (r) => {
          if (chrome.runtime.lastError) return res();
          const all = (r && r.attachChannelStats) || {};
          const e = all[ch] || {};
          try { mutate(e); } catch (x) { /* bookkeeping only */ }
          all[ch] = e;
          chrome.storage.local.set({ attachChannelStats: all }, () => { void chrome.runtime.lastError; res(); });
        });
        return true;
      }, false);
      if (!ok) res();
    })).catch(() => { /* never breaks the chain */ });
  }
  function noteChannelStat(ch, outcome) {
    bumpChannelStats(ch, (e) => { e[outcome] = (e[outcome] || 0) + 1; e.at = Date.now(); });
  }
  // (v0.21.67) The last reaction-probe code per channel (+ how often the channel
  // ended "held": Messenger read the clip but never staged it that time).
  function noteChannelRx(ch, code, held) {
    bumpChannelStats(ch, (e) => { e.rx = String(code || "-").slice(0, 24); e.rxAt = Date.now(); if (held) e.held = (e.held || 0) + 1; });
  }
  // Machine-wide attach health (see attachMiss): a set with zero confirmed clips
  // extends the streak, any confirmed clip resets it.
  async function noteAttachMiss(zeroEvidence) {
    attachMiss = zeroEvidence ? { streak: (attachMiss.streak || 0) + 1, at: Date.now() } : { streak: 0, at: Date.now() };
    await setLocal({ attachMiss });
  }
  // GROUND-TRUTH outcome of a finished set (v0.21.43): seen = a video of ours is
  // visible in the chat after the send. Three unseen in a row ⇒ the learned
  // attach channel is forgotten (the next set tries the channels again).
  let unseenStreak = 0;
  async function noteSetOutcome(seen, via, id, name) {
    ask({ type: "VIDEO_SEEN", seen: !!seen, via: via || "-" });
    if (seen) { unseenStreak = 0; return; }
    unseenStreak++;
    vstat("set sent per protocol but NO video visible yet in " + (name || id) + " (" + unseenStreak + " in a row)");
    if (unseenStreak < 3) return;
    unseenStreak = 0;
    await setLocal({ attachPref: null });
    setStatus({ videoLast: "no video visible in 3 chats in a row (via " + (via || "-") + ") — re-learning the attach channel" });
    try {
      const thrAt = (await getLocal(["videoUnseenLoggedAt"])).videoUnseenLoggedAt || 0;
      if (Date.now() - thrAt > 24 * 3600 * 1000) {
        await setLocal({ videoUnseenLoggedAt: Date.now() });
        ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: "(video check)", action: "video-status", reply: "3 sets in a row sent per protocol but no video visible in the chat — attach channel (" + (via || "-") + ") not taking on this machine; switched channel" } });
      }
    } catch (e) { /* telemetry only */ }
  }
  let lastCdpVerifiedAt = 0;
  // Seed from the persisted stats so a content-script reload on a healthy machine
  // doesn't start in "unproven" mode (rush mode would queue videos needlessly).
  getLocal(["cdpStats"]).then((r) => {
    const t = r && r.cdpStats && r.cdpStats.lastVerifiedAt;
    if (t && t > lastCdpVerifiedAt) lastCdpVerifiedAt = t;
  });
  // "Healthy" = a file-API attach was VERIFIED (preview appeared) within the last
  // 2 h on this machine — the signal that an attach will cost seconds, not minutes.
  // (Hard parks only — the per-set skip token is meaningless outside a set.)
  const cdpRecentlyHealthy = () => cdpAvailable() && Date.now() - lastCdpVerifiedAt < 2 * 3600 * 1000;
  // Rush must not starve its own health signal: noteCdpVerified() only fires inside
  // the attach path, which rush skips — so once the 2 h window lapsed (overnight),
  // a HEALTHY machine could never leave rush while ≥3 buyers wait. While unproven
  // but usable, let ONE videos-first probe visit through every 10 min: a healthy
  // attach verifies in seconds and restores videos-first for 2 h; an unhealthy
  // machine pays at most one slow visit per 10 min.
  let lastRushProbeAt = 0;
  const RUSH_PROBE_EVERY_MS = 10 * 60 * 1000;
  function rushProbeDue() {
    if (!cdpUsableNow()) return false;
    if (Date.now() - lastRushProbeAt <= RUSH_PROBE_EVERY_MS) return false;
    lastRushProbeAt = Date.now();
    return true;
  }
  function noteCdpVerified(blind) {
    cdpStrikes = 0;
    cdpInputMissRounds = 0; // (v0.21.53) the composer input is back — drop the escalating park
    cdpUnverifiedStreak = 0;
    lastCdpVerifiedAt = Date.now();
    ask({ type: "CDP_VERIFIED", blind: !!blind }); // fire-and-forget telemetry ("protocol ok" ≠ "clip staged")
  }
  // The browser accepted a file-API set but the composer showed NOTHING (no tile,
  // no staged signal) for the whole window. One miss is a chat/layout quirk; two
  // in a row mean this machine's composer is not taking file-API sets right now
  // (wrong input on a new layout, frozen renderer…): park the file API 30 min so
  // the synthetic strategies get their turn, then re-probe. A verified attach
  // resets the streak. Telemetry: the 🩺 fileapi line shows unverified=N.
  let cdpUnverifiedStreak = 0;
  function noteCdpUnverified() {
    ask({ type: "CDP_UNVERIFIED" });
    if (++cdpUnverifiedStreak >= 3) {
      cdpUnverifiedStreak = 0;
      cdpDisabledUntil = Date.now() + 5 * 60 * 1000;
      setStatus({ videoLast: "file API sets are not showing up in the composer on this machine — paste attach for 5 min" });
    }
  }
  // Absolute on-disk path for a clip (background downloads it once per machine).
  // null = no path → that clip uses the synthetic strategies. Successes are memoized
  // only briefly (2 min) so a deleted file is re-validated by the background (it
  // re-checks `exists`); failures are remembered 15 min so we don't re-ask per clip.
  const diskPathMem = {};
  const diskSizeByPath = {}; // absolute path -> byte size (from the download record)
  let diskFailStreak = 0;
  function forgetDiskPaths(paths) {
    for (const k of Object.keys(diskPathMem)) {
      const e = diskPathMem[k];
      if (!paths || (e && e.path && paths.includes(e.path))) delete diskPathMem[k];
    }
  }
  // (v0.21.41) no longer gated on the file-API park: the disk cache stays warm
  // while parked, so lifting a park is never a cold start.
  async function diskPathFor(req) {
    const key = req.url || "local:" + (req.name || "") + ":" + ((req.dataUrl && req.dataUrl.length) || 0);
    const m = diskPathMem[key];
    if (m && Date.now() - m.at < (m.path ? 2 * 60 * 1000 : (m.ttl || 5 * 60 * 1000))) return m.path;
    try {
      // Per-clip time budget: the background keeps the download running past it
      // and persists the id, so the NEXT visit adopts the file — this visit falls back.
      const r = await Promise.race([
        ask(Object.assign({ type: "VIDEO_DISK_PATH" }, req)),
        sleep(60000).then(() => ({ ok: false, error: "disk path lookup timed out (download still running)" })),
      ]);
      if (r && r.ok && r.path) {
        diskFailStreak = 0;
        diskPathMem[key] = { path: r.path, at: Date.now() };
        if (r.size > 0) diskSizeByPath[r.path] = r.size; // (v0.21.67) the reaction probe recognises our clip by its size
        return r.path;
      }
      // A SOFT miss (download still running / lookup timed out) is re-asked in
      // 30 s and never counts toward the park; hard misses are remembered 5 min.
      const soft = /still downloading|timed out/i.test((r && r.error) || "");
      diskPathMem[key] = { path: null, at: Date.now(), ttl: soft ? 30 * 1000 : 5 * 60 * 1000 };
      if (!soft && ++diskFailStreak >= 6) { diskFailStreak = 0; cdpDisabledUntil = Date.now() + 5 * 60 * 1000; } // this machine can't stage clips on disk right now
      setStatus({ videoLast: "clip not on disk yet: " + trunc((r && r.error) || "?", 60) + " — paste attach this time" });
    } catch (e) { /* fall back */ }
    return null;
  }
  const VIDEO_CLAIM_TTL = 3 * 60 * 1000; // an in-flight claim older than this is stale
  // A via:"lock" stamp younger than this = a set being sent RIGHT NOW in some pass.
  // ONE constant for the engine's wait, the scan-time resume rescue and the
  // catch-up arm (they disagreed: 10 vs 30 min — a crashed set sat 30 min).
  const VIDEO_INFLIGHT_MS = 10 * 60 * 1000;
  // (v0.21.40, operator: "remove all blocks — send any video you can") the only
  // pacing left on a chat whose clips fail to load/attach is this short backoff;
  // there is NO 24h pause and NO give-up count any more. `fails` is still counted
  // (diagnostic), the pending lane's own per-chat retry spacing bounds the cost.
  const VIDEO_RETRY_BACKOFF = 3 * 60 * 1000; // wait this long before retrying a failed ATTACH
  const VIDEO_MAX_TRIES = 3; // telemetry threshold only ("attachFails3+" in 🩺) — never blocks
  // A LOAD failure (clip not downloadable yet) usually clears within a minute.
  const backoffFor = (att) => (att && att.why === "struck" ? 15 * 60 * 1000 : att && att.why === "load" ? 60 * 1000 : VIDEO_RETRY_BACKOFF);
  // Synchronous, in-memory guard: threadIds this content-script instance has already
  // committed a video to. Checked with ZERO awaits at the very top of maybeSendVideo,
  // so even if chrome.storage writes lag, a chat can't be sent to twice in one session.
  const videoLocked = new Set();
  async function recordVideoFail(id, why) {
    const am = (await getLocal(["videoAttempts"])).videoAttempts || {};
    const a = am[id] || {};
    // (v0.21.47) keep the entry's other fields (blindTries — the bounded-retry count)
    am[id] = Object.assign({}, a, { fails: (a.fails || 0) + 1, failAt: Date.now(), why: why || a.why || "" });
    await setLocal({ videoAttempts: am });
  }
  // Live "why" line for the popup: every exit of the video engine reports itself, so
  // "videos not sending" is diagnosable from a screenshot instead of guesswork.
  function vstat(reason) {
    setStatus({ videoLast: reason });
    reportVideoStatus(reason); // fire-and-forget; must never block the caller
  }
  // Central video-status telemetry: mirrors MATERIAL blocked states into the existing
  // Activity feed, deduped to at most one row per reason per 24h — the dashboard now
  // NAMES the machines whose videos are blocked and why. Healthy exits never post.
  const VSTAT_CLASSES = [
    [/^videos OFF/, "cfg-off"],
    [/^no videos configured/, "cfg-none"],
    [/^couldn't read settings/, "settings-unreadable"],
    [/^loaded \d+\/\d+ clip/, "clips-load-failed"],
    [/^⚠ 0\//, "attach-failed"],
    [/^⚠ all /, "clips-all-blocked"],
    [/^skip — detected an existing video/, "dom-marked"],
    [/can't load/, "clips-excluded"],
    [/^paused 24h/, "chat-paused-24h"],
    [/^file API blocked/, "file-access-off"],
    [/^error:/, "engine-error"],
  ];
  // Machine-wide blockers: only these trigger the one-time "OK again" recovery row.
  const VSTAT_FULL_BLOCK = { "cfg-off": 1, "cfg-none": 1, "settings-unreadable": 1, "attach-failed": 1, "clips-all-blocked": 1, "engine-error": 1 };
  const VSTAT_TTL = 24 * 3600 * 1000;
  let vstatMap = null, vstatHydrating = null; // {key: lastPostedAt}, persisted
  async function reportVideoStatus(reason) {
    try {
      if (!vstatMap) {
        if (!vstatHydrating) vstatHydrating = getLocal(["videoBlockReported"]).then((r) => { vstatMap = (r && r.videoBlockReported) || {}; });
        await vstatHydrating;
      }
      const now = Date.now();
      if (/^sent ✓/.test(reason)) {
        const hadBlock = Object.keys(vstatMap).some((k) => VSTAT_FULL_BLOCK[k] && vstatMap[k] > (vstatMap.ok || 0));
        if (hadBlock && now - (vstatMap.ok || 0) > VSTAT_TTL) {
          vstatMap.ok = now;
          await setLocal({ videoBlockReported: vstatMap });
          ask({ type: "LOG_EVENT", entry: { action: "video-status", thread: null, buyer: null, reply: "videos OK again — " + reason } });
        }
        return;
      }
      let key = null;
      for (const [re, k] of VSTAT_CLASSES) if (re.test(reason)) { key = k; break; }
      if (!key) return; // normal skips/backoffs — never mirrored
      if (now - (vstatMap[key] || 0) < VSTAT_TTL) return; // deduped: no storage read, no post
      vstatMap[key] = now; // never deleted — keys re-assert at most daily, immune to flapping
      await setLocal({ videoBlockReported: vstatMap });
      ask({ type: "LOG_EVENT", entry: { action: "video-status", thread: null, buyer: null, reply: "videos blocked [" + key + "]: " + reason } });
    } catch (e) { /* telemetry must never disturb the bot */ }
  }
  // Set true when a deferSend run staged the whole set but SKIPPED the Enter so
  // the caller can put the text reply into the SAME message (one send delivers
  // videos + answer together). The caller is then responsible for firing an
  // Enter (typeAndSend, or sendAttachedVideos as fallback) in this same visit.
  let videoSendDeferred = false;
  // Called by the reply path AFTER an Enter actually shipped the staged bundle:
  // converts the owned DRAFT marker into a real sent stamp, and only THEN posts
  // the "sent ✓" status + Activity row (staging must never claim delivery). A
  // partial set keeps its tail resumable and stays on the pending queue.
  async function finalizeDeferredVideoSend(id, sidebarKey, name) {
    try {
      const dm = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
      const mk = dm[id];
      if (!mk || mk.owner !== TAB_UID || typeof mk.resumeFrom !== "number") return;
      const total = typeof mk.resumeTotal === "number" ? mk.resumeTotal : mk.resumeFrom;
      const n = mk.sent || 0;
      if (mk.resumeFrom < total) {
        // Partial set shipped with the reply — tail still owed on a later visit.
        dm[id] = { done: true, at: Date.now(), owner: TAB_UID, sent: n, resumeFrom: mk.resumeFrom, resumeTotal: total };
        await setLocal({ videoSentThreads: dm });
        await recordVideoFail(id, "attach"); // paces the tail retries
        vstat("sent " + n + "/" + total + " with the reply — finishing the rest on a later visit (" + (name || id) + ")");
        if (n > 0) ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: "(demo video)", action: "video", reply: n + "/" + total + " demo videos sent — finishing the rest later" } });
        return;
      }
      dm[id] = { done: true, at: Date.now(), owner: TAB_UID, sent: n };
      const am = (await getLocal(["videoAttempts"])).videoAttempts || {};
      if (am[id]) delete am[id];
      await setLocal({ videoSentThreads: dm, videoAttempts: am });
      videoLocked.add(id);
      clearVideoPending(id);
      if (sidebarKey && sidebarKey !== id) clearVideoPending(sidebarKey);
      vstat("sent ✓ " + n + "/" + total + " to " + (name || id) + " (with the reply)");
      if (n > 0) ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: "(demo video)", action: "video", reply: n + "/" + total + " demo video(s) sent" } });
    } catch (e) { /* bookkeeping must never break the reply path */ }
  }
  // Called when a staged draft is being ABANDONED this visit (navigation, send
  // failure): drops the in-flight via:"lock" tag so the pending-lane visit may
  // adopt and ship the draft immediately instead of waiting out the 30-min
  // in-flight window. Everything else about the marker stays honest.
  async function demoteDraftMarker(id) {
    try {
      const dm = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
      const mk = dm[id];
      if (mk && mk.owner === TAB_UID && mk.via === "lock" && typeof mk.resumeFrom === "number") {
        delete mk.via;
        mk.at = Date.now();
        dm[id] = mk;
        await setLocal({ videoSentThreads: dm });
      }
    } catch (e) { /* best-effort */ }
  }
  // (v0.21.47) VIDEO DOCTOR — read-only facts about WHY a clip cannot be staged on
  // this machine, in one line, mirrored to the central Activity feed. No clicks,
  // no files staged: it names the failing step (window hidden / no attach button /
  // click point covered / no chooser input / file access off / clip not on disk…)
  // so the next fix is aimed instead of guessed. Runs by itself after 2 sets with
  // nothing confirmed (max once per 6 h per machine) and on the popup's 🩺 probe.
  async function videoDoctor() {
    const F = [];
    const c = findComposer();
    F.push("vis=" + document.visibilityState + (safe(() => document.hasFocus(), false) ? "/focus" : "") + " pip=" + (document.pictureInPictureEnabled ? (document.pictureInPictureElement ? "on" : "off") : "DISABLED"));
    // (v0.21.67) the media gate (are this page's media loads parked?), how it was
    // primed, sticky user activation (the opt-in experiment), the last reaction code
    F.push("gate=" + mediaGate.state + (mediaGate.provenHidden ? "(hidden-proven" : "(") + (mediaGate.at ? "," + Math.round((Date.now() - mediaGate.at) / 60000) + "m)" : ")") +
           " primed=" + mediaGate.primed + (mediaGate.primes ? "/" + mediaGate.primes + "x" : "") +
           " userAct=" + (safe(() => !!navigator.userActivation, false) ? (userActivated() ? "Y" : "n") + (safe(() => navigator.userActivation.isActive, false) ? "/now" : "") : "?") +
           " pulse=" + (lastActPulse ? lastActPulse.how + (lastActPulse.after ? "✓" : "✗") + "(" + Math.round((Date.now() - lastActPulse.at) / 60000) + "m)" : "-") +
           " rx=" + lastAttachRx + (lastAttachHeld ? "(held)" : "") +
           (lastShimInfo ? " picker=" + (lastShimInfo.connected ? "inDOM" : "detached") + (lastShimInfo.react ? "/react" : "/native") + (lastShimInfo.accept ? "/accept:" + trunc(lastShimInfo.accept, 20) : "") : ""));
    F.push("composer=" + (c ? (composerText(c) ? "has-text" : "empty") : "NONE"));
    const ctl = sendControlLabel();
    F.push("ctl=\"" + trunc(ctl || "-", 24) + "\"" + (ctl && LIKE_CTL_RE.test(ctl) && !SEND_CTL_RE.test(ctl) ? "(like)" : ctl && SEND_CTL_RE.test(ctl) ? "(send)" : "(?)"));
    F.push("tray=" + trayRemoveBtns().length + "/" + trayEls().length + " up=" + trayUploads() +
           " [strict " + trayQuery(VIDEO_REMOVE_SEL).length + "/" + trayQuery(VIDEO_PREVIEW_SEL).length +
           " + band " + trayWide("remove").length + "/" + trayWide("preview").length + "]");
    // (v0.21.56) DETECTION vs ATTACH — the question the counters cannot answer.
    // PC-bde6i reported FOUR different channels (drop, input, dom, paste — CDP and
    // pure DOM alike) each dispatching ~90 times with 0 tiles, while
    // persistentInput=found, fileAccess=ok and 180 successful CDP sets. Either
    // Messenger refuses every programmatic attach, or the clip IS staged and our
    // detectors cannot see it — and they only ever look INSIDE [role=main]
    // (trayQuery). If Messenger moved the composer's attachment tray into a portal,
    // every detector reads 0 for ever and the engine gives up on a working attach.
    // So: count the same preview elements document-wide and say where they live.
    try {
      const main = getMain();
      const all = Array.from(document.querySelectorAll(VIDEO_PREVIEW_SEL));
      let inMain = 0, outside = 0;
      for (const el of all) { if (main && main.contains(el)) inMain++; else outside++; }
      const blobs = document.querySelectorAll('img[src^="blob:"]').length;
      const vids = document.querySelectorAll("video").length;
      // Every "remove"-ish control anywhere — if Messenger renamed the button our
      // VIDEO_REMOVE_SEL misses it and a staged clip reads as nothing staged.
      const rmLabels = [];
      for (const b of document.querySelectorAll("[aria-label]")) {
        const al = safe(() => b.getAttribute("aria-label"), "") || "";
        if (/remove|supprimer|retirer|delete|enlever/i.test(al) && rmLabels.length < 4 && rmLabels.indexOf(al) === -1) rmLabels.push(al);
      }
      F.push("docscan: preview-els main=" + inMain + " OUTSIDE-main=" + outside +
             " blobImgs=" + blobs + " videoEls=" + vids +
             " removeish=[" + rmLabels.map((x) => trunc(x, 26)).join(" | ") + "]");
    } catch (e) { F.push("docscan: err " + trunc((e && e.message) || e, 40)); }
    F.push("chatHasVideo=" + (safe(chatAlreadyHasOurVideo, false) ? "Y" : "n"));
    const st = await getLocal(["attachPref", "attachChannelStats", "attachMiss"]);
    const cs = st.attachChannelStats || {};
    F.push("shim: fired=" + lastShimFired + " seen=" + lastShimSeen);
    F.push("channels=" + ["btn", "chooser", "drop", "input", "dom", "paste"].map((k) => {
      const e = cs[k];
      return e ? k + ":" + (e.dispatched || 0) + "d/" + (e.tile || 0) + "t/" + (e.blind || 0) + "b/" + (e.none || 0) + "n/" + (e.unverified || 0) + "u" : k + ":-";
    }).join(" "));
    F.push("pref=" + (st.attachPref && st.attachPref.channel ? st.attachPref.channel : "-") + " missStreak=" + ((st.attachMiss && st.attachMiss.streak) || 0));
    try {
      const r = await Promise.race([ask({ type: "CDP_DOCTOR" }), sleep(20000).then(() => null)]);
      F.push("cdp: " + (r && r.ok ? r.text : ((r && r.error) || "no answer")));
    } catch (e) { F.push("cdp: error " + ((e && e.message) || e)); }
    return F.join(" | ");
  }
  let doctorRunning = false;
  function maybeRunVideoDoctor(reason) {
    (async () => {
      try {
        if (doctorRunning) return;
        if (reason !== "gave-up" && (attachMiss.streak || 0) < 2) return;
        const last = (await getLocal(["videoDoctorAt"])).videoDoctorAt || 0;
        if (Date.now() - last < 6 * 3600 * 1000) return;
        await setLocal({ videoDoctorAt: Date.now() });
        doctorRunning = true;
        const text = await videoDoctor();
        await setLocal({ videoDoctorLast: { at: Date.now(), text } });
        ask({ type: "LOG_EVENT", entry: { thread: null, threadId: "", buyer: "(video doctor)", action: "video-status", reply: "video doctor [" + reason + "]: " + text } });
      } catch (e) { /* diagnostics must never disturb the bot */ } finally { doctorRunning = false; }
    })();
  }
  /* ---------------- (v0.21.72) THE CLIP LEDGER — every clip, exactly once ----------
   * The engine has always tracked a chat's demo set by COUNT and INDEX ("sent 1 of
   * 2, resume at 1"). A count cannot say WHICH clip a chat has — so a clip skipped
   * because its download was struck out that hour, a tail dropped because the
   * dashboard list changed, or a set closed on "a video of ours is in this chat"
   * all ended the chat for good with a clip missing, and nothing could ever send
   * just that one. The ledger records, per chat, the clips handed over BY IDENTITY:
   *   s = sent,   t = handed over but never confirmed.
   * Both mean "never dispatch this clip into this chat again"; a configured clip
   * in neither is OWED. The index machinery below is untouched — the ledger only
   * (1) makes the loop step over a clip the chat already holds, and (2) lets a
   * chat that still owes a NEVER-ATTEMPTED clip receive exactly that clip later
   * (on the buyer's next message — never a blast to dormant chats). A clip that
   * was attempted and could not be confirmed is still never re-dispatched.
   * Pure helpers (store/smoke-clips.js); storage key `videoClips`, 1500 chats. */
  const CLIP_LEDGER_MAX = 1500;
  // A clip's identities: the uploaded object's own name (unique per upload — the
  // dashboard prefixes the upload time) and, when the dashboard recorded the
  // file's size, "=name:size" — so the SAME file uploaded again later, or listed
  // twice, is still one clip.
  function clipIdsOf(v) {
    if (!v) return [];
    const ids = [];
    if (v.url) {
      const u = String(v.url).split(/[?#]/)[0];
      const base = u.slice(u.lastIndexOf("/") + 1);
      let dec = base;
      try { dec = decodeURIComponent(base); } catch (e) { /* keep the raw segment */ }
      ids.push(dec || u);
    } else {
      ids.push("local:" + String(v.name || "clip") + ":" + ((v.dataUrl && v.dataUrl.length) || 0));
    }
    const size = Number(v.size) || 0;
    if (v.name && size > 0) ids.push("=" + String(v.name) + ":" + size);
    return ids;
  }
  // What the Activity row calls the clip: the name the operator uploaded it under.
  function clipLabelOf(v) {
    if (v && v.name) return String(v.name);
    const k = clipIdsOf(v)[0] || "clip";
    return k.replace(/^local:/, "").replace(/^\d{10,}-/, "").replace(/:\d+$/, "");
  }
  function clipLedgerNorm(e) {
    const o = e && typeof e === "object" ? e : {};
    return { s: o.s && typeof o.s === "object" ? o.s : {}, t: o.t && typeof o.t === "object" ? o.t : {}, at: o.at || 0 };
  }
  const clipHeld = (led, ids) => !!(led && ids && ids.some((k) => k && ((led.s && led.s[k]) || (led.t && led.t[k]))));
  const clipSent = (led, ids) => !!(led && ids && ids.some((k) => k && led.s && led.s[k]));
  // How many CLIPS the ledger holds as sent (the "=name:size" aliases are a second
  // name for the same clip, not another clip). A chat whose mark says more clips
  // were sent than the ledger knows was partly served BEFORE v0.21.72 (or lost a
  // ledger write): the ledger cannot say which clips those were, so it must never
  // be used to decide what that chat still owes.
  const clipSentCount = (led) => Object.keys((led && led.s) || {}).filter((k) => k.charAt(0) !== "=").length;
  const clipLedgerTrusted = (led, mark) => clipSentCount(led) >= (Number(mark && mark.sent) || 0);
  function clipMark(e, ids, bucket, now) {
    for (const k of ids || []) {
      if (!k) continue;
      if (bucket === "s") { e.s[k] = now; delete e.t[k]; }
      else if (bucket === "t") { if (!e.s[k]) e.t[k] = now; }
      else { delete e.s[k]; delete e.t[k]; }
    }
  }
  // idsList = the configured clips' identities, in sending order → what this chat
  // still owes (indices), how many it holds, and whether the ledger knows the chat
  // at all (known = 0 for every chat served before v0.21.72 — those are left alone).
  function clipOwed(led, idsList) {
    const L = clipLedgerNorm(led);
    const owed = [];
    let sentN = 0, triedN = 0;
    const seen = {};
    (idsList || []).forEach((ids, i) => {
      if (!ids || !ids.length) return;
      if (ids.some((k) => seen[k])) return; // the same clip listed twice is one clip
      for (const k of ids) seen[k] = 1;
      if (clipSent(L, ids)) sentN++;
      else if (clipHeld(L, ids)) triedN++;
      else owed.push(i);
    });
    return { owed, sentN, triedN, known: Object.keys(L.s).length + Object.keys(L.t).length };
  }
  // Always keyed by the chat's REAL id (the engine's `id`, the watcher's URL id) —
  // every write goes there, so there is nothing to fall back to.
  async function clipLedgerGet(id) {
    const map = (await getLocal(["videoClips"])).videoClips || {};
    return clipLedgerNorm(map[id]);
  }
  async function clipLedgerPut(id, mutate) {
    const map = (await getLocal(["videoClips"])).videoClips || {};
    const e = clipLedgerNorm(map[id]);
    try { mutate(e); } catch (err) { /* keep the entry as it was */ }
    e.at = Date.now();
    map[id] = e;
    const keys = Object.keys(map);
    if (keys.length > CLIP_LEDGER_MAX) {
      keys.sort((a, b) => ((map[a] && map[a].at) || 0) - ((map[b] && map[b].at) || 0));
      for (const k of keys.slice(0, keys.length - CLIP_LEDGER_MAX)) delete map[k];
    }
    await setLocal({ videoClips: map });
    return e;
  }
  // The configured clip list as one string: when it changes, every in-memory
  // "already served this session" latch is re-evaluated against the ledger.
  const clipListSig = (s) => (s && Array.isArray(s.demoVideoUrls) ? s.demoVideoUrls.filter((v) => v && v.url).map((v) => clipIdsOf(v)[0]).join("|") : "");
  let videoLockedSig = null;

  async function maybeSendVideo(id, name, immediate, sidebarKey, deferSend, hooks) {
    videoSendDeferred = false;
    let fgOn = false; // (v0.21.48) this visit brought the window to the front — hand focus back at the end
    let shimOn = false; // (v0.21.49) this visit switched the page visibility shim on — off at the end
    let pipOn = false; // (v0.21.50) this visit opened the keep-awake picture-in-picture window — closed at the end
    try {
      // Terminal exits must clear the pending queue under BOTH keys: deferral
      // writes videoPending[sidebarId] (v0.21.14) but this engine runs on the
      // ADOPTED id — clearing only `id` left sidebar-keyed entries immortal
      // (the aged lane revisited a done chat every hour forever).
      const clearPend = () => {
        clearVideoPending(id);
        if (sidebarKey && sidebarKey !== id) clearVideoPending(sidebarKey);
      };
      // (v0.21.71) A chat judged SERVED by somebody else (a cloud row, the DOM, the
      // sidebar) may still hold THIS machine's own leftovers: a clip staged in its
      // composer draft (a hidden-tab attach whose tile surfaced late) and the retry
      // state (videoAttempts: failAt / claimAt / blindTries) that keeps the watcher's
      // Enter armed for it six hours. Both must go, or the watcher — or the next
      // text reply's Enter — ships a second copy on top of the other computer's.
      // Only when this machine DID try here (an attempts entry exists), only on
      // an empty composer (an operator's typed draft is theirs), never mid-upload.
      const servedCleanup = async () => {
        try {
          const amS = (await getLocal(["videoAttempts"])).videoAttempts || {};
          if (!amS[id]) return;
          delete amS[id];
          await setLocal({ videoAttempts: amS });
          if (!stillOnThread(id)) return;
          const t0 = Date.now();
          while (Date.now() - t0 < 60000 && uploadingInBand()) { if (!stillOnThread(id)) return; await sleep(1000); }
          const c0 = findComposer();
          if (c0 && !composerText(c0) && !uploadingInBand() && trayRemoveBtns().length > 0) {
            await sweepTrayExtras(0);
            console.debug("[SubSell] video: removed this machine's leftover staged clip(s) from a chat served elsewhere", id);
          }
        } catch (e) { /* the stop itself stands */ }
      };
      // (v0.21.60) The demo-video LINK SENDER IS DELETED. It posted a raw storage
      // URL into buyer chats — which reads as phishing, went into chats the bot had
      // never spoken in, and contradicted the bot's own rule never to post a link.
      // It only ever existed because we believed the native attach was failing, and
      // it was not: the tray detector was blind (v0.21.58). Videos are sent as FILES
      // or not at all. Do not reintroduce this.
      // (v0.21.47) NOTHING CONFIRMED in this chat ⇒ never a confirmed mark. Bounded
      // native retries (videoRetryMax, default 2): the mark is dropped, the chat is
      // paced by the short attach backoff and re-queued; every later visit checks
      // the chat for a video FIRST (chatAlreadyHasOurVideo), so a clip that DID land
      // invisibly is re-marked, never re-sent. Past the cap: a terminal mark and
      // nothing else — no link is ever sent (v0.21.60), so a chat is never spammed.
      // (v0.21.72) `ids` = the identities of the ONE clip this visit handed over
      // without confirmation (absent on an adopt visit). The retry re-dispatches it
      // exactly as before, so it leaves the ledger; its key is kept on the attempt
      // record (blindKey) — if the chat later shows a video of ours, that video is
      // THIS clip, and the rest of the set stays deliverable (see the DOM stop).
      const zeroEvidenceExit = async (why, total, ids) => {
        const maxTries = Math.max(0, Number(sCfg.videoRetryMax != null ? sCfg.videoRetryMax : VIDEO_BLIND_RETRIES_DEFAULT) || 0);
        const amZ = (await getLocal(["videoAttempts"])).videoAttempts || {};
        const prev = amZ[id] || {};
        const tries = (prev.blindTries || 0) + 1;
        await noteAttachMiss(true);
        const dmZ = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        if (dmZ[id] && dmZ[id].owner && dmZ[id].owner !== TAB_UID) return; // taken over — its stamps govern
        if (tries <= maxTries) {
          if (dmZ[id] && dmZ[id].done && !dmZ[id].sent) delete dmZ[id]; // drop our lock/marker: the chat is NOT served
          amZ[id] = Object.assign({}, prev, { fails: (prev.fails || 0) + 1, failAt: Date.now(), why: "blind", blindTries: tries }, ids && ids.length ? { blindKey: ids[0] } : {});
          await setLocal({ videoSentThreads: dmZ, videoAttempts: amZ });
          if (ids && ids.length) { clipMark(led, ids, "clear"); await clipLedgerPut(id, (e) => clipMark(e, ids, "clear")); }
          videoLocked.delete(id);
          {
            const qkZ = sidebarKey || id;
            if (qkZ && videoPending[qkZ] == null && videoPending[id] == null) { videoPending[qkZ] = Date.now(); persistDedup(); }
          }
          vstat("⚠ 0/" + total + " confirmed in " + (name || id) + " (" + why + ") — retry " + tries + "/" + maxTries + " in a few minutes");
          setStatus({ lastError: "video: nothing confirmed attached — will retry (" + tries + "/" + maxTries + ")", currentThread: name });
          maybeRunVideoDoctor("attach-miss");
          return;
        }
        // On a REPLY visit the buyer's answer goes out FIRST (idempotent hook,
        // afterClip semantics): otherwise our link would be the newest bubble and
        // the reply path's "conversation changed" recheck would swallow the answer.
        if (hooks && typeof hooks.onClipSent === "function") {
          try { await hooks.onClipSent(-1); } catch (e) { /* the reply path reports its own errors */ }
        }
        dmZ[id] = { done: true, at: Date.now(), owner: TAB_UID, sent: 0, resumeTotal: total, gaveUp: 1 };
        delete amZ[id];
        await setLocal({ videoSentThreads: dmZ, videoAttempts: amZ });
        // (v0.21.72) given up on this chat: every clip it does not hold counts as
        // tried, so no later top-up starts the same failing attach again.
        await clipLedgerPut(id, (e) => { for (const ci of cfgIds) if (!clipSent(e, ci)) clipMark(e, ci, "t", Date.now()); });
        videoLocked.add(id);
        clearPend();
        vstat("⚠ gave up on the demo video for " + (name || id) + " after " + tries + " tries (a video is sent as a FILE or not at all)");
        setStatus({ lastAction: "video: gave up after " + tries + " tries", currentThread: name });
        ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: "(demo video)", action: "video", reply: "0/" + total + " demo videos — native attach failed " + tries + "× (no link is ever sent)" } });
        maybeRunVideoDoctor("gave-up");
      };
      // (v0.21.72) The dashboard's clip list changed since these latches were set
      // (a clip was added, replaced or removed): every chat is re-evaluated against
      // the ledger — one may now owe a clip it was never handed. Still synchronous;
      // the persisted marks below remain the authority for every chat.
      {
        const sigNow = clipListSig(lastSettings);
        if (sigNow !== videoLockedSig) { videoLockedSig = sigNow; videoLocked.clear(); }
      }
      // SYNCHRONOUS guard first (no awaits): if this instance already committed a video
      // to this chat, never touch it again — closes the rapid-re-entry "non-stop" loop.
      if (id && videoLocked.has(id)) {
        clearPend();
        vstat("skip — already sent this session (" + (name || id) + ")");
        return;
      }
      const cfg = await getLocal([
        "videoEnabled", "demoVideos", "demoVideo", "videoDelaySec", "videoSentThreads", "videoAttempts", "videoJustSend",
      ]);
      // JUST-SEND is the default (v0.21.43); a machine-local `videoJustSend:false`
      // or the dashboard's `videoJustSend:false` brings the verdict engine back.
      let justSend = cfg.videoJustSend !== false;
      let sCfg = {}; // the synced settings object (retry cap + link fallback knobs)

      // LOCAL videos (uploaded per-machine, base64 dataUrls).
      let local = Array.isArray(cfg.demoVideos) ? cfg.demoVideos : [];
      if (!local.length && cfg.demoVideo && cfg.demoVideo.dataUrl) local = [cfg.demoVideo]; // legacy single
      local = local.filter((v) => v && v.dataUrl);

      // CENTRAL videos + the configurable delays from the synced config.
      let central = [];
      let centralDelay = null;
      let betweenSec = null;
      let settingsOk = true;
      try {
        const resp = await ask({ type: "GET_SETTINGS" });
        const s = (resp && resp.settings) || {};
        sCfg = s;
        if (!resp || !resp.settings) settingsOk = false;
        if (Array.isArray(s.demoVideoUrls)) central = s.demoVideoUrls.filter((v) => v && v.url);
        if (s.demoVideoDelaySec != null) centralDelay = Number(s.demoVideoDelaySec);
        if (s.demoVideoBetweenSec != null) betweenSec = Number(s.demoVideoBetweenSec);
        if (s.videoJustSend === false) justSend = false;
      } catch (e) {
        settingsOk = false;
      }

      // CENTRAL videos (the dashboard set) are the single source of truth when they
      // exist — legacy per-machine local clips are ignored then. This stops (a) a
      // corrupt old local file from blocking the whole set via the complete-set
      // guard, and (b) buyers receiving local+central duplicates.
      if (central.length) local = [];
      if (!settingsOk && !central.length && !local.length) {
        // Queue instead of dropping: a one-cycle settings hiccup used to consume
        // this chat's visit permanently (next visit could be days away on rotation).
        {
          const dn = (cfg.videoSentThreads || {})[id];
          const alreadyDone = !!(dn && dn.done && typeof dn.resumeFrom !== "number");
          const qk = sidebarKey || id;
          if (qk && !alreadyDone && videoPending[qk] == null && videoPending[id] == null) {
            videoPending[qk] = Date.now();
            persistDedup();
          }
        }
        vstat("couldn't read settings this cycle — will retry");
        return;
      }
      if (!cfg.videoEnabled && !central.length) {
        clearPend();
        vstat("videos OFF — no central videos in dashboard and per-machine toggle unchecked");
        setStatus({ lastError: "VIDEOS OFF on this machine — this machine has no video list (check dashboard Videos tab / this machine's config link)" });
        return;
      }
      if (!local.length && !central.length) {
        clearPend();
        vstat("no videos configured");
        setStatus({ lastError: "NO VIDEOS CONFIGURED — this machine receives no video list (check dashboard Videos tab / this machine's config link)" });
        return;
      }

      const now = Date.now();
      const done = cfg.videoSentThreads || {};

      // (v0.21.72) THE CLIP LEDGER for this chat, and the configured clips'
      // identities in sending order (per-machine local clips first — they are
      // ignored whenever the dashboard has clips). `videoCompleteSet:false` in the
      // dashboard turns the new SENDS off (top-up, changed list, evidence credit);
      // the ledger's "never the same clip twice" skip is always on.
      const completeSet = sCfg.videoCompleteSet !== false;
      const cfgIds = local.concat(central).map(clipIdsOf);
      let led = await clipLedgerGet(id);
      const buyerVisit = !!(hooks && typeof hooks.onClipSent === "function");
      let keyFlow = false; // this visit starts from the LEDGER (top-up / changed list), not from a resume index

      // RESUME-TAIL: a set interrupted by operator navigation records resumeFrom = the
      // first clip index NEVER ATTEMPTED (we break BEFORE attempting). Only that
      // strictly-untouched tail may be sent later — zero duplicate risk, and the chat
      // finally gets all 3 configured clips instead of 2.
      let resumeFrom = done[id] && done[id].done && typeof done[id].resumeFrom === "number" ? done[id].resumeFrom : null;

      // (v0.21.72) TOP-UP. A chat this machine already served whose ledger shows a
      // configured clip it was NEVER handed — a clip added to the dashboard since,
      // or one whose download was struck out the day the chat was served. Only when
      // the BUYER just wrote (never a blast to dormant chats), only chats the
      // ledger knows (served on v0.21.72+), only never-attempted clips, each once.
      // It runs as a resume visit from the first owed clip; the loop below steps
      // over every clip the ledger already holds.
      if (completeSet && buyerVisit && resumeFrom == null && done[id] && done[id].done) {
        const dmkT = done[id];
        const confirmedT = !!(dmkT.sent || dmkT.recon || dmkT.via === "dom" || dmkT.via === "cloud" || dmkT.via === "taildrop" || dmkT.resumeTotal != null);
        const owT = clipOwed(led, cfgIds);
        // …and only when the ledger accounts for every clip the mark says was sent
        // (a chat partly served before v0.21.72 would otherwise get its first clip again).
        if (confirmedT && !dmkT.gaveUp && owT.known > 0 && owT.owed.length > 0 && clipLedgerTrusted(led, dmkT)) {
          const copyT = Object.assign({}, dmkT, { resumeFrom: owT.owed[0], resumeTotal: cfgIds.length, sent: owT.sentN });
          delete copyT.via;
          done[id] = copyT;
          resumeFrom = owT.owed[0];
          keyFlow = true;
          vstat("top-up — " + (name || id) + " is missing " + owT.owed.length + " of the " + cfgIds.length + " dashboard clip(s); sending only those");
        }
      }

      // IN-FLIGHT guard: a via:"lock" progress stamp younger than 10 min means a
      // set is probably being sent RIGHT NOW in another pass/tab (every loop
      // iteration refreshes `at`, so a live pass stays fresh even under heavy
      // background-tab timer throttling). Only a STALE stamp (crash mid-set) may
      // resume. Belt: even if a live pass IS wrongly resumed, the per-iteration
      // owner check + pre-attempt stamps below make interleaving duplicate-free —
      // the resumer starts strictly after the last stamped clip and the old owner
      // bows out at its next iteration.
      // (v0.21.40: 10 min, was 30 — a live pass re-stamps `at` at least every few
      // minutes; a crashed one used to block its own chat's resume for half an hour)
      if (resumeFrom != null && done[id].via === "lock" && now - (done[id].at || 0) < VIDEO_INFLIGHT_MS) {
        vstat("set in progress in another pass — waiting (" + (name || id) + ")");
        return;
      }

      // (1) CONFIRMED sent → never resend. Only the NEW {done:true} is authoritative.
      if (done[id] && done[id].done && resumeFrom == null) {
        const dmk = done[id];
        // SELF-HEAL (i) — orphaned pre-send lock: via:"lock" with no clip ever
        // confirmed attached, older than 24h = a crash between lock and first
        // attach. If the open chat visibly has our video → confirm it; if the
        // loaded chat shows none → provably nothing attached (attach is preview-
        // based), clear the mark so the chat finally gets its set.
        // (v0.21.41: the in-flight window, not 24 h — a live pass re-stamps `at`
        // within ~2 min of locking; anything older with no clip stamped is a crash)
        if (dmk.via === "lock" && !dmk.sent && now - (dmk.at || 0) > VIDEO_INFLIGHT_MS && !dmk.recon) {
          const mainEl = getMain();
          if (mainEl && findComposer() && safe(() => mainEl.querySelector('[role="row"]'), null)) {
            const dmR = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
            if (chatServedVideo(id, sidebarKey)) { // (v0.21.53) geometry OR the sidebar's own words
              dmR[id] = Object.assign({}, dmR[id], { sent: 1, recon: 1 }); // confirmed after all
              await setLocal({ videoSentThreads: dmR });
            } else {
              delete dmR[id];
              await setLocal({ videoSentThreads: dmR });
              videoLocked.delete(id);
              {
                // queue the delivery explicitly — "a later visit" meant hours on busy machines
                const qkH = sidebarKey || id;
                if (qkH && videoPending[qkH] == null && videoPending[id] == null) { videoPending[qkH] = Date.now(); persistDedup(); }
              }
              vstat("cleared an orphaned send-lock (" + (name || id) + ") — video sends on the next visit");
              return; // NEVER send in the same visit as a heal — normal pipeline takes it later
            }
          }
        }
        // SELF-HEAL (ii) — pre-hardening DOM mark (video branch until 2026-08-10,
        // badge branch until this release): BOUNDED divergence probe, max 3 tries
        // >= 4h apart, only on a LOADED chat. A single both-negative read is NOT
        // terminal — on throttled/minimized RDP windows the FP source (autoplaying
        // listing clip / badge media) is often not rendered at probe time. Clear
        // ONLY when the hardened detector is silent while a frozen legacy detector
        // still fires (FP source identified live). Both-negative keeps the mark —
        // the zero-duplicate direction. Legacy one-shot rechecked:1 counts as one
        // consumed probe, so already-burned marks get two more chances.
        const probeN = typeof dmk.recheckN === "number" ? dmk.recheckN : (dmk.rechecked ? 1 : 0);
        if (dmk.via === "dom" && !dmk.sent && probeN < 3 && now - (dmk.recheckAt || 0) > 4 * 3600 * 1000 && (dmk.at || 0) < BADGE_FIX_TS) {
          const mainEl2 = getMain();
          if (mainEl2 && findComposer() && safe(() => mainEl2.querySelector('[role="row"]'), null)) {
            const dmP = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
            if (!chatAlreadyHasOurVideo() && (legacyChatVideoDetect() || legacyBadgeDetect())) {
              delete dmP[id];
              await setLocal({ videoSentThreads: dmP });
              videoLocked.delete(id);
              vstat("cleared a false 'already sent' mark (" + (name || id) + ") — video sends on a later visit");
              return; // heal now, deliver on a later visit through the full pipeline
            }
            dmP[id] = Object.assign({}, dmP[id], { recheckN: probeN + 1, recheckAt: now });
            if (probeN + 1 >= 3) dmP[id].rechecked = 1; // terminal only after the 3rd both-negative
            await setLocal({ videoSentThreads: dmP });
          }
        }
        // (v0.21.41) latch the session guard only for CONFIRMED marks. A bare
        // via:"lock" (a set in flight in another pass — or a crash) is re-read on
        // every visit so heal (i) can run without a page reload, and its pending
        // entry is kept.
        const confirmedMark = !!(dmk.sent || dmk.recon || dmk.via === "dom" || dmk.via === "cloud" || dmk.via === "taildrop" || dmk.resumeTotal != null);
        // (v0.21.72) a served chat that still owes a never-attempted clip is not
        // latched for the session: its buyer's next message tops it up (above).
        const owL = completeSet && !dmk.gaveUp ? clipOwed(led, cfgIds) : null;
        const owesMore = !!(owL && owL.known > 0 && owL.owed.length > 0);
        if (confirmedMark) { if (!owesMore) videoLocked.add(id); clearPend(); }
        vstat("skip — chat already marked sent (" + (name || id) + ")");
        return;
      }
      // A video is visibly in the chat (real message row) → it's sent; mark + stop.
      // (Skipped in resume mode — of course there are already videos there.)
      if (resumeFrom == null && chatServedVideo(id, sidebarKey)) {
        // (v0.21.72) …but when THIS machine handed this chat ONE clip it could not
        // confirm (a bounded retry is pending: videoAttempts.blindKey), the video
        // now in the chat is THAT clip — not the whole set. v0.21.71's sidebar
        // memory made this stop reliable, and with it every such chat was closed
        // after its first clip ("it keeps sending one video"). Credit that clip and
        // keep the never-attempted rest deliverable: a resume marker at the first
        // owed clip, delivered by the pending lane. Only with a verifiably EMPTY
        // tray (a leftover copy of the credited clip must never be adopted and
        // sent); otherwise the old terminal mark below stands.
        const attD = (cfg.videoAttempts || {})[id];
        const blindIdx = attD && attD.blindTries && attD.blindKey ? cfgIds.findIndex((ci) => ci.indexOf(attD.blindKey) >= 0) : -1;
        if (completeSet && blindIdx >= 0) {
          await servedCleanup(); // drops the retry state and sweeps our own leftover tile
          const trayClean = stillOnThread(id) && trayRemoveBtns().length === 0 && !uploadingInBand();
          led = await clipLedgerPut(id, (e) => clipMark(e, cfgIds[blindIdx], "s", Date.now()));
          const owD = clipOwed(led, cfgIds);
          if (trayClean && owD.owed.length > 0) {
            const dmD = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
            if (!(dmD[id] && dmD[id].owner && dmD[id].owner !== TAB_UID)) {
              dmD[id] = { done: true, at: now, owner: TAB_UID, resumeFrom: owD.owed[0], resumeTotal: cfgIds.length, sent: owD.sentN, recon: 1, noAdopt: 1 };
              await setLocal({ videoSentThreads: dmD });
              videoLocked.delete(id);
              const qkD = sidebarKey || id;
              if (qkD && videoPending[qkD] == null && videoPending[id] == null) { videoPending[qkD] = Date.now(); persistDedup(); }
              vstat("the first clip is confirmed in " + (name || id) + " (Facebook shows it) — " + owD.owed.length + " more clip(s) follow on the next visit");
              return;
            }
          }
        }
        videoLocked.add(id);
        clearPend();
        done[id] = { done: true, at: now, via: "dom" }; // inert marker: DOM-detected, not a confirmed send
        await setLocal({ videoSentThreads: done });
        await servedCleanup(); // (v0.21.71) our own leftover tile / retry state must not outlive the stop
        vstat("skip — detected an existing video in chat (" + (name || id) + ")");
        return;
      }
      // A leftover OLD boolean `true` mark with NO actual video in the chat was a
      // premature "marked up-front" mark from the old bug — clear it so this chat
      // (the backlog that never got its video) gets it now.
      if (done[id] === true) {
        delete done[id];
        await setLocal({ videoSentThreads: done });
      }
      // (v0.21.71) CLOUD MEMORY: an Activity row "N/M demo video(s) sent" for this
      // chat from ANY computer — or from this one before its storage was wiped or
      // reinstalled — means the buyer has our clip: mark + stop, never a second
      // set. Read-only, bounded, no login / no rows = today's behaviour. Exceptions:
      // THIS machine's own deliberate bounded retry (blindTries after a zero-evidence
      // exit) against its OWN row — the .47 retry design stands — and the popup's
      // "Resend video to OPEN chat" (manualResend, 10 min), the operator's eyes
      // outrank the log. In RESUME mode (our own partial set is in the chat) only
      // ANOTHER computer's row stops the tail.
      {
        const cm = await ask({ type: "MEMORY_VIDEO", threadId: id });
        const attC = (cfg.videoAttempts || {})[id];
        const manual = !!(attC && attC.manualResend && now - attC.manualResend < 10 * 60 * 1000);
        const stop = !!(cm && cm.ok && cm.sent && !manual && (resumeFrom == null ? !(cm.mine && attC && attC.blindTries) : !cm.mine));
        if (stop) {
          videoLocked.add(id);
          clearPend();
          // re-read right before writing: the snapshot in `done` is seconds old now
          const dmC = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          dmC[id] = { done: true, at: now, via: "cloud", recon: 1, by: cm.by || "" };
          await setLocal({ videoSentThreads: dmC });
          await servedCleanup();
          vstat("skip — the Activity log already shows a demo video sent in this chat (" + (cm.by || "another computer") + ")");
          console.debug("[SubSell] video: skip — cloud memory says already sent", id, cm.by || "");
          return;
        }
        // Another computer claimed this chat's newest message BEFORE we did (or we
        // hold no claim) and has not logged a video since: it sends its clips before
        // its text, so its video row is not there yet. Not this visit — nothing
        // marked, the chat stays queued; the next visit finds that computer's video
        // row (→ mark) or nothing (→ send). Not in resume mode, not on a manual resend.
        if (cm && cm.ok && cm.inflight && resumeFrom == null && !manual) {
          const qkI = sidebarKey || id;
          if (qkI && videoPending[qkI] == null && videoPending[id] == null) { videoPending[qkI] = Date.now(); persistDedup(); }
          vstat("another computer (" + (cm.inflightBy || "?") + ") is handling this chat right now — video left to it (re-checked later)");
          return;
        }
      }
      // (2) Backoff so a chat whose clip keeps failing to LOAD isn't retried every
      // scan. NOT permanent anymore: after 24h the fail count resets — a transient
      // download problem used to ban a chat from ever getting its video.
      const att0 = (cfg.videoAttempts || {})[id] || null;
      if (att0) {
        // (v0.21.40) No 24h pause: a chat that failed 3× keeps retrying on the
        // short backoff below. The count is kept for the diagnostic only.
        if (att0.claimAt && now - att0.claimAt < VIDEO_CLAIM_TTL && att0.claimTab !== TAB_UID) {
          vstat("another tab is sending to " + (name || id));
          return;
        }
        // (v0.21.41) a buyer-triggered visit (reply hook present) is the natural
        // retry point — never refused for pacing; otherwise load fails back off
        // 60 s, attach fails 3 min.
        if (!(hooks && typeof hooks.onClipSent === "function") && att0.failAt && now - att0.failAt < backoffFor(att0)) {
          vstat("backing off after a failed " + (att0.why === "load" ? "load" : "attach") + " — retry soon (" + (name || id) + ")");
          return;
        }
      }
      // (3) Short-lived claim (TTL) so two passes/tabs don't both send right now.
      const attempts = (await getLocal(["videoAttempts"])).videoAttempts || {};
      const cur = attempts[id];
      if (cur && cur.claimAt && now - cur.claimAt < VIDEO_CLAIM_TTL && cur.claimTab !== TAB_UID) { vstat("claim race — another pass owns " + (name || id)); return; }
      attempts[id] = Object.assign({}, cur, { claimAt: now, claimTab: TAB_UID });
      await setLocal({ videoAttempts: attempts });
      const verify = (await getLocal(["videoAttempts"])).videoAttempts || {};
      if (!(verify[id] && verify[id].claimTab === TAB_UID)) { vstat("claim race — another pass owns " + (name || id)); return; } // lost the claim race

      // NO DELAYS (v0.21.25/26, operator directive): no pre-video wait on any
      // path, no between-clips gap at all — clips are ATTACHED back-to-back and
      // sent together in ONE message below. `immediate`, centralDelay and
      // betweenSec are kept in signatures/config for compatibility but no
      // longer do anything. (void reads keep linters honest.)
      void immediate; void centralDelay; void betweenSec;

      // ABORT if the operator opened a different chat during the pre-video wait —
      // uploading now would drop the clip into the WRONG conversation. Not locked
      // yet, so this chat still gets its video on a later visit.
      if (!stillOnThread(id)) {
        console.debug("[SubSell] video: aborted — user switched chats during the wait", id);
        {
          // nothing attached, no lock: queue the retry (a buyer-triggered visit had no pending entry)
          const qkA = sidebarKey || id;
          if (qkA && videoPending[qkA] == null && videoPending[id] == null) { videoPending[qkA] = Date.now(); persistDedup(); }
        }
        setStatus({ lastAction: "video postponed — you switched chats (will retry)", currentThread: name });
        return;
      }
      // Re-check AFTER the delay: during the wait the chat may have received a video
      // (another pass finished, or one finally rendered). Re-read storage + the DOM so
      // we never pile a second clip onto a chat that already has one. (Not in resume
      // mode — there the done-flag and existing videos are expected.)
      if (resumeFrom == null) {
        const fresh = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        if (videoLocked.has(id) || (fresh[id] && fresh[id].done) || chatServedVideo(id, sidebarKey)) {
          // Do NOT latch videoLocked when the observed mark is a RESUME marker —
          // "done" is transient there (another pass's partial set); a latched tab
          // would eat the tail's pending-queue entry forever without delivering.
          // …nor on another pass's BARE in-flight lock: if that pass crashes, a
          // latched tab would refuse the chat (and eat its pending entry) until reload.
          if (!(fresh[id] && (typeof fresh[id].resumeFrom === "number" || (fresh[id].via === "lock" && !fresh[id].sent)))) videoLocked.add(id);
          if (!(fresh[id] && fresh[id].done)) {
            fresh[id] = { done: true, at: Date.now(), via: "dom" };
            await setLocal({ videoSentThreads: fresh });
          }
          await servedCleanup(); // (v0.21.71) same rule: nothing of ours may ride a later Enter here
          vstat("skip after delay — video appeared meanwhile (" + (name || id) + ")");
          console.debug("[SubSell] video: skip after delay — chat already has a video", id);
          return;
        }
      }

      // A clip that fails to LOAD 3 times GLOBALLY (any chat) is excluded from the
      // set instead of blocking it: one oversized/broken upload in the dashboard used
      // to fail the complete-set rule on EVERY chat = "no videos at all". The
      // remaining clips still ship, and the popup names the bad one.
      const STRIKE_TTL = 60 * 60 * 1000; // (v0.21.41) an excluded URL is re-probed after this (was 6 h)
      const urlFails = (await getLocal(["videoUrlFails"])).videoUrlFails || {};
      const strikeN = (e) => (typeof e === "number" ? e : (e && e.n) || 0);   // legacy numeric = {n:value, at:0}
      const strikeAt = (e) => (typeof e === "number" ? 0 : (e && e.at) || 0);
      let urlFailsChanged = false;
      for (const u of Object.keys(urlFails)) {
        if (strikeN(urlFails[u]) >= 3 && now - strikeAt(urlFails[u]) > STRIKE_TTL) {
          delete urlFails[u]; // ban expired — the URL re-enters the set and is re-probed this pass
          urlFailsChanged = true;
        }
      }
      const activeCentral = central.filter((v) => strikeN(urlFails[v.url]) < 3);
      const excluded = central.length - activeCentral.length;
      if (excluded > 0 && activeCentral.length) vstat("⚠ " + excluded + " dashboard clip(s) can't load (too big/broken?) — sending the rest");

      // Build the ordered File list (local first, then central downloaded via background),
      // plus the parallel list of on-disk paths for the Chrome file API (null = none).
      const files = [];
      const paths = [];
      const fileIds = []; // (v0.21.72) each slot's clip identities — always aligned with `files`
      const fileNames = []; // …and the name the operator uploaded it under (Activity rows)
      for (const v of local) {
        try {
          files.push(dataUrlToFile(v.dataUrl, v.name, v.type));
          fileIds.push(clipIdsOf(v));
          fileNames.push(clipLabelOf(v));
          paths.push(await diskPathFor({ dataUrl: v.dataUrl, name: v.name }));
        } catch (e) {
          /* skip a bad local video */
        }
      }
      // (v0.21.41) The index space is the FULL configured list, always: a URL that
      // is struck out (3 download failures, re-probed hourly) keeps its slot as an
      // EXCLUDED sentinel the loop steps over — so `files.length` never changes
      // between visits and a parked tail can no longer be dropped as "set changed"
      // (the .40 regression: one bad clip URL sealed chats after their first clip).
      const EXCLUDED_SLOT = { excluded: true };
      // A stalled clip download must never freeze the scan loop (replies included):
      // the fetch gets a budget; past it the clip is a null slot for this visit.
      const fetchWithBudget = (url) => Promise.race([
        ask({ type: "FETCH_VIDEO", url }),
        sleep(100000).then(() => ({ ok: false, error: "video fetch timed out" })),
      ]);
      for (const v of central) {
        fileIds.push(clipIdsOf(v)); // exactly one slot is pushed per iteration below
        fileNames.push(clipLabelOf(v));
        if (strikeN(urlFails[v.url]) >= 3) { files.push(EXCLUDED_SLOT); paths.push(null); continue; }
        let ok = false;
        try {
          // ON-DISK FIRST (v0.21.38): with the file API on, the clip's path is all
          // the attach needs — hauling 10-30 MB of base64 per clip through the
          // message channel before the first attach was seconds of "instant"
          // lost on every visit. The File is loaded LAZILY, only if a synthetic
          // strategy ever runs for this clip. (The disk cache is kept warm even
          // while the file API is parked — a park must not mean a cold start.)
          const p = await diskPathFor({ url: v.url, name: v.name });
          if (p) {
            const load = async () => {
              const r = await fetchWithBudget(v.url);
              if (!(r && r.ok && r.base64)) return null;
              const mime = r.mime || "video/mp4";
              return dataUrlToFile(`data:${mime};base64,${r.base64}`, v.name || "video.mp4", mime);
            };
            files.push({ lazy: true, name: v.name || "video.mp4", load });
            paths.push(p);
            ok = true;
          } else {
            const r = await fetchWithBudget(v.url);
            if (r && r.ok && r.base64) {
              const mime = r.mime || "video/mp4";
              files.push(dataUrlToFile(`data:${mime};base64,${r.base64}`, v.name || "video.mp4", mime));
              paths.push(null);
              ok = true;
            }
          }
        } catch (e) {
          /* fall through to failure accounting */
        }
        if (ok) {
          if (urlFails[v.url]) { delete urlFails[v.url]; urlFailsChanged = true; }
        } else {
          // (v0.21.40) keep the slot: indices stay aligned with the configured
          // set, the loop sends the clips BEFORE this one and resumes here later.
          files.push(null);
          paths.push(null);
          urlFails[v.url] = { n: strikeN(urlFails[v.url]) + 1, at: Date.now() };
          urlFailsChanged = true;
        }
      }
      if (urlFailsChanged) {
        await setLocal({ videoUrlFails: urlFails });
        // Fires only on the TRANSITION into full lockout (some clips were active at
        // the start of this pass, and now every URL is struck out) — one dashboard row.
        if (activeCentral.length > 0 && central.length > 0 && central.every((v) => strikeN(urlFails[v.url]) >= 3)) {
          ask({ type: "LOG_EVENT", entry: { thread: "(system)", threadId: "", buyer: "(system)", action: "video-status", reply: "all " + central.length + " dashboard clip(s) failing to DOWNLOAD on this machine (network/proxy?) — re-probing in 6h; replies unaffected" } });
        }
      }

      // SEND WHAT LOADED (v0.21.40, operator: "send any video you can, you don't
      // need all to send"). The old rule held the WHOLE set until every clip had
      // loaded — one slow download meant no video at all. Now a clip that can't
      // load right now is a `null` slot: the clips before it go out on this visit,
      // the loop stops at the slot with a resume marker (that clip is re-tried on
      // the next visit, not skipped), and only a set whose NEXT DUE clip is
      // missing waits (short backoff + pending queue).
      const expected = files.length;
      const loadedN = files.filter((f) => f && !f.excluded).length;
      const firstMissing = files.findIndex((f) => !f);
      const startAt0 = resumeFrom != null ? Math.min(resumeFrom, files.length) : 0;
      // (v0.21.72) a clip this chat already holds (sent, or handed over once) is
      // stepped over exactly like a struck-out one — by identity, wherever it sits.
      const heldAt = (k) => clipHeld(led, fileIds[k]);
      const moreDueAfter = (k) => { for (let j = k + 1; j < files.length; j++) if (!(files[j] && files[j].excluded) && !heldAt(j)) return true; return false; };
      // …and the names of the clips this chat holds as sent, for the Activity rows
      const clipNamesSent = () => {
        const names = [];
        fileIds.forEach((ci, k) => { if (clipSent(led, ci) && fileNames[k] && names.indexOf(fileNames[k]) < 0) names.push(fileNames[k]); });
        return names.length ? ": " + trunc(names.join(" + "), 160) : "";
      };
      // A FRESH visit to a chat whose ledger already holds EVERY configured clip
      // (its mark was lost or cleared, the ledger was not): nothing is due. Restore
      // a confirmed mark — without this the "next due clip" search below would run
      // off the end and report "can't download", re-queueing the chat every 15 min
      // for ever. (Resume visits are left alone: an adopt visit must still run.)
      if (resumeFrom == null && files.length > 0 && files.every((f, k) => heldAt(k))) {
        videoLocked.add(id);
        clearPend();
        const dmH = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        if (!(dmH[id] && dmH[id].owner && dmH[id].owner !== TAB_UID)) {
          dmH[id] = { done: true, at: Date.now(), owner: TAB_UID, sent: clipOwed(led, fileIds).sentN, resumeTotal: files.length };
          const amH = (await getLocal(["videoAttempts"])).videoAttempts || {};
          if (amH[id]) delete amH[id]; // the claim taken above must not keep the watcher armed for this chat
          await setLocal({ videoSentThreads: dmH, videoAttempts: amH });
        }
        vstat("skip — this chat already holds every dashboard clip (" + (name || id) + ")");
        return;
      }
      let nextDue = startAt0;
      while (nextDue < files.length && ((files[nextDue] && files[nextDue].excluded) || heldAt(nextDue))) nextDue++; // step over struck-out and already-held clips
      const nothingLoadable = startAt0 < files.length && nextDue >= files.length; // every remaining clip is struck out
      if (nothingLoadable && startAt0 > 0) {
        // (v0.21.42) a parked tail whose remaining clips are ALL struck out ends
        // exactly like the in-visit path ends (`continue` over struck slots →
        // terminal): the chat got everything sendable. Consistent, and no
        // once-a-minute no-op visits for up to an hour.
        videoLocked.add(id);
        clearPend();
        const dmX = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        dmX[id] = { done: true, at: Date.now(), owner: TAB_UID, sent: (done[id] && typeof done[id].sent === "number" ? Math.min(done[id].sent, startAt0) : startAt0), resumeTotal: files.length };
        await setLocal({ videoSentThreads: dmX });
        vstat("remaining clip(s) can't download (struck out) — set closed at " + startAt0 + "/" + files.length + " (" + (name || id) + ")");
        return;
      }
      if (!files.length || nothingLoadable || (nextDue < files.length && !files[nextDue])) {
        // a fresh chat with NOTHING loadable waits for the strike window (15 min
        // pacing), a merely-slow clip is retried within the minute
        await recordVideoFail(id, nothingLoadable || (central.length > 0 && !activeCentral.length) ? "struck" : "load");
        const allBlocked = central.length > 0 && !activeCentral.length;
        const msg = allBlocked
          ? "⚠ all " + central.length + " dashboard clip(s) failing to DOWNLOAD on this machine (network/proxy?) — replies unaffected, re-probing within the hour"
          : nothingLoadable
            ? "remaining clip(s) can't download right now (struck out) — re-probing within the hour (" + (name || id) + ")"
            : "loaded " + loadedN + "/" + expected + " clip(s), clip " + (nextDue + 1) + " not yet — retrying within a minute (" + (name || id) + ")";
        vstat(msg);
        setStatus({ lastError: "video: " + msg, currentThread: name });
        // Queue the retry explicitly (pending lane, honored after the short backoff).
        {
          const qkL = sidebarKey || id;
          const dnL = (cfg.videoSentThreads || {})[id];
          const doneL = !!(dnL && dnL.done && typeof dnL.resumeFrom !== "number");
          if (qkL && !doneL && videoPending[qkL] == null && videoPending[id] == null) { videoPending[qkL] = Date.now(); persistDedup(); }
        }
        return;
      }
      {
        const laterMissing = files.findIndex((f, k) => k > nextDue && !f);
        if (laterMissing >= 0) vstat("clip " + (laterMissing + 1) + " can't load right now — sending the others first (" + (name || id) + ")");
      }
      void firstMissing;

      // Resume-tail is an INDEX into `files`. With strike decay the active set can
      // GROW between visits (a revived URL slots in earlier), so replaying the index
      // could REPEAT an already-delivered clip. Resume only against the exact same
      // set size it was recorded with; otherwise drop the tail (never resend).
      // (v0.21.72) …unless the LEDGER knows this chat: then the clips it holds are
      // known by identity, the index is no longer needed, and the visit continues
      // from the first clip of the NEW list this chat does not hold — nothing
      // repeated, nothing dropped. (Tails parked before v0.21.72 have no ledger
      // and are dropped as before.)
      if (resumeFrom != null && !(done[id] && done[id].resumeTotal === files.length) && completeSet) {
        const owS = clipOwed(led, fileIds);
        // trusted = the ledger accounts for every clip this chat's marker says was sent
        const ledOk = owS.known > 0 && clipLedgerTrusted(led, done[id]);
        if (ledOk && owS.owed.length > 0) {
          resumeFrom = owS.owed[0];
          done[id] = Object.assign({}, done[id], { resumeFrom, resumeTotal: files.length, sent: owS.sentN });
          keyFlow = true;
          vstat("the clip list changed since this chat's last visit — sending only the clip(s) it does not have (" + (name || id) + ")");
        } else if (ledOk) {
          // the new list holds nothing this chat lacks → the set is complete
          videoLocked.add(id);
          clearPend();
          const dmC2 = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          dmC2[id] = { done: true, at: Date.now(), owner: TAB_UID, sent: owS.sentN, resumeTotal: files.length };
          await setLocal({ videoSentThreads: dmC2 });
          vstat("the clip list changed — this chat already has every current clip (" + (name || id) + ")");
          return;
        }
      }
      if (resumeFrom != null && !(done[id] && done[id].resumeTotal === files.length)) {
        videoLocked.add(id);
        clearPend();
        const dm0 = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        // via:"taildrop" + resumeTotal ⇒ catch-up treats it as confirmed (head clips
        // WERE attempted — must never re-queue) and the self-heals never touch it.
        dm0[id] = { done: true, at: Date.now(), via: "taildrop", resumeTotal: typeof done[id].resumeTotal === "number" ? done[id].resumeTotal : 0 };
        await setLocal({ videoSentThreads: dm0 });
        vstat("resume tail dropped — clip set changed since interruption (" + (name || id) + ")");
        return;
      }

      // RE-VERIFY the claim right before locking: the pre-lock phase (first-video
      // delay + clip downloads) can outlive the 3-min claim TTL on slow machines,
      // and a second tab may have legitimately claimed over a stale one. Losing
      // the claim here = the other pass owns this chat — bow out with no writes.
      {
        const amV = (await getLocal(["videoAttempts"])).videoAttempts || {};
        const curV = amV[id];
        if (curV && curV.claimTab && curV.claimTab !== TAB_UID && curV.claimAt && Date.now() - curV.claimAt < VIDEO_CLAIM_TTL) {
          vstat("claim lost during the pre-send wait — another pass owns " + (name || id));
          return;
        }
        amV[id] = Object.assign({}, curV, { claimAt: Date.now(), claimTab: TAB_UID });
        await setLocal({ videoAttempts: amV });
      }

      // *** LOCK THE CHAT BEFORE SENDING — the zero-resend guarantee. ***
      // Persist {done:true} for this conversation BEFORE uploading a single clip, in
      // BOTH the in-memory set (synchronous, instant) and storage (survives reloads).
      // From this instant every other pass/tab/reload that reaches the guards above
      // sees the chat as done and skips. There is NO retry path and NO fail record for
      // the send itself: even if the upload, the send, the confirmation, AND the DOM
      // detection all fail, this chat is recorded and can NEVER receive another video.
      // (Operator priority: never re-send / never spam. A rare missed clip on a truly
      // failed upload is the accepted trade.)
      videoLocked.add(id);
      clearPend(); // committed to sending — off the pending queue (both keys)
      {
        const dm = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        // via:"lock": tag the pre-send lock so a crash mid-send is detectable later
        // (the tag is overwritten by the mid-set/undo/final stamps on normal flow).
        const priorRecon = dm[id] && dm[id].recon ? 1 : 0;
        dm[id] = { done: true, at: Date.now(), via: "lock", owner: TAB_UID };
        if (priorRecon) dm[id].recon = 1;
        // On a RESUME visit, carry the marker's fields through the lock: a crash
        // between this write and the first tail attach used to degrade the mark to
        // a bare lock — heal (i) could then wrongly clear it (its "no sent means
        // nothing attached" premise is false here) and re-send the HEAD clips.
        // With sent/resumeFrom preserved, a crash in this window simply resumes.
        if (resumeFrom != null) {
          if (done[id] && done[id].sent) dm[id].sent = done[id].sent;
          dm[id].resumeFrom = Math.min(resumeFrom, files.length);
          dm[id].resumeTotal = files.length;
        }
        const am = (await getLocal(["videoAttempts"])).videoAttempts || {};
        // Keep the FAIL history through the send attempt (drop only the claim):
        // deleting the whole entry here reset `fails` to 0 on every retry visit,
        // so the 3-strikes/24h attach pause could never actually trigger — chats
        // with a flaky clip retried every 20 min forever (both diagnostics showed
        // pausedAttach=0 despite repeated attach failures).
        // (v0.21.52) blindTries MUST survive this rebuild. It is the bounded-retry
        // count zeroEvidenceExit compares against videoRetryMax; dropping it here
        // made `tries` read 1 on every visit, so `tries <= maxTries` was true for
        // ever - the chat was retried every few minutes indefinitely and the link
        // fallback below it was unreachable code. The field diagnostic showed it
        // live: twelve failed attempts over 17 minutes still reporting "retry 1".
        // Note blindTries can exist with no fails (the adopt path at ~:274 sets it
        // alone), so the delete branch has to check for it too.
        if (am[id] && (am[id].fails || am[id].blindTries)) {
          am[id] = { fails: am[id].fails, failAt: am[id].failAt, why: am[id].why, blindTries: am[id].blindTries };
        } else delete am[id];
        await setLocal({ videoSentThreads: dm, videoAttempts: am });
      }
      const startAt = resumeFrom != null ? Math.min(resumeFrom, files.length) : 0;
      // (v0.21.47) Clips CONFIRMED delivered before this visit come from the
      // marker's own count, never from the resume INDEX: an adopt visit that
      // resumed at N with nothing ever confirmed used to terminal-stamp sent:N.
      // (v0.21.72) on a ledger-started visit (top-up / changed list) the clips
      // held are not a prefix of the list, so the count is the ledger's own.
      const sentBase = keyFlow ? clipOwed(led, fileIds).sentN
        : (resumeFrom != null && done[id] && typeof done[id].sent === "number" ? Math.min(done[id].sent, startAt) : startAt);
      console.debug("[SubSell] video: LOCKED chat + sending clips " + (startAt + 1) + "–" + files.length + " to", id);
      // (v0.21.48) OBLIGATORY VISIBILITY. Chrome defers media loading and pauses
      // rendering in a hidden/occluded tab, so Messenger's uploader never starts
      // until a human clicks the page — the operator's "as soon as I click on the
      // page it starts uploading". For the length of this set the window comes
      // to the front and the tab is activated; focus is handed back afterwards.
      // Setting videoForeground (default on).
      // (v0.21.49) LAYER 1 — the page shim: for this set the page itself reads
      // "visible" and keeps its animation frames ticking even while the tab is
      // really hidden. Needs no focus, no window movement. (A tab kept awake by
      // capture — popup 🔋 — is genuinely visible and skips all of this.)
      if (document.visibilityState !== "visible") {
        shimOn = true;
        try { await Promise.race([ask({ type: "VIS_SHIM", on: true }), sleep(4000)]); } catch (e) { /* best effort */ }
      }
      // LAYER 2 — (v0.21.50) keep the page PAINTING with a picture-in-picture
      // window opened on the extension's own trusted activation: frames tick,
      // media loads, nothing to click, works minimized. Window focus (layer 3)
      // only when PiP is refused.
      // (v0.21.51 SAFE MODE) both are OFF unless the dashboard turns them on
      // (videoPip / videoForeground): a floating window and windows pulled to the
      // front read as "the computer doing crazy stuff" on the operator's desktop.
      if (powerOn("videoPip") && document.visibilityState !== "visible") {
        pipOn = await enterPipForSet(name || id);
        if (pipOn) setStatus({ lastAction: "page kept awake (picture-in-picture) for the video set…", currentThread: name });
      }
      // LAYER 3 — the window comes to the front (verified, one retry).
      if (!pipOn && powerOn("videoForeground") && document.visibilityState !== "visible") {
        fgOn = true;
        setStatus({ lastAction: "bringing this window to the front for the video set…", currentThread: name });
        try { await Promise.race([ask({ type: "VIDEO_FOREGROUND", on: true }), sleep(5000)]); } catch (e) { /* best effort */ }
        await sleep(1500);
        if (document.visibilityState !== "visible") {
          // Windows may refuse the foreground to a process without recent input:
          // once more, un-minimizing first and drawing attention.
          try { await Promise.race([ask({ type: "VIDEO_FOREGROUND", on: true, retry: true }), sleep(5000)]); } catch (e) { /* best effort */ }
          await sleep(1500);
          if (document.visibilityState !== "visible") {
            const ff = (await getLocal(["fgFail"])).fgFail || {};
            await setLocal({ fgFail: { n: (ff.n || 0) + 1, at: Date.now() } });
            setStatus({ videoLast: "window could not be brought to the front (another app kept it) — page shim + trusted input carry the set; 🔋 Keep awake makes this tab visible for good" });
          }
        }
      }

      // ONE-MESSAGE DELIVERY: attach every clip back-to-back (each verified),
      // then a single Enter sends the whole set as ONE message. A clip that
      // provably fails to attach stops the set with a resume marker; whatever
      // is already in the tray still goes out with the one send.
      // A previous visit's LATE-rendered tile is restored with the chat's draft a
      // beat after the chat opens: look for it before deciding the tray is clean.
      {
        const tW = Date.now();
        while (Date.now() - tW < 2500 && trayRemoveBtns().length === 0) await sleep(500);
      }
      // (v0.21.72) A TOP-UP NEVER TOUCHES A COMPOSER IT DID NOT FILL. The chat was
      // already served: an attachment staged here, or text being typed, is the
      // operator's (or unknown) — never swept, never adopted, never sent. Restore
      // the served mark and leave; the buyer's next message tries again.
      if (keyFlow && (trayRemoveBtns().length > 0 || composerText(findComposer()))) {
        const dmK2 = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        if (!(dmK2[id] && dmK2[id].owner && dmK2[id].owner !== TAB_UID)) {
          dmK2[id] = { done: true, at: Date.now(), owner: TAB_UID, sent: sentBase, resumeTotal: files.length };
          await setLocal({ videoSentThreads: dmK2 });
        }
        videoLocked.delete(id);
        vstat("top-up postponed — something is already staged or being typed in " + (name || id) + " (not ours to touch)");
        return;
      }
      // (v0.21.72) a resume written after "the first clip is confirmed in the chat"
      // (noAdopt) follows the fresh-run rule: a tile sitting here is a late COPY of
      // the clip the chat already has — adopting it would send it twice.
      const freshTray = startAt === 0 || !!(done[id] && done[id].noAdopt);
      if (freshTray && trayRemoveBtns().length > 0) {
        await sweepTrayExtras(0); // fresh run: stale strays out before we stack clips
      }
      // Resume runs ADOPT a leftover unsent preview (a crashed run's attached
      // clip, or the tile of a clip the file API staged that rendered after we
      // left) as known-good — it rides the first Enter, finally delivered. The
      // streaming engine keeps at most ONE clip in flight per chat, so more than
      // one leftover is a pile of copies: keep the newest (tail), trim the rest.
      if (startAt > 0 && !freshTray && trayRemoveBtns().length > 1) {
        for (let pass = 0; pass < 3 && trayRemoveBtns().length > 1; pass++) {
          safe(() => trayRemoveBtns()[0].click());
          await sleep(2000);
        }
        if (trayRemoveBtns().length > 1) {
          // Skip this visit, but leave the chat RESUMABLE: the lock stamp above
          // (via:"lock", fresh `at`) would read as "set in progress" for 30 min,
          // and clearPend() already dropped the pending entry — rewrite a plain
          // resume marker and re-queue (the pending lane retries it, paced).
          const dmK = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          if (!(dmK[id] && dmK[id].owner && dmK[id].owner !== TAB_UID)) {
            dmK[id] = { done: true, at: Date.now(), owner: TAB_UID, resumeFrom: startAt, resumeTotal: files.length, sent: sentBase };
            await setLocal({ videoSentThreads: dmK });
          }
          videoLocked.delete(id);
          {
            const qkK = sidebarKey || id;
            if (qkK && videoPending[qkK] == null && videoPending[id] == null) { videoPending[qkK] = Date.now(); persistDedup(); }
          }
          await recordVideoFail(id, "attach"); // (v0.21.42) 3-min pacing — without it lane 1.5 re-opened this chat every scan
          vstat("tray holds " + trayRemoveBtns().length + " stuck previews — skipping this visit (" + (name || id) + ")");
          return;
        }
      }
      let knownCount = trayRemoveBtns().length;
      let okCount = 0;
      let failedAt = -1;    // first clip whose attach provably failed (tray verified clean → re-attempt allowed)
      let dirtyStop = false; // a clip whose attach is UNCONFIRMED — must never be re-attempted
      // STREAMING DELIVERY (v0.21.34, operator: "send whatever can send"): in the
      // one-by-one path each clip is SENT the moment its own upload finishes,
      // instead of being held until the whole set is attached. On builds where
      // Facebook rejects a paste while a previous clip is still uploading (this
      // fleet: every set showed bulk:0 + ~60s per clip) the old hold meant ~4
      // minutes of nothing, then everything at once — and the text reply waited
      // just as long. Now: clip 1 out in ~30s, the reply right behind it (via
      // hooks.onClipSent), clips 2..N streaming after, and between clips the
      // engine YIELDS whenever another buyer is waiting (the tail resumes via
      // the pending lane — a postponement, never a loss). The bulk fast path
      // (all clips landed in one paste) still sends as one message.
      const streaming = !deferSend;
      let streamedCount = 0;
      // Park the un-sent tail (resume marker + pending queue) — shared by the
      // navigation and yield exits of the streaming path.
      const parkTail = async (nextIdx, statusLine) => {
        const dmPk = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        if (dmPk[id] && dmPk[id].owner && dmPk[id].owner !== TAB_UID) return; // taken over — its stamps govern
        dmPk[id] = { done: true, at: Date.now(), owner: TAB_UID, resumeFrom: nextIdx, resumeTotal: files.length, sent: okCount + sentBase };
        await setLocal({ videoSentThreads: dmPk });
        videoLocked.delete(id); // the finishing visit must pass the in-memory guard
        const qkPk = sidebarKey || id;
        if (qkPk && videoPending[qkPk] == null && videoPending[id] == null) { videoPending[qkPk] = Date.now(); persistDedup(); }
        setStatus({ lastAction: statusLine, currentThread: name });
      };

      // FAST PATH: hand the whole remaining set over in ONE paste so Facebook
      // uploads the clips in PARALLEL (a human dragging 3 files at once). This
      // is where the old 30-60s went — serialized uploads plus a settle wait
      // between each. Nothing is SENT until the final Enter, so if the bulk
      // paste lands only partially we can simply clear the tray and fall back
      // to the verified one-by-one path: zero duplicate risk either way.
      let bulkDone = false;
      cdpSetToken++; // new set: a file-API miss inside it skips the file API for its remaining clips only
      // FILE API ⇒ STREAM ONE CLIP AT A TIME (v0.21.38, operator: "send whatever
      // you can, don't wait for all"): no multi-file set — clip 1 is on its way
      // in seconds, the reply rides right behind it, and at most one clip is ever
      // in flight per chat (the property that makes late tiles adoptable instead
      // of a pile). The synthetic multi-paste below stays for machines without it.
      // (the run covers the loadable clips from startAt up to the first missing
      // slot AT OR AFTER it — a missing slot before startAt was already delivered)
      const firstMissingFromStart = files.findIndex((f, k) => k >= startAt && !f);
      const runEnd = firstMissingFromStart >= 0 ? firstMissingFromStart : files.length;
      const cdpPerClip = cdpUsableNow() && runEnd > startAt && paths.slice(startAt, runEnd).every((p, k) => !!p || !!(files[startAt + k] && files[startAt + k].excluded));
      let bulkFiles = null;
      // (v0.21.41) never in streaming mode: a multi-file paste holds every clip for
      // one Enter (against "send whatever you can") and on this fleet it takes zero
      // files anyway (bulk:0) — 10+ s lost per set. Kept only for the dormant
      // hold-and-send mode.
      if (!streaming && !cdpPerClip && runEnd - startAt > 1) {
        bulkFiles = [];
        for (let k = startAt; k < runEnd; k++) {
          const f = files[k];
          if (f && f.excluded) { bulkFiles = null; break; } // a struck-out slot inside the range → one-by-one
          let real = f;
          if (f && f.lazy) { try { real = await f.load(); } catch (e) { real = null; } }
          if (!real) { bulkFiles = null; break; } // can't load one → one-by-one handles it
          files[k] = real; // keep the loaded File — the one-by-one fallback must not reload it
          bulkFiles.push(real);
        }
      }
      if (bulkFiles) {
        const rest = bulkFiles;
        const bulk = await attachVideosBulk(rest, id, paths.slice(startAt));
        safe(() => chrome.storage.local.get(["videoAttachTrace"], (rB) => {
          if (chrome.runtime.lastError) return;
          const tr = (rB && rB.videoAttachTrace) || [];
          tr.push({ at: Date.now(), clip: 0, of: rest.length, res: "bulk:" + String(bulk), tray: trayRemoveBtns().length, up: trayUploads() });
          while (tr.length > 12) tr.shift();
          chrome.storage.local.set({ videoAttachTrace: tr }, () => void chrome.runtime.lastError);
        }));
        if (bulk === "navigated") {
          const dmB2 = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          if (dmB2[id] && dmB2[id].owner && dmB2[id].owner !== TAB_UID) return;
          dmB2[id] = { done: true, at: Date.now(), owner: TAB_UID, resumeFrom: startAt, resumeTotal: files.length, sent: sentBase };
          await setLocal({ videoSentThreads: dmB2 });
          videoLocked.delete(id);
          {
            const qkB2 = sidebarKey || id;
            if (qkB2 && videoPending[qkB2] == null && videoPending[id] == null) { videoPending[qkB2] = Date.now(); persistDedup(); }
          }
          setStatus({ lastAction: "video set interrupted (chat switched) — finishing later", currentThread: name });
          return;
        }
        if (typeof bulk === "number" && bulk >= rest.length) {
          okCount = rest.length;
          // Belt-and-suspenders: never let a surplus preview (any source) ride the
          // single Enter — extras always append at the TAIL, same rule as sweepTrayExtras.
          {
            const expect = knownCount + rest.length;
            if (trayRemoveBtns().length > expect) await sweepTrayExtras(expect);
          }
          knownCount = trayRemoveBtns().length;
          bulkDone = true;
          const dmB = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          if (dmB[id] && dmB[id].owner && dmB[id].owner !== TAB_UID) return;
          dmB[id] = { done: true, at: Date.now(), via: "lock", owner: TAB_UID, sent: okCount + sentBase, resumeFrom: runEnd, resumeTotal: files.length };
          await setLocal({ videoSentThreads: dmB });
          setStatus({ lastAction: `${okCount} video(s) attached together`, currentThread: name });
        } else if (trayRemoveBtns().length > knownCount) {
          await sweepTrayExtras(knownCount); // partial/none: reset (nothing sent yet) and verify one by one
        }
      }

      let loadStop = false; // the loop stopped at a clip that could not be loaded (re-tried later, never skipped)
      let unverifiedStop = false; // the loop stopped at a file-API clip that never showed (one adopt visit later)
      let setVia = "-"; // attach channel used by this set's last clip (cdp / paste) — for the ground-truth check
      let lastSres = null; // outcome of the last streamed send ("sent" / "stuck")
      for (let i = bulkDone ? runEnd : startAt; i < files.length; i++) {
        if (files[i] && files[i].excluded) continue; // struck-out clip URL: send the rest (re-probed hourly)
        // (v0.21.72) NEVER THE SAME CLIP TWICE: a clip the ledger holds for this
        // chat (sent, or handed over once without confirmation) is stepped over —
        // by identity, so a re-ordered list, a clip listed twice or a top-up can
        // never dispatch it again.
        if (heldAt(i)) continue;
        const idsI = fileIds[i] || [];
        if (!files[i]) {
          // Not loadable right now: everything before it is out (or going out);
          // resume exactly here on a later visit. No pre-attempt stamp — the
          // clip was never touched.
          loadStop = true;
          failedAt = i;
          break;
        }
        // Navigation abort: NOTHING has been sent yet (send is one Enter at the
        // end) and Enter must never fire after the operator switched chats.
        // Clips already attached are recorded as attempted (if Messenger kept
        // them as a draft they'd double-send on a re-attempt); the tail resumes
        // on a later visit.
        if (!stillOnThread(id)) {
          console.debug("[SubSell] video: stopped mid-set at clip", i + 1, "— will finish on a later visit", id);
          const dm2 = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          if (dm2[id] && dm2[id].owner && dm2[id].owner !== TAB_UID) return; // taken over — its stamps govern
          dm2[id] = { done: true, at: Date.now(), owner: TAB_UID, resumeFrom: i, resumeTotal: files.length, sent: okCount + sentBase };
          await setLocal({ videoSentThreads: dm2 });
          videoLocked.delete(id); // allow the resume visit through the in-memory guard
          // Queue the finish explicitly: waiting for an organic revisit left tails
          // sitting for hours (both machine diagnostics showed exactly this).
          {
            const qk2 = sidebarKey || id;
            if (qk2 && videoPending[qk2] == null && videoPending[id] == null) { videoPending[qk2] = Date.now(); persistDedup(); }
          }
          setStatus({ lastAction: `video set paused at ${i}/${files.length} — finishing later`, currentThread: name });
          return;
        }
        {
          // TAKEOVER check: if another pass lock-stamped this chat (its `owner`),
          // bow out silently — the new owner resumes strictly AFTER our last
          // stamped clip, so nothing double-sends and nothing is skipped.
          const curM = ((await getLocal(["videoSentThreads"])).videoSentThreads || {})[id];
          if (curM && curM.owner && curM.owner !== TAB_UID) {
            console.debug("[SubSell] video: another pass took over this set — bowing out", id);
            return;
          }
          // PRE-ATTEMPT stamp: exclude the CURRENT clip from any future resume
          // BEFORE touching it — a crash anywhere inside the attempt (even after
          // Enter fired) can then never re-send it. This keeps the original
          // "attempted clips never repeat" law under the new resume machinery;
          // the cost is the old accepted trade (a crashed attempt's clip may be
          // missed, never duplicated). Also refreshes `at` (the in-flight signal)
          // and stamps ownership for the takeover check above.
          const dmA = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          dmA[id] = { done: true, at: Date.now(), via: "lock", owner: TAB_UID, sent: okCount + sentBase, resumeFrom: i + 1, resumeTotal: files.length };
          await setLocal({ videoSentThreads: dmA });
        }
        setStatus({ lastAction: `attaching video ${i + 1}/${files.length}…`, currentThread: name });
        // (v0.21.77) every slot's byte size (disk record, else a loaded File) — lets the
        // probe name a clip that was handed over in place of this one (trace "dup:")
        const setSizes = files.map((f, k) => (paths[k] && diskSizeByPath[paths[k]]) || (f && !f.lazy && !f.excluded && typeof f.size === "number" ? f.size : 0));
        let res = await attachVideo(files[i], knownCount, id, paths[i], { justSend, setSizes, slot: i, onTick: () => { busySince = Date.now(); refreshThreadLock(sidebarKey || id); } });
        const resVia = lastAttachVia;
        const resDup = lastAttachDupOf; // read now — the trace below is written from a storage callback
        if (resDup) vstat("clip " + (i + 1) + ": Messenger was handed " + resDup + " in its place (" + (name || id) + ")");
        if (resVia && resVia !== "-") setVia = resVia;
        const resTrace = res === true ? "ok" : String(res);
        // ATTACH TRACE (ring of 12, shown in 🩺): which clip, what verdict, how
        // the tray looked — ends the guessing when a machine's attaches fail.
        safe(() => chrome.storage.local.get(["videoAttachTrace"], (rT) => {
          if (chrome.runtime.lastError) return;
          const tr = (rT && rT.videoAttachTrace) || [];
          tr.push({ at: Date.now(), clip: i + 1, of: files.length, res: resTrace + (resVia && resVia !== "-" ? "/" + resVia : "") + (lastAttachRx && lastAttachRx !== "-" ? " rx:" + lastAttachRx : "") + (resDup ? " dup:" + resDup : ""), tray: trayRemoveBtns().length, up: trayUploads() });
          while (tr.length > 12) tr.shift();
          chrome.storage.local.set({ videoAttachTrace: tr }, () => void chrome.runtime.lastError);
        }));
        if (res === "aborted") {
          // Navigated BEFORE anything was dispatched (v0.21.41): clip i was never
          // touched — resume AT i (the pre-attempt stamp said i+1; correct it).
          const dmAb = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          if (dmAb[id] && dmAb[id].owner && dmAb[id].owner !== TAB_UID) return;
          dmAb[id] = { done: true, at: Date.now(), owner: TAB_UID, resumeFrom: i, resumeTotal: files.length, sent: okCount + sentBase };
          await setLocal({ videoSentThreads: dmAb });
          videoLocked.delete(id);
          {
            const qkAb = sidebarKey || id;
            if (qkAb && videoPending[qkAb] == null && videoPending[id] == null) { videoPending[qkAb] = Date.now(); persistDedup(); }
          }
          setStatus({ lastAction: "video set interrupted (chat switched) — finishing later", currentThread: name });
          return;
        }
        if (res === "navigated") {
          // Mid-attach navigation: clip i counts as ATTEMPTED (its paste may have
          // landed somewhere unverifiable — re-attempting could double-send);
          // clips already attached stay in this chat's draft and are ADOPTED by
          // the queued resume visit if Messenger kept them. Nothing is sent now.
          const dmN = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          if (dmN[id] && dmN[id].owner && dmN[id].owner !== TAB_UID) return;
          dmN[id] = { done: true, at: Date.now(), owner: TAB_UID, resumeFrom: i + 1, resumeTotal: files.length, sent: okCount + sentBase };
          await setLocal({ videoSentThreads: dmN });
          videoLocked.delete(id);
          {
            const qkN = sidebarKey || id;
            if (qkN && videoPending[qkN] == null && videoPending[id] == null) { videoPending[qkN] = Date.now(); persistDedup(); }
          }
          setStatus({ lastAction: "video set interrupted (chat switched) — finishing later", currentThread: name });
          return;
        }
        if (res === true || res === "blind") {
          okCount++;
          // (v0.21.72) the ledger learns it the moment the engine counts it
          clipMark(led, idsI, "s", Date.now());
          await clipLedgerPut(id, (e) => clipMark(e, idsI, "s", Date.now()));
          // Count-based, +1 exactly: re-snapshotting the whole tray here would
          // absorb an undetected stray copy into the "known-good" set and let it
          // ride the Enter as a duplicate.
          knownCount += 1;
          // Progress stamp: the attached count is recorded IMMEDIATELY, so a
          // mid-set death can never look like "nothing sent" and get re-queued.
          // Never clobber a takeover: if another pass owns the mark now, bow out
          // WITHOUT stamping — it resumed after our last stamped clip, so this
          // clip is excluded from its run (undercounted, never re-sent).
          const dmP2 = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          if (dmP2[id] && dmP2[id].owner && dmP2[id].owner !== TAB_UID) return;
          dmP2[id] = { done: true, at: Date.now(), via: "lock", owner: TAB_UID, sent: okCount + sentBase, resumeFrom: i + 1, resumeTotal: files.length };
          await setLocal({ videoSentThreads: dmP2 });
          if (streaming) {
            // (v0.21.47) promoted only on a NEW tile (a persistent blob/listing
            // <video> outside the rows used to promote an empty tray to "exact-count")
            if (res === "blind" && trayRemoveBtns().length >= knownCount) res = true; // the tile showed after all → normal exact-count send
            // (the upload wait lives inside sendStagedClip now — it never presses mid-upload)
            if (!stillOnThread(id)) {
              await parkTail(i + 1, `video set paused at ${i}/${files.length} (chat switched) — finishing later`);
              return;
            }
            // EXACTLY ONE MESSAGE'S WORTH before Enter (v0.21.38): known head + this
            // clip. A surplus tile is an earlier attempt's late copy — trimmed; if
            // it won't go, nothing is sent (the clip counts as attempted and the
            // set stops here rather than posting a pile — the PC-mnbbd tray7 case).
            if (res === true && !(await trimTraySurplus(knownCount))) {
              okCount--;
              // (v0.21.72) not sent after all — but it WAS handed over: tried, never again
              clipMark(led, idsI, "clear"); clipMark(led, idsI, "t", Date.now());
              await clipLedgerPut(id, (e) => { clipMark(e, idsI, "clear"); clipMark(e, idsI, "t", Date.now()); });
              dirtyStop = true;
              failedAt = i;
              // Empty the tray entirely before leaving: the text reply that
              // follows this visit presses Enter in the same composer, and a
              // staged pile would ride it. Losing our own copy is the safe side
              // (this clip is stamped attempted; the set resumes after it).
              await sweepTrayExtras(0);
              // (v0.21.42) skip-forward stays: this clip's tile WAS seen, and on a
              // late-rendering machine one more copy can surface after the sweep —
              // re-dispatching it later could pair with that copy. Law 1 wins.
              vstat("tray holds extra previews that won't clear — not sending a pile (" + (name || id) + ")");
              break;
            }
            if (res === "blind" && composerText(findComposer())) {
              // The operator started typing here: their Enter will carry the
              // staged clip; ours must not ship their half-typed text.
              await parkTail(i + 1, `video set paused at ${i}/${files.length} (you are typing) — finishing later`);
              return;
            }
            setStatus({ lastAction: `sending video ${i + 1}/${files.length}…`, currentThread: name });
            const sres = await sendStagedClip(id, res !== true, () => { busySince = Date.now(); refreshThreadLock(sidebarKey || id); });
            if (sres === "navigated") {
              await parkTail(i + 1, `video set paused at ${i + 1}/${files.length} (chat switched) — finishing later`);
              return;
            }
            streamedCount++;
            lastSres = sres;
            if (sres === "stuck") {
              // The tile would not go after six rounds: leave it STAGED (it is a due
              // clip — the next clip's Enter, or the text reply's, carries it) and
              // count it as known so the next attach is still exact.
              knownCount = trayRemoveBtns().length;
              vstat("clip " + (i + 1) + " stays staged — Messenger did not take the send yet; it rides the next Enter (" + (name || id) + ")");
            } else if (res === true) {
              // Tray verified empty by the send; a stray that renders late now can
              // only be an older leftover — remove it, never adopt it.
              knownCount = await settleTrayAfterSend(id);
            } else {
              knownCount = trayRemoveBtns().length; // blind: a tile showing now may be our own clip still uploading — carry it
            }
            refreshThreadLock(sidebarKey || id); // uploads outlive the cross-tab lease
            if (hooks && typeof hooks.onClipSent === "function") {
              // Interleave the TEXT reply right after the first clip (the reply
              // path honors its own delay clock and reports its own errors).
              try { await hooks.onClipSent(i); } catch (e) { /* never break the set */ }
              if (!stillOnThread(id)) {
                await parkTail(i + 1, `video set paused at ${i + 1}/${files.length} (chat switched) — finishing later`);
                return;
              }
            }
            // (v0.21.41) with the file API usable a clip costs seconds, so only an
            // OVERDUE buyer (lane-0 evidence) interrupts the set; on the synthetic
            // path (minutes per clip) any waiting buyer still does.
            // (v0.21.72) …and only when a clip is actually still DUE after this one:
            // a tail of struck-out or already-held clips is not worth a parked visit.
            if (moreDueAfter(i) && (cdpUsableNow() ? buyersWaitingCount(id, sidebarKey, true) > 0 : buyersWaitingNow(id, sidebarKey))) {
              // YIELD: someone else is waiting for a reply. Their answer outranks
              // this chat's remaining clips — the tail is queued (pending lane,
              // guaranteed delivery), not dropped, and no failure is recorded.
              await parkTail(i + 1, `${okCount + sentBase}/${files.length} videos sent — pausing for a waiting buyer, finishing later`);
              vstat("sent " + (okCount + sentBase) + "/" + files.length + " — yielded to a waiting buyer, finishing later (" + (name || id) + ")");
              ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: "(demo video)", action: "video", reply: (okCount + sentBase) + "/" + files.length + " demo videos sent — finishing the rest after a waiting buyer" + clipNamesSent() } });
              return;
            }
          }
        } else if (res === "dirty" || res === "unverified") {
          // Attach unconfirmed AND the tray couldn't be verified clean ("dirty"),
          // or the browser accepted a file-API set that showed nothing yet
          // ("unverified" — a late tile is possible, and the resume visit adopts
          // it): treat the clip as attempted (the pre-attempt stamp already
          // excludes it) and stop — never dispatch a second copy.
          dirtyStop = true;
          failedAt = i;
          // (v0.21.72) handed over, never confirmed: the ledger keeps it as tried
          clipMark(led, idsI, "t", Date.now());
          await clipLedgerPut(id, (e) => clipMark(e, idsI, "t", Date.now()));
          if (res === "unverified") unverifiedStop = true;
          if (res === "unverified") {
            // FLUSH: if the clip IS staged invisibly, one Enter on the (text-empty)
            // composer sends it — delivered instead of lost, and consistent with
            // the skip-forward stamp; on a truly empty composer Enter is a no-op.
            const cF = findComposer();
            if (cF && stillOnThread(id) && !composerText(cF)) pressEnter(cF);
            vstat("clip " + (i + 1) + " handed to the composer but nothing showed — finishing later, never twice (" + (name || id) + ")");
          }
          break;
        } else {
          // attachVideo=false ⇒ no new preview appeared AND extras were cleaned ⇒
          // nothing of this clip can ride the send — re-attempting it later
          // cannot duplicate.
          failedAt = i;
          break;
        }
      }
      // THE ONE SEND: everything attached (new clips + any adopted leftovers)
      // goes out with a single Enter. Never pressed on an empty tray, and never
      // after navigation — and a navigation-blocked send must NEVER fall through
      // to the terminal "sent ✓" stamp (that would record a full set the buyer
      // never received). The attached draft is adopted by the queued resume
      // visit if Messenger kept it.
      const attachedNow = trayRemoveBtns().length;
      let adoptedN = 0; // (v0.21.47) leftover tiles a resume visit adopted and sent below — evidence too
      if (okCount > 0) noteAttachMiss(false); // this machine's channel IS taking
      // Streamed clips already went out one by one — nothing is held for a final Enter.
      const wantSend = streamedCount > 0 ? false : (okCount > 0 || (startAt > 0 && attachedNow > 0));
      if (wantSend && !stillOnThread(id)) {
        const dmB = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        if (!(dmB[id] && dmB[id].owner && dmB[id].owner !== TAB_UID)) {
          dmB[id] = { done: true, at: Date.now(), owner: TAB_UID, resumeFrom: failedAt >= 0 ? ((dirtyStop && !loadStop) ? failedAt + 1 : failedAt) : files.length, resumeTotal: files.length, sent: okCount + sentBase };
          await setLocal({ videoSentThreads: dmB });
        }
        videoLocked.delete(id);
        {
          const qkB = sidebarKey || id;
          if (qkB && videoPending[qkB] == null && videoPending[id] == null) { videoPending[qkB] = Date.now(); persistDedup(); }
        }
        vstat("set attached but chat switched before the send — finishing on a later visit (" + (name || id) + ")");
        setStatus({ lastAction: "video send postponed (chat switched) — finishing later", currentThread: name });
        return;
      }
      // Tray/bookkeeping mismatch = something attached or vanished that we can't
      // explain — send what's there, but never RE-ATTEMPT ambiguous clips
      // (skip-forward), the duplicate-safe direction.
      const trayMismatch = wantSend && attachedNow !== knownCount;
      if (wantSend && deferSend) {
        // COMBINED-MESSAGE MODE: leave the set STAGED — the caller types the text
        // reply into the same composer and ONE Enter ships videos + text together.
        // CRITICAL: nothing has been sent yet, so NO terminal stamp, NO "sent ✓"
        // status and NO Activity row here — those fire in
        // finalizeDeferredVideoSend() only after an Enter actually goes. The mark
        // becomes an owned DRAFT (resumeFrom = resumeTotal = full set attached):
        // if this visit is abandoned, the queued pending visit adopts the draft
        // and ships it through the normal send path.
        videoSendDeferred = true;
        {
          const dmD = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          if (!(dmD[id] && dmD[id].owner && dmD[id].owner !== TAB_UID)) {
            dmD[id] = {
              done: true, at: Date.now(), via: "lock", owner: TAB_UID, sent: okCount + sentBase,
              // Partial attach: the tail stays resumable (same skip-forward rules
              // as the normal partial branch); full attach: resumeFrom = total.
              resumeFrom: failedAt >= 0 ? (loadStop ? failedAt : ((dirtyStop || trayMismatch) ? failedAt + 1 : failedAt)) : files.length,
              resumeTotal: files.length,
            };
            await setLocal({ videoSentThreads: dmD });
          }
        }
        videoLocked.delete(id); // DRAFT is not terminal — finalize re-locks
        {
          const qkD = sidebarKey || id;
          if (qkD && videoPending[qkD] == null && videoPending[id] == null) { videoPending[qkD] = Date.now(); persistDedup(); }
        }
        setStatus({ lastAction: `${Math.max(attachedNow, okCount)} video(s) staged — sending with the reply…`, currentThread: name });
        return;
      }
      if (wantSend) {
        setStatus({ lastAction: `sending ${Math.max(attachedNow, okCount)} video(s) in one message…`, currentThread: name });
        // (v0.21.72) an adopted leftover may STILL be uploading (a heavy clip left
        // staged by the previous visit): never press mid-upload — Messenger drops it.
        {
          const tU = Date.now();
          while (Date.now() - tU < 150000 && uploadingInBand()) { if (!stillOnThread(id)) break; await sleep(1000); busySince = Date.now(); }
        }
        await sendAttachedVideos();
        if (okCount === 0 && attachedNow > 0) adoptedN = attachedNow; // adopted leftovers went out with that Enter
        if (adoptedN > 0) {
          // (v0.21.72) what just went out is a clip handed over earlier: tried → sent
          const nowA = Date.now();
          for (const k of Object.keys(led.t)) { led.s[k] = nowA; delete led.t[k]; }
          await clipLedgerPut(id, (e) => { for (const k of Object.keys(e.t)) { e.s[k] = nowA; delete e.t[k]; } });
        }
      }
      if (okCount === 0 && startAt === 0 && !dirtyStop && !keyFlow) {
        // NOTHING attached in this whole run, with the tray VERIFIED CLEAN (no
        // preview, and Messenger's own send control never left its empty state).
        // Nothing can possibly have been sent, so undoing the lock and retrying
        // cannot duplicate. (A dirty stop is NOT undone here — the resume marker
        // below skips the unverifiable clip; the terminal check catches a chat
        // that ends with zero confirmed clips.)
        // Fleet-visible breadcrumb, max one per 24h per machine (state-change only):
        // an attach-stage failure means this account's FB upload UI needs attention.
        const thrAt = (await getLocal(["videoAttachFailLoggedAt"])).videoAttachFailLoggedAt || 0;
        if (Date.now() - thrAt > 24 * 3600 * 1000) {
          await setLocal({ videoAttachFailLoggedAt: Date.now() }); // written BEFORE posting so two tabs can't double-log
          ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: "(video attach failure)", action: "video-status", reply: "0/" + files.length + " attached — no attach channel staged a clip (" + (lastAttachVia || "-") + "); FB upload UI may have changed on this machine" } });
        }
        // (v0.21.47) bounded retry + link fallback (was: unlock + unbounded retry)
        await zeroEvidenceExit("attach", files.length, failedAt >= 0 ? fileIds[failedAt] : null);
        return;
      }
      if (failedAt >= 0) {
        // PARTIAL set (some clips delivered, or a resume tail that attached 0):
        // record the exact tail and finish on a later, paced visit. Previously a
        // failed resume tail fell through to the terminal stamp — the mark burned
        // to {done, sent:2} forever and logged "0 demo video(s) sent" (machine
        // PC-o9ppb's whole sidebar was sent2 for exactly this reason).
        // A CLEAN failure re-attempts the failed clip (provably nothing attached);
        // a DIRTY one skips it forever (attach unverifiable — never risk a dup).
        {
          const chk = ((await getLocal(["videoSentThreads"])).videoSentThreads || {})[id];
          if (chk && chk.owner && chk.owner !== TAB_UID) return; // taken over — its stamps govern
        }
        // (v0.21.47) a FRESH chat whose very first clip was handed over with no
        // signal at all ("unverified", flush Enter already pressed) has nothing
        // confirmed: the bounded-retry policy takes it now, instead of skipping
        // forward one clip per visit for the rest of the set.
        // (v0.21.67) …except a clip Messenger provably HOLDS (the reaction probe
        // saw it read): it may surface in the tray once the tab is shown, so it
        // gets the ONE adopt visit below first (trimmed to one and sent), and only
        // an empty tray on that visit reaches the bounded retry.
        if (unverifiedStop && !loadStop && startAt === 0 && !keyFlow && okCount + adoptedN === 0 && !(lastAttachHeld && !(done[id] && done[id].unverifiedTail))) {
          await zeroEvidenceExit("unconfirmed", files.length, fileIds[failedAt]);
          return;
        }
        // A LOAD stop never skips: the clip at failedAt was never touched.
        const resumeAtF = loadStop ? failedAt : ((dirtyStop || trayMismatch) ? failedAt + 1 : failedAt);
        if (resumeAtF >= files.length && unverifiedStop) {
          // (v0.21.41) the LAST clip was handed to the composer but never showed:
          // keep the chat resumable for ONE adopt visit — if its tile renders late
          // (Messenger restores it with the draft) that visit sends it; if the tray
          // is empty the visit terminal-stamps. Never re-dispatched (the reply's
          // Enter already flushed an invisibly staged clip).
          const dmU = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          dmU[id] = { done: true, at: Date.now(), owner: TAB_UID, resumeFrom: files.length, resumeTotal: files.length, sent: okCount + sentBase, unverifiedTail: 1 };
          await setLocal({ videoSentThreads: dmU });
          videoLocked.delete(id);
          {
            const qkU = sidebarKey || id;
            if (qkU && videoPending[qkU] == null && videoPending[id] == null) { videoPending[qkU] = Date.now(); persistDedup(); }
          }
          vstat("sent " + (okCount + sentBase) + "/" + files.length + " — last clip handed over but not shown; one adopt visit later (" + (name || id) + ")");
          if (okCount > 0) ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: "(demo video)", action: "video", reply: (okCount + sentBase) + "/" + files.length + " demo videos sent — last clip checked on a later visit" } });
          return;
        }
        if (resumeAtF >= files.length && okCount + sentBase + adoptedN === 0) {
          // (v0.21.47) the whole chat ends with ZERO confirmed clips: not a
          // confirmed mark — bounded retry / link fallback instead.
          await zeroEvidenceExit("unconfirmed", files.length, fileIds[failedAt]);
          return;
        }
        if (resumeAtF >= files.length) {
          // Nothing left to resume (dirty on the LAST clip) — terminal-stamp what
          // was actually delivered; the unverifiable tail clip is dropped (the
          // long-standing "never repeat an attempted clip" trade). resumeTotal
          // marks the stamp as protocol-confirmed so the catch-up arm keeps it
          // even when sent is 0 (single-clip dirty case).
          const dmT = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          dmT[id] = { done: true, at: Date.now(), owner: TAB_UID, sent: okCount + sentBase, resumeTotal: files.length };
          await setLocal({ videoSentThreads: dmT });
          vstat("sent " + (okCount + sentBase) + "/" + files.length + " — last clip unverifiable, dropped to stay duplicate-safe (" + (name || id) + ")");
          if (okCount > 0) ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: "(demo video)", action: "video", reply: (okCount + sentBase) + "/" + files.length + " demo video(s) sent" } });
          return;
        }
        if (okCount === 0) await noteAttachMiss(true); // a tail visit that confirmed nothing counts against the machine too
        const dmF = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        dmF[id] = { done: true, at: Date.now(), owner: TAB_UID, resumeFrom: resumeAtF, resumeTotal: files.length, sent: okCount + sentBase };
        await setLocal({ videoSentThreads: dmF });
        videoLocked.delete(id); // the finishing visit must pass the in-memory guard
        await recordVideoFail(id, loadStop ? "load" : "attach"); // short backoff only (v0.21.40)
        {
          const qkF = sidebarKey || id;
          if (qkF && videoPending[qkF] == null && videoPending[id] == null) { videoPending[qkF] = Date.now(); persistDedup(); }
        }
        const whyF = loadStop ? "couldn't load yet" : "didn't attach";
        vstat("sent " + (okCount + sentBase) + "/" + files.length + " — clip " + (failedAt + 1) + " " + whyF + "; finishing on a later visit (" + (name || id) + ")");
        setStatus({ lastError: "video: " + (okCount + sentBase) + "/" + files.length + " sent, clip " + (failedAt + 1) + " " + whyF + " — will finish later", currentThread: name });
        if (okCount > 0) ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: "(demo video)", action: "video", reply: (okCount + sentBase) + "/" + files.length + " demo videos sent — finishing the rest on a later visit" + clipNamesSent() } });
        return;
      }
      // (v0.21.47) A chat that reaches the terminal with ZERO confirmed clips (an
      // adopt visit on an empty tray, a set of unverified clips…) is NOT served.
      if (okCount + sentBase + adoptedN === 0) {
        await zeroEvidenceExit("unconfirmed", files.length);
        return;
      }
      // Stamp the mark as a CONFIRMED send (sent count) so the backlog catch-up can
      // tell genuine sends from old ambiguous marks and never re-queues this chat.
      {
        const dmS = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        if (dmS[id] && dmS[id].owner && dmS[id].owner !== TAB_UID) return; // taken over — its stamps govern
        // `owner` stays on the terminal stamp: without it, a >30-min-stalled pass
        // that wakes AFTER another pass finished would see no owner, pass every
        // takeover check, and re-send the tail on top of the finished set.
        // (v0.21.72) THE LAST CLIP IS STILL STAGED ("stuck": its tile never left —
        // typically a heavy clip whose upload had not finished). It used to be
        // stamped "sent" and the bot walked on to the next chat: unless the watcher
        // caught it on the very next scan, the clip stayed in this chat's draft and
        // the buyer got one video fewer. Now the chat keeps ONE adopt visit (the
        // same marker an unverified last clip gets): that visit waits the upload
        // out and sends the leftover tile; an empty tray there closes the chat.
        // Never a second dispatch — the clip is in the ledger as handed over.
        const stuckTail = lastSres === "stuck" && okCount > 0 && stillOnThread(id) && trayRemoveBtns().length > 0;
        if (stuckTail) {
          dmS[id] = { done: true, at: Date.now(), owner: TAB_UID, sent: Math.max(0, okCount + sentBase + adoptedN - 1), resumeFrom: files.length, resumeTotal: files.length, unverifiedTail: 1, stuck: 1 };
          await setLocal({ videoSentThreads: dmS });
          videoLocked.delete(id);
          const qkSt = sidebarKey || id;
          if (qkSt && videoPending[qkSt] == null && videoPending[id] == null) { videoPending[qkSt] = Date.now(); persistDedup(); }
          vstat("sent " + (okCount + sentBase + adoptedN - 1) + "/" + files.length + " — the last clip is still staged (upload not finished); one more visit sends it (" + (name || id) + ")");
          if (okCount > 1 || sentBase + adoptedN > 0) ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: "(demo video)", action: "video", reply: (okCount + sentBase + adoptedN - 1) + "/" + files.length + " demo videos sent — last clip checked on a later visit" } });
          return;
        }
        dmS[id] = { done: true, at: Date.now(), owner: TAB_UID, sent: okCount + sentBase + adoptedN };
        // last clip left staged (Messenger would not take the send): the watcher keeps
        // pressing while this chat is open. (v0.21.72) …also when the adopt visit's
        // own send left the tile where it was.
        if (lastSres === "stuck" || (adoptedN > 0 && stillOnThread(id) && trayRemoveBtns().length > 0)) dmS[id].stuck = 1;
        const amS = (await getLocal(["videoAttempts"])).videoAttempts || {};
        if (amS[id]) delete amS[id]; // full set delivered — clean fail/claim slate
        await setLocal({ videoSentThreads: dmS, videoAttempts: amS });
      }
      vstat("sent ✓ " + (okCount + sentBase + adoptedN) + "/" + files.length + " to " + (name || id));
      setStatus({ lastAction: `demo video(s) sent ✓ (${okCount + sentBase + adoptedN}/${files.length})`, currentThread: name });
      // Mirror to the local + cloud activity log (fire-and-forget; no effect on sending).
      // (v0.21.72) the row NAMES the clips this chat now holds, and is written only
      // when this visit actually sent something (a closing visit with nothing new
      // used to add a second identical row).
      if (okCount + adoptedN > 0) ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: "(demo video)", action: "video", reply: (okCount + sentBase + adoptedN) + "/" + files.length + " demo video(s) sent" + clipNamesSent() } });
      // A chat that still owes a NEVER-ATTEMPTED clip (its download was struck out
      // today) is not latched for the session: its buyer's next message tops it up.
      if (completeSet && clipOwed(led, fileIds).owed.length > 0) videoLocked.delete(id);
      // GROUND TRUTH (v0.21.43): the protocol said "sent" — does a video of ours
      // now show in this chat? This is the only signal that cannot lie about the
      // attach channel. Three unseen sets in a row switch the channel (file API ↔
      // paste) for this machine and post ONE fleet-visible row; the mark keeps
      // `unseen:1` for the diagnostic. Never an automatic re-send (law 1) — the
      // popup's "Resend video to OPEN chat" is the operator's manual lever.
      // Only a set whose last send was accepted ("sent") counts, and only after the
      // optimistic message has had time to render on a throttled page (20 s) —
      // a "stuck" send is a SEND problem, not an attach-channel one.
      if (okCount > 0 && lastSres === "sent" && stillOnThread(id)) {
        await sleep(20000);
        if (!stillOnThread(id)) return;
        // (v0.21.53) the sidebar's own "You sent a video." counts too — on a hidden
        // tab the geometric detector cannot see anything and used to report every
        // delivered set as unseen, which cleared the learned channel every 3 sets
        // and latched the machine into reply-first rush mode for ever.
        const seenInChat = chatAlreadyHasOurVideo() || sidebarSaysWeSentVideo(id, sidebarKey);
        await noteSetOutcome(seenInChat, setVia, id, name);
        if (seenInChat) await noteAttachMiss(false); // this machine's channel IS delivering
        if (!seenInChat) {
          const dmG = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          if (dmG[id] && dmG[id].done) { dmG[id] = Object.assign({}, dmG[id], { unseen: 1 }); await setLocal({ videoSentThreads: dmG }); }
        }
      }
    } catch (e) {
      vstat("error: " + e.message);
      setStatus({ lastError: "video error: " + e.message });
      // (v0.21.41) STATE REPAIR: an exception between our lock write and the first
      // clip stamp (background restart, DOM helper throw) used to leave a bare lock
      // that read as "already sent" until heal (i). Nothing was attached (attach is
      // preview-based and the first stamp precedes every dispatch), so undo it now.
      try {
        const cm = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        const m = cm[id];
        if (m && m.via === "lock" && m.owner === TAB_UID && !m.sent && typeof m.resumeFrom !== "number") {
          delete cm[id];
          await setLocal({ videoSentThreads: cm });
          videoLocked.delete(id);
          const qkE = sidebarKey || id;
          if (qkE && videoPending[qkE] == null && videoPending[id] == null) { videoPending[qkE] = Date.now(); persistDedup(); }
        }
      } catch (e2) { /* best effort */ }
    } finally {
      if (fgOn) { fgOn = false; ask({ type: "VIDEO_FOREGROUND", on: false }); } // hand focus back
      if (pipOn) { pipOn = false; exitPipForSet(); } // the PiP window closes with the set
      if (shimOn) { shimOn = false; ask({ type: "VIS_SHIM", on: false }); } // the page reads the truth again
    }
  }

  // Smart follow-up on a quiet chat (WE spoke last). Gated by configurable quiet
  // period + a per-chat count cap so it can never spam. Claude decides whether
  // there's room (or returns [SKIP]). State per thread: { lastAt, count }.
  // How long ago was this row's last activity, per the SIDEBAR time tag ("· 22m",
  // "· 2h", "· 3j")? Lets an already-long-quiet chat qualify for a follow-up on its
  // FIRST visit instead of restarting the whole quiet clock from zero.
  function sidebarQuietMs(anchor) {
    const t = safe(() => anchor.innerText || "", "");
    let last = null;
    const re = /(?:^|[\s·•])(\d{1,3})\s?(min|m|h|hr|j|d)\b/gi;
    let m;
    while ((m = re.exec(t)) !== null) last = m;
    if (!last) return null;
    const n = parseInt(last[1], 10);
    const u = last[2].toLowerCase();
    if (u === "m" || u === "min") return n * 60 * 1000;
    if (u === "h" || u === "hr") return n * 3600 * 1000;
    return n * 24 * 3600 * 1000; // j / d
  }
  async function maybeFollowUp(id, name, anchor) {
    try {
      const settings = (await ask({ type: "GET_SETTINGS" })).settings || {};
      if (!settings.smartFollowupEnabled) return;
      const maxCount = Math.max(0, Number(settings.smartFollowupMaxCount) || 0);
      if (maxCount <= 0) return;
      const quietH = settings.smartFollowupQuietHours != null ? Number(settings.smartFollowupQuietHours) : 6;
      const gapH = settings.smartFollowupGapHours != null ? Number(settings.smartFollowupGapHours) : 24;

      // ---- ANTI-SPAM CAP (read from the actual conversation) ----
      // Count how many messages in a row at the end are OURS. The first is our
      // reply; any beyond that are follow-ups already sent. If we've hit the cap,
      // send NOTHING. (max=1 → stop once the last 2 messages are both ours.)
      const botTail = botTailCount();
      if (botTail === 0) return; // buyer actually spoke last → not a follow-up case
      const followupsDone = botTail - 1;
      if (followupsDone >= maxCount) return; // already followed up enough → STOP

      // ---- COST GUARD: dead-lead cutoff ----
      // Every follow-up evaluation is a full-price API call even when the model
      // just answers [SKIP]. A chat quiet for over a week is not coming back —
      // don't pay to keep re-asking about it. Fresh leads are unaffected.
      const quietNow = anchor ? sidebarQuietMs(anchor) : null;
      if (quietNow != null && quietNow > 7 * 24 * 3600 * 1000) return;

      // ---- TIME GATE ----
      const store = (await getLocal(["followUpState"])).followUpState || {};
      const now = Date.now();
      const thresholdMs = (followupsDone === 0 ? quietH : gapH) * 3600 * 1000;
      let st = store[id];
      if (!st) {
        // First time we notice this quiet chat. If the SIDEBAR already shows it's
        // been quiet longer than the threshold, it qualifies NOW — restarting the
        // whole clock here was a big reason follow-ups "never happened".
        const quietMs = anchor ? sidebarQuietMs(anchor) : null;
        if (quietMs != null && quietMs >= thresholdMs) {
          st = { lastAt: now - thresholdMs - 60000 }; // eligible immediately
        } else {
          store[id] = { lastAt: now };
          await setLocal({ followUpState: store });
          return;
        }
      }
      if (now - (st.lastAt || 0) < thresholdMs) return; // not quiet long enough yet

      // ---- COST GUARD: skip cap ----
      // Three consecutive [SKIP] verdicts for the same chat won't turn into a
      // yes on the 10th try — stop billing evaluations for it. A follow-up that
      // actually SENDS resets the count (the chat proved alive again).
      if ((st.skips || 0) >= 3) return;

      // Pre-call guard: reading the transcript and paying for an evaluation is
      // pointless (and would read the WRONG chat) if the operator has already
      // navigated away — the post-call guard below only threw the paid result out.
      if (!stillOnThread(id)) return;

      const transcript = fullTranscript();
      if (!transcript) return;
      // Billed-followup memo: a follow-up that was paid for but never delivered
      // (chat switch, missing composer, send failure) is replayed on the next
      // pass instead of re-billed — only while the chat transcript and the
      // settings are byte-identical; anything changed voids the memo.
      const fp = JSON.stringify(settings);
      const memoValid = !!(st.pendingText && st.pendingFor === transcript && st.pendingFp === fp);
      if (!memoValid && st.pendingText) { delete st.pendingText; delete st.pendingFor; delete st.pendingFp; }
      const r = await ask({ type: "GET_FOLLOWUP", context: transcript, memContext: fullTranscript(40) || transcript, threadName: name, threadId: id, pendingText: memoValid ? st.pendingText : undefined });
      if (!r || !r.ok) {
        setStatus({ lastError: "follow-up: " + (r && r.error), currentThread: name });
        return;
      }
      // Advance the clock: a SENT follow-up restarts it fully; a Claude [SKIP] only
      // pushes it HALF a period (a full reset meant a few skips = never following up).
      // TITLE-ECHO GUARD: the model occasionally echoes the thread label ("Svargood ·
      // S25 ultra S23 ultra…") as its whole answer — one machine SENT that to a
      // buyer as a "follow-up". A real follow-up never begins with the full
      // "Name · listing" label; treat an echo as a skip, never type it.
      const titleEcho = !!(r.text && name && normMsg(name).length >= 8 && normMsg(r.text).startsWith(normMsg(name)));
      const skipped = r.skip || !r.text || !r.text.trim() || titleEcho;
      st.lastAt = skipped ? now - Math.floor(thresholdMs / 2) : now;
      st.skips = skipped ? (st.skips || 0) + 1 : 0; // 3 in a row → skip-cap above stops the spend
      // Store the billed text BEFORE the send attempt — any abort below keeps it
      // for a free replay next pass. (A skip must not clear an existing memo.)
      if (!skipped) { st.pendingText = r.text; st.pendingFor = transcript; st.pendingFp = fp; }
      store[id] = st;
      await setLocal({ followUpState: store });
      if (skipped) {
        setStatus({ lastAction: "follow-up: no room (" + (r.reason || "skip") + ")", currentThread: name });
        return;
      }
      if (!stillOnThread(id)) {
        setStatus({ lastAction: "follow-up aborted — you switched chats", currentThread: name });
        return;
      }
      const composer = findComposer();
      if (!composer) return;
      setStatus({ lastAction: "follow-up: sending…", currentThread: name });
      const ok = await typeAndSend(composer, r.text);
      if (ok) {
        rememberSent(r.text); // so we never mistake our follow-up for a buyer message
        delete st.pendingText; delete st.pendingFor; delete st.pendingFp; // delivered
        store[id] = st;
        await setLocal({ followUpState: store });
        cooldowns[id] = Date.now() + COOLDOWN_MS;
        setStatus({ lastAction: `follow-up sent ✓ (${followupsDone + 1}/${maxCount})`, lastReplySent: trunc(r.text, 200), currentThread: name });
        ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, action: "followup", reply: r.text } });
      } else {
        setStatus({ lastError: "follow-up: typed but couldn't send" });
      }
    } catch (e) {
      setStatus({ lastError: "follow-up error: " + e.message });
    }
  }

  /* ---------------- handle ONE conversation ---------------- */
  async function handleThread(anchor) {
    let id = threadId(anchor); // may be ADOPTED below if FB redirects to a canonical id
    const sidebarId = id;
    const name = anchorName(anchor);
    noteOpenThread(id, sidebarId, name); // (v0.21.73) the reader must know this chat's own title — it is not a message
    // Snapshot the sidebar's opinion BEFORE opening: opening marks the chat READ on
    // Facebook (the blue dot dies), so if this visit fails to reply for any reason
    // we must not lose the fact that a buyer was probably waiting.
    // Snippet ONLY — a stuck-lit dot on minimized windows is not evidence of a
    // waiting buyer (this fleet's dots never clear), and dot-triggered suspicious
    // rechecks tripled the latency of every queued-video delivery visit.
    const sidebarSaysBuyer = safe(() => snippetSuggestsBuyerLast(anchor), false);
    cooldowns[id] = Date.now() + COOLDOWN_MS;
    setStatus({ currentThread: name, lastAction: "opening", lastError: null });

    safe(() => anchor.click());
    await sleep(2000);
    if (id && !location.href.includes(id)) {
      // Facebook sometimes opens the chat under a DIFFERENT canonical /t/<id> than
      // the sidebar row's href (group-style threads etc.). The old code declared
      // "couldn't open thread" and abandoned — but the chat WAS open on screen, its
      // unread dot already killed → the "opened but never replied" middle convo.
      // ADOPT the redirected id when the open chat's header matches the row we
      // clicked; abandon only if it's genuinely a different/failed chat.
      const m = safe(() => location.href.match(/\/t\/([^/?#]+)/), null);
      const urlId = m ? m[1] : "";
      // Compare on the FIRST participant's name only. Sidebar rows like
      // "Skylie +1 other · Iphone 13 pro" never appear verbatim in the open chat's
      // header (it renders "Skylie and 1 other" or the member list), which made the
      // strict match fail forever on group threads.
      const label = ((name || "").split("·")[0] || "").split(/\s*(?:\+|&|,| et | and )\s*/i)[0].trim();
      let headerHasName =
        label.length >= 2 &&
        safe(() => (((getMain() && getMain().innerText) || "").toLowerCase().indexOf(label.toLowerCase()) !== -1), false);
      let urlIdNow = urlId;
      if (!(urlIdNow && urlIdNow !== id && headerHasName)) {
        // SLOW-LOAD grace: on laggy Remote Desktop the URL/header can land seconds
        // after the 2s settle — scoring a "failed open" here was how real buyers
        // collected quarantine strikes. One more beat, then re-judge.
        await sleep(4000);
        if (location.href.includes(id)) {
          // it WAS just slow — fall through below as a normal successful open
          urlIdNow = id;
        } else {
          const m2 = safe(() => location.href.match(/\/t\/([^/?#]+)/), null);
          urlIdNow = m2 ? m2[1] : "";
          headerHasName =
            label.length >= 2 &&
            safe(() => (((getMain() && getMain().innerText) || "").toLowerCase().indexOf(label.toLowerCase()) !== -1), false);
        }
      }
      if (urlIdNow === id) {
        // late load — opened fine after all
      } else if (urlIdNow && urlIdNow !== id && headerHasName) {
        console.debug("[SubSell] thread id redirected", id, "->", urlIdNow, "— adopting");
        delete openFails[sidebarId];
        id = urlIdNow; // all state (dedup, caps, videos) now keys on the REAL id
        noteOpenThread(id, sidebarId, name); // (v0.21.73) the title follows the chat to its real id
        adoptedAlias[sidebarId] = id; // bridge sidebar-keyed lookups to the real id
        cooldowns[id] = Date.now() + COOLDOWN_MS; // mirror the entry cooldown
      } else {
        // QUARANTINE repeat offenders: a thread that keeps failing to open must not
        // eat scan cycles while real buyers (the next chats down) sit waiting.
        // ESCALATING parks (30 min → 6 h → 24 h): one diagnostic showed a thread at
        // 60 failed opens because the flat 30-min park barely slowed the retry loop.
        // Lanes 0/1/1.5 now honor this park (see pickTarget), so it actually holds.
        openFails[sidebarId] = { n: openFailCount(sidebarId) + 1, at: Date.now() };
        const nOF = openFails[sidebarId].n;
        if (nOF >= 3) {
          const parkMs = nOF >= 10 ? 24 * 3600 * 1000 : nOF >= 6 ? 6 * 3600 * 1000 : 30 * 60 * 1000;
          cooldowns[sidebarId] = Date.now() + parkMs;
          persistDedup();
          if (nOF === 6) {
            // Never park a possible buyer silently: one Activity row names the chat
            // so the operator can open it by hand on this machine.
            ask({ type: "LOG_EVENT", entry: { thread: name, threadId: sidebarId, buyer: "(system)", action: "video-status", reply: "a chat refuses to open (6+ tries) — open it by hand on this machine: " + (name || sidebarId) } });
          }
          setStatus({ lastError: "thread won't open (" + nOF + "×) — parked " + (parkMs >= 3600000 ? Math.round(parkMs / 3600000) + "h" : "30 min") + ": " + sidebarId });
        } else {
          setStatus({ lastError: "couldn't open thread " + sidebarId });
        }
        return;
      }
    }
    delete openFails[sidebarId]; // opened fine (directly or adopted) — clear the strike count
    refreshThreadLock(sidebarId); // keep our lease alive through the long parts
    const composer = await waitForComposer();
    if (!composer) {
      setStatus({ lastError: "thread didn't load" });
      return;
    }
    await sleep(700); // let the last bubbles settle

    // Wait for the thread's messages to actually render before reading them. On slow
    // loads / Remote Desktop the message list can lag behind the URL change, so a
    // naive read would grab the PREVIOUS chat and reply with the wrong context
    // ("answering the wrong person"). Require two identical reads in a row = settled.
    let turn = buyerSpokeLast();
    let prevSig = turn ? turn.transcript : "(you-last)";
    for (let i = 0; i < 5; i++) {
      await sleep(600);
      const t = buyerSpokeLast();
      const sig = t ? t.transcript : "(you-last)";
      turn = t;
      if (sig === prevSig) break; // stable → safe to act
      prevSig = sig;
    }
    // SIDEBAR-CONFIRMED BUYER TURN (v0.21.34): the open-chat read defaults every
    // inconclusive bubble to "me" (the anti-self-reply law), and on some chats
    // (group-style threads, custom themes, media-heavy tails) that turned a REAL
    // buyer message into "you spoke last" three times → 6h suppression (a
    // diagnostic showed "Charles: How much? · 2h" and "Dreamliner: Le 13 pro ·
    // 12h" sitting unanswered exactly like that). When the sidebar row itself
    // attributes the last message to the buyer BY NAME and that same text is the
    // last bubble in the open chat, that bubble is the buyer's — answer it.
    let rescueHint = null; // the sidebar hint that produced `turn`, if any (the pre-send recheck re-runs it)
    if (!turn && sidebarSaysBuyer) {
      const hint = safe(() => sidebarSnippetBody(anchor), null);
      const confirmed = hint ? buyerSpokeLastConfirmed(hint) : null;
      if (confirmed) {
        turn = confirmed;
        rescueHint = hint;
        setStatus({ lastAction: "buyer message confirmed via sidebar attribution", currentThread: name });
      }
    }
    if (!turn) {
      // SUSPICIOUS READ: the sidebar said a buyer message was waiting, but the open
      // chat reads as "you spoke last". On slow loads (Remote Desktop) the buyer's
      // last bubbles sometimes haven't rendered yet — and since opening already
      // KILLED the unread dot, shelving this chat for 10 minutes = the "opened,
      // then forgotten" bug. Re-check in 2 minutes instead; after 3 straight
      // suspicious reads accept the chat really is idle (stops a permanently
      // buyer-looking snippet — e.g. some group rows — from looping forever).
      if (sidebarSaysBuyer && (suspiciousReads[id] = (suspiciousReads[id] || 0) + 1) < 3) {
        cooldowns[id] = Date.now() + 2 * 60 * 1000;
        // (v0.21.41) a chat that owes a video tail still gets its video pass here
        // (idempotent) — three suspicious reads used to cost it three lane slots for nothing.
        if (videoPending[id] != null || videoPending[sidebarId] != null) {
          await maybeSendVideo(id, name, false, sidebarId);
          if (videoLocked.has(id)) clearVideoPending(sidebarId);
        }
        setStatus({ lastAction: "sidebar showed a buyer message but chat reads you-last — re-checking in 2 min", currentThread: name });
        return;
      }
      clearWaiting(id, sidebarId); // genuinely idle — resolved, off the never-miss ledger
      // Three straight idle reads against a still-lit sidebar nudge: stop the
      // ledger from re-stamping this chat for a while, or lane 0 revisits it
      // every few minutes all day. A NEW buyer message clears through lane 1
      // (unread + buyer snippet) regardless of this suppression.
      if (sidebarSaysBuyer) {
        waitSuppress[id] = Date.now() + 6 * 3600 * 1000;
        waitSuppress[sidebarId] = waitSuppress[id];
      }
      cooldowns[id] = Date.now() + IDLE_COOLDOWN_MS;
      // You spoke last — nothing to reply to. But still: (1) send the demo video if
      // this chat never got one, and (2) consider a smart, capped follow-up if the
      // chat has been quiet long enough. Both are once/limited per chat — no spam.
      // A visit that DELIVERS a queued/deferred set honors demoVideoDelaySec
      // (immediate only on genuinely idle revisits) — "instant burst on open" fix.
      await maybeSendVideo(id, name, videoPending[id] == null && videoPending[sidebarId] == null, sidebarId);
      if (videoLocked.has(id)) clearVideoPending(sidebarId); // terminal → clear sidebar-keyed pending
      await maybeFollowUp(id, name, anchor);
      setStatus({ lastAction: "skip — you spoke last (checked video + follow-up)", currentThread: name });
      return;
    }
    delete suspiciousReads[id]; // got a real buyer turn — reset the misread counter
    if (isOwnEcho(turn.buyerMessage)) {
      // The "last message" is actually OUR OWN (alignment mis-read) — never reply to
      // ourselves. Hard stop against self-reply spam.
      clearWaiting(id, sidebarId);
      cooldowns[id] = Date.now() + IDLE_COOLDOWN_MS;
      // (v0.21.41) same omission as the lastHandled branch had: give the chat its
      // video pass (idempotent) instead of a 10-min cooldown and nothing.
      await maybeSendVideo(id, name, videoPending[id] == null && videoPending[sidebarId] == null, sidebarId);
      if (videoLocked.has(id)) clearVideoPending(sidebarId);
      setStatus({ lastAction: "skip — that last message was ours, not the buyer (video checked)", currentThread: name });
      return;
    }
    // Composite dedupe key (new writes) with backward compat for entries persisted
    // by older builds as the plain buyer text. The composite key lets a buyer who
    // REPEATS the same words later ("ok", "?") get answered again — the plain-text
    // key skipped them forever.
    if (lastHandled[id] === turn.dedupeKey || lastHandled[id] === turn.buyerMessage || (turn.legacyKey && lastHandled[id] === turn.legacyKey)) {
      // (v0.21.73) a key written before the title block left the read: same message,
      // already answered. Re-stamp it in today's form so the match is direct from now on.
      if (lastHandled[id] !== turn.dedupeKey && lastHandled[id] !== turn.buyerMessage) { lastHandled[id] = turn.dedupeKey; persistDedup(); }
      clearWaiting(id, sidebarId); // already answered this exact message
      // Audit fix: chats that keep landing here (our reply mis-read as not-last)
      // previously NEVER reached a video pass — give them one (idempotent).
      await maybeSendVideo(id, name, videoPending[id] == null && videoPending[sidebarId] == null, sidebarId);
      if (videoLocked.has(id)) clearVideoPending(sidebarId); // terminal → clear sidebar-keyed pending
      setStatus({ lastAction: "skip — already replied to this message (video checked)", currentThread: name });
      return;
    }

    // ---- HARD PER-CONVERSATION REPLY CAP (maxRepliesPerConvo) ----
    // Count = TEXT replies the bot has already sent in THIS chat (videos & follow-ups
    // are separate and never counted). Once a chat reaches the cap we go silent for the
    // rest of the conversation — even if the buyer keeps asking more questions. Checked
    // here, before spending a Claude call. cap 0 = unlimited.
    const settings = (await ask({ type: "GET_SETTINGS" })).settings || {};
    const replyCap = Math.max(0, Number(settings.maxRepliesPerConvo) || 0);
    const repliesSoFar = replyCounts[id] || 0;
    if (replyCap > 0 && repliesSoFar >= replyCap) {
      clearWaiting(id, sidebarId); // cap says stay silent — resolved by policy
      cooldowns[id] = Date.now() + IDLE_COOLDOWN_MS;
      // No more text replies — but the demo video is separate ("2 + videos"), so still
      // make sure this chat got its one-time video (idempotent: no-op if already sent).
      await maybeSendVideo(id, name, false, sidebarId);
      if (videoLocked.has(id)) clearVideoPending(sidebarId); // terminal → clear sidebar-keyed pending
      // COURTESY CLOSE at the cap — ZERO API cost. The operator's law is "every
      // message gets an answer"; going silent mid-conversation broke it. The
      // FIRST buyer message past the cap gets ONE canned, settings-built closing
      // line (no Claude call, so the cap still caps the spend); after that,
      // silence. replyCounts moves to cap+1 as the sent-once flag.
      if (repliesSoFar === replyCap && stillOnThread(id)) {
        const composerC = findComposer();
        if (composerC) {
          const closeLine =
            "Passe nous voir au shop quand tu veux — " +
            (settings.businessAddress || "757 Rue Beaubien E, Montréal") + ", " +
            (settings.businessHoursText || "9AM–10PM, 7 days") +
            " 😊 On va bien s'occuper de toi! (Come by anytime — we'll take care of you!)";
          const okC = await typeAndSend(composerC, closeLine);
          if (okC) {
            rememberSent(closeLine);
            lastHandled[id] = turn.dedupeKey;
            replyCounts[id] = replyCap + 1; // courtesy close sent once — never again
            persistDedup();
            ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: trunc(turn.buyerMessage, 120), action: "text", reply: closeLine } });
            setStatus({ lastAction: "cap reached — one-time courtesy close sent (no API cost)", lastReplySent: trunc(closeLine, 120), currentThread: name });
            return;
          }
        }
      }
      if ((settings.convoCapBehavior || "stop") === "notify") {
        setStatus({ lastAction: "needs you — reply cap reached (" + repliesSoFar + "/" + replyCap + "), buyer still messaging", currentThread: name });
      } else {
        setStatus({ lastAction: "skip — reply cap reached (" + repliesSoFar + "/" + replyCap + ") for this chat", currentThread: name });
      }
      return;
    }

    // VIDEOS-FIRST (v0.21.24, operator directive): the demo set goes out the
    // moment a buyer engages — BEFORE the text reply, with no first-video delay.
    // Rationale: the post-reply tail (delay → clips → gaps) was where every
    // timing bug lived; sending on a freshly-opened, settled chat is the most
    // reliable moment there is, and the buyer watching clips while the reply is
    // being written reads perfectly natural. All one-set-per-chat guards live
    // inside maybeSendVideo, so for an already-served chat this returns in
    // milliseconds. Costs nothing: zero extra API calls.
    setStatus({ lastAction: "buyer said: " + trunc(turn.buyerMessage, 80), currentThread: name });

    // Pre-call guard: if the operator already clicked into a different chat during
    // the load/settle window above, the Claude call's result would only be thrown
    // away later — don't pay for it. No state is touched (not marked handled,
    // still on the waiting ledger), so the chat is retried on a later cycle.
    if (!stillOnThread(id)) {
      setStatus({ lastAction: "aborted — you switched chats before asking Claude (will retry)", currentThread: name });
      return;
    }
    // Billed-reply memo: if a previous cycle already PAID for a reply to this exact
    // buyer message + transcript but the send was aborted (chat switch, send
    // failure), replay that text instead of billing an identical call again.
    const memo = pendingReply[id];
    const memoOk = !!(memo && memo.buyerMessage === turn.buyerMessage && memo.transcript === turn.transcript && Date.now() - memo.at < 10 * 60 * 1000);
    if (memo && !memoOk) delete pendingReply[id];

    // PARALLEL PIPELINE (v0.21.28) + STREAMING DELIVERY (v0.21.34):
    // The Claude call is FIRED here (not awaited) so the reply is generated
    // while clip 1 attaches. Then — instead of holding EVERYTHING until the
    // whole set is attached and shipping it with one Enter at the very end (on
    // this fleet's FB build a paste is rejected mid-upload, so that meant ~4
    // minutes of "holding" per chat, with the text answer waiting just as long
    // and every other buyer blocked) — clip 1 is sent the moment its upload
    // finishes, the TEXT reply ships right behind it (still honoring the
    // configured delay, counted from this instant), and the remaining clips
    // stream out one by one, yielding whenever another buyer is waiting.
    // Still exactly one API call per reply.
    const replyPromise = ask({ type: "GET_REPLY_SIMPLE", buyerMessage: turn.buyerMessage, context: turn.transcript, memContext: turn.memTranscript, threadName: name, threadId: id, cachedText: memoOk ? memo.text : undefined });
    const replyClockStart = Date.now();
    const targetDelayMs = (settings.responseDelaySec || 15) * 1000 + rand(0, (settings.jitterSec || 15) * 1000);

    // Ships the text reply exactly once — called by the video engine right after
    // the first clip goes out, or below when there are no clips to send.
    const rs = { done: false };
    const shipReply = async (afterClip) => {
      if (rs.done) return;
      rs.done = true;
      const reply = await replyPromise; // usually already resolved while clip 1 attached
      if (!reply || !reply.ok) {
        setStatus({ lastError: "Claude error: " + (reply && reply.error) });
        return;
      }
      if (reply.skip) {
        if (reply.reason === "empty reply" || reply.memory === "answered" || reply.memory === "echo" || reply.title) {
          // Claude DELIBERATELY chose silence (system/meta message, nothing to answer).
          // Mark handled so the same unanswerable message isn't re-billed every
          // cooldown; a NEW buyer message (different text) still gets handled fresh.
          // (v0.21.71) same for a message the thread memory says another computer
          // already answered, or that was ours to begin with.
          lastHandled[id] = turn.dedupeKey;
          clearWaiting(id, sidebarId);
          persistDedup();
        } else if (reply.memory === "claimed") {
          // (v0.21.71) another computer claimed this message first: its reply lands
          // within its own delay. Look again in 2 min — by then the chat reads
          // "we spoke last", or the memory says answered. Not marked handled: if
          // that computer never delivers, its claim expires and this one answers.
          cooldowns[id] = Date.now() + 2 * 60 * 1000;
          persistDedup();
        }
        setStatus({ lastAction: "skip — " + reply.reason, currentThread: name });
        return;
      }
      if (reply.human) {
        lastHandled[id] = turn.dedupeKey;
        clearWaiting(id, sidebarId); // handed to the human — resolved for the bot
        setStatus({ lastAction: "needs you: " + reply.reason, currentThread: name });
        return; // (the clips keep streaming — videos alone still help the human close)
      }
      if (!reply.text || !reply.text.trim()) {
        setStatus({ lastAction: "skip — empty reply" });
        return;
      }
      // Remember the billed text until it's actually delivered — an abort below used
      // to throw it away and bill a fresh call on the retry.
      if (!memoOk) pendingReply[id] = { buyerMessage: turn.buyerMessage, transcript: turn.transcript, text: reply.text, at: Date.now() };

      // Only the REMAINDER of the configured delay — the clip-1 attach/upload time
      // already counted toward it. Zero extra waiting is ever added on top.
      // (v0.21.71) …plus the TYPING PACE: the time a person needs to type THIS
      // reply (length × Typing WPM, capped by typingPaceMaxSec). Right after a
      // clip went out the pace is the floor — the seller sends the clip, then
      // types — instead of the text landing on the clip's heels.
      const typingMs = typingPaceMs(reply.text, settings);
      const delayMs = Math.max(afterClip ? typingMs : 0, targetDelayMs + typingMs - (Date.now() - replyClockStart));
      if (delayMs > 0) {
        refreshThreadLock(sidebarId); // (v0.21.71) the sleep can approach LOCK_MS with the typing pace on top — stamp before it too
        setStatus({ lastAction: "waiting " + Math.round(delayMs / 1000) + "s before replying" + (typingMs ? " (" + Math.round(typingMs / 1000) + "s of it is typing pace)" : ""), currentThread: name });
        await sleep(delayMs);
      }
      refreshThreadLock(sidebarId); // the delay is the longest window — re-stamp the lease

      // ABORT if the operator navigated to a different chat during the wait — typing
      // now would post this reply into the WRONG conversation. The chat is not marked
      // handled, so it's retried cleanly on a later cycle (the billed reply is
      // already memoized above).
      if (!stillOnThread(id)) {
        setStatus({ lastAction: "aborted — you switched chats during the wait (will retry)", currentThread: name });
        return;
      }
      // (v0.21.71) THREAD MEMORY, fresh, right before typing: during the wait
      // another computer may have delivered its reply to this very message, or
      // claimed it before we did. One bounded read; unavailable = go on as before.
      // After the navigation check (the transcript must be THIS chat's), before the
      // conversation recheck. The 40-bubble read lets it see an older reply to the
      // same words that has scrolled out of the model's 12.
      const pre = await ask({ type: "MEMORY_PRESEND", threadId: id, threadName: name, buyerMessage: turn.buyerMessage, transcript: fullTranscript(40) || turn.memTranscript || turn.transcript });
      if (pre && pre.ok && pre.skip) {
        if (pre.memory === "claimed") {
          cooldowns[id] = Date.now() + 2 * 60 * 1000; // the earlier claim delivers; look again soon (memo kept — replayed free if it never lands)
        } else {
          lastHandled[id] = turn.dedupeKey;
          clearWaiting(id, sidebarId);
          delete pendingReply[id];
        }
        persistDedup();
        setStatus({ lastAction: "skip — " + pre.reason, currentThread: name });
        return;
      }
      // Make sure the chat didn't move on while we waited (buyer sent more) — better
      // to re-read next cycle than answer a stale message. NOT enforced right after
      // a clip went out: the chat's tail is ours by construction then, and a human
      // answers sequentially anyway (a newer buyer message gets its own reply next
      // cycle).
      if (!afterClip) {
        // A sidebar-rescued turn is invisible to the hint-less read — re-run the
        // same rescue. buyerSpokeLast() is tried FIRST so a NEW buyer bubble still
        // aborts, and the rescue still stops at any painted/right-hugging own
        // bubble, so a message WE sent during the wait aborts too.
        const recheck = buyerSpokeLast() || (rescueHint ? buyerSpokeLastConfirmed(rescueHint) : null);
        if (!recheck || recheck.buyerMessage !== turn.buyerMessage) {
          setStatus({ lastAction: "aborted — conversation changed during the wait (will retry)", currentThread: name });
          return;
        }
      }

      // The composer node may have been re-rendered by the attach work — re-find it.
      const composerNow = findComposer() || composer;
      const sent = await typeAndSend(composerNow, reply.text);
      if (!sent) {
        // NO blind re-fire: typeAndSend's false covers ambiguous outcomes (its
        // compose-mismatch guard may have CLEARED the text, or the Enter may have
        // actually taken) — a second Enter here could ship a garbled fragment or a
        // duplicate. The billed reply stays memoized (replayed free next cycle).
        setStatus({ lastError: "typed the reply but couldn't send it (will retry)" });
        return;
      }
      rememberSent(reply.text); // so we never mistake this for a buyer message later
      lastHandled[id] = turn.dedupeKey;
      delete pendingReply[id]; // delivered — the billed-reply memo is no longer needed
      replyCounts[id] = repliesSoFar + 1; // count this text reply toward the per-convo cap
      clearWaiting(id, sidebarId); // ANSWERED — off the never-miss ledger
      cooldowns[id] = Date.now() + COOLDOWN_MS;
      persistDedup(); // survive a content-script reload — don't re-reply the same message (and keep the cap count)
      // (v0.21.71) The Activity row is written HERE, on delivery (it used to be
      // written when the reply was generated, so an aborted send still showed as
      // sent and a replayed one showed twice). This row is also every other
      // computer's memory that this message is answered. Fire-and-forget.
      ask({ type: "LOG_EVENT", entry: { thread: name, threadId: id, buyer: trunc(turn.buyerMessage, 400), action: "text", reply: reply.text } });
      setStatus({
        lastAction: "replied ✓" + (replyCap > 0 ? " (" + replyCounts[id] + "/" + replyCap + ")" : ""),
        lastReplySent: trunc(reply.text, 200),
        currentThread: name,
      });

      // Schedule a follow-up (background handles the timing). Re-armed on every
      // reply, so it only fires after the conversation has gone quiet. Fire-and-forget.
      ask({ type: "BOT_REPLIED", threadId: id });

      // Buyer re-engaged and we replied — restart the smart follow-up clock for this
      // chat (the per-chat cap itself is read live from the conversation tail).
      try {
        const fs = (await getLocal(["followUpState"])).followUpState || {};
        fs[id] = { lastAt: Date.now() };
        await setLocal({ followUpState: fs });
      } catch (e) {
        /* non-fatal */
      }
    };

    // VIDEOS FIRST, streamed: clip 1 → (reply) → clip 2 → clip 3, each sent as
    // soon as it is ready. All one-set-per-chat guards live inside the engine,
    // so for an already-served chat this returns in milliseconds and the reply
    // simply goes out below.
    // RUSH MODE (v0.21.37): when several OTHER buyers are already waiting and the
    // Chrome file API has not proven itself on this machine recently (i.e. an
    // attach would go through the slow synthetic path — minutes per set), the
    // buyer's ANSWER outranks this chat's clips: reply now, queue the set on the
    // pending lane (guaranteed later delivery). A machine with a healthy file
    // API keeps videos-first — its attach costs seconds, not minutes.
    let rush = false;
    // (v0.21.40, operator: "remove the blocks — videos instantly") rush only when
    // the file API is genuinely UNAVAILABLE on this machine right now (denied /
    // parked): then an attach means minutes of synthetic pasting and three other
    // buyers should not wait for it. With the file API usable the streaming
    // engine costs seconds per clip and yields between clips, so it is always
    // videos-first — "unproven recently" no longer counts against it.
    // (v0.21.47) …and whenever this machine's last 2+ sets confirmed NOTHING
    // (attachMiss): the buyer's answer must not wait a minute or two behind an
    // attach that is not taking. Reply now; the set goes to the pending lane
    // (bounded native retries with channel rotation, then the link fallback).
    const attachFailing = (attachMiss.streak || 0) >= 2;
    if (!videoLocked.has(id) && ((buyersWaitingCount(id, sidebarId) >= 3 && !cdpAvailable()) || attachFailing)) {
      // Never queue a chat whose set is already CONFIRMED delivered (persisted
      // mark — videoLocked is in-memory and empty after a reload): the engine
      // exits in ms for it and latches videoLocked.
      const dnR = ((await getLocal(["videoSentThreads"])).videoSentThreads || {})[id];
      const served = !!(dnR && dnR.done && typeof dnR.resumeFrom !== "number");
      rush = !served;
    }
    void rushProbeDue; void cdpRecentlyHealthy; // kept for the diagnostic/health line
    if (rush) {
      const qkR = sidebarId || id;
      if (qkR && videoPending[qkR] == null && videoPending[id] == null) { videoPending[qkR] = Date.now(); persistDedup(); }
      setStatus({ lastAction: attachFailing ? "video attach failing on this machine (" + attachMiss.streak + " sets) — replying first, videos queued" : "rush: " + buyersWaitingCount(id, sidebarId) + " buyers waiting — replying first, videos queued", currentThread: name });
    } else if (!videoLocked.has(id)) {
      refreshThreadLock(sidebarId); // uploads can outlive the cross-tab lease
      await maybeSendVideo(id, name, true, sidebarId, false, { onClipSent: () => shipReply(true) });
      if (videoLocked.has(id)) clearVideoPending(sidebarId); // terminal → clear the sidebar-keyed pending too
    }
    // No clips configured / set already delivered / engine exited before a clip
    // went out — the reply goes now (text-only path keeps the full delay).
    await shipReply(false);
  }

  /* ---------------- main loop ---------------- */
  function onMarketplace() {
    return /messenger\.com/.test(location.host) || /facebook\.com\/(messages|marketplace)/.test(location.href);
  }
  // Facebook sometimes serves its OWN error page ("This page isn't available right
  // now" / "Reload Page") — the conversation list is gone, so the bot is stuck with
  // nothing to scan, and the operator finds that screen the next day. We detect ONLY
  // that explicit error page (this wording never appears on a working Messenger), so
  // self-healing can never fire on a page that's working fine.
  const MP_INBOX = "https://www.messenger.com/marketplace/";
  const RECOVER_COOLDOWN_MS = 4 * 60 * 1000; // never auto-reload more than this often
  let zeroAnchorStreak = 0;
  let lastRecoverAt = 0;
  // Buried-pending rescue pacing: in-memory only; the 6h freshness reload retries muted orphans.
  let lastOrphanScrollAt = 0;
  const orphanRescueTries = {};
  const ORPHAN_RESCUE_MAX = 40; // ~2 full sweeps of a large list, then stop until next page reload
  function onFacebookErrorPage() {
    const t = safe(() => (document.body && document.body.innerText) || "", "");
    if (!t || t.length > 3000) return false; // a real Messenger is huge; the error page is tiny
    return /isn'?t available right now|this page isn'?t available|try reloading this page|reload page|n'?est pas disponible|recharger la page/i.test(t);
  }
  // Pick the next chat to handle, by priority, skipping any already handled this wake.
  // P1 unread (buyer waiting) overrides cooldowns; P2 the sidebar preview looks like
  // the buyer spoke last; P3 fair idle rotation (oldest-seen first).
  // The unread re-open floor is 4 MINUTES: Messenger sometimes leaves a chat's blue
  // dot lit even after we visited (reactions, glitches — see the operator's sidebar,
  // many dots that never clear). With a short floor the bot cycled those same
  // "sticky-dot" chats forever and STARVED everything below — the real "missing
  // conversations". A brand-new unread chat (never opened) still fires instantly;
  // floored dot-chats simply fall through to P2/P3 so rotation always progresses.
  const UNREAD_REOPEN_MS = 4 * 60 * 1000;
  // Anyone waiting longer than this jumps to the FRONT of the queue (oldest first).
  // Fresh buyers get instant service; this lane is the "nobody is ever missed" law.
  const OVERDUE_MS = 5 * 60 * 1000;
  // AGED-VIDEO throttle: at most ONE pending-video visit per interval may preempt
  // LANE 1, and a chat that just got an aged attempt is skipped for an hour so one
  // stuck chat (e.g. clips in 24h fail-pause) can't wedge the lane. In-memory only —
  // a content-script reload restarts the pacing, which fails toward FEWER preemptions.
  // (v0.21.40) queued sets must not sit for hours (a diagnostic showed 21 pending,
  // oldest 19 h): one queued set every 90 s, eligible after 2 min, a failing chat
  // re-tried every 15 min. Lanes 0/1 (overdue / brand-new buyer) still outrank it.
  // (v0.21.41) 15 s spacing (a pending visit itself takes longer — the throttle
  // only ever skipped slots), no age floor (parkTail re-stamps a just-yielded tail
  // fresh, which hid it from the lane for 2 min), 4 min per-chat retry.
  const AGED_VIDEO_EVERY_MS = 15 * 1000;
  const AGED_VIDEO_MIN_AGE_MS = 0;
  // (Note: whenever NO buyer is waiting, LANE 1.5 drains continuously with no
  // pacing at all — these constants only bound the worst case on busy machines.)
  const AGED_VIDEO_RETRY_MS = 4 * 60 * 1000;
  let lastAgedVideoAt = 0;
  const agedVideoTried = {}; // threadId -> last aged-lane attempt
  // Is this chat's video engine in a backoff that would refuse a send instantly?
  // Checks BOTH the sidebar id and its adopted canonical id (group threads redirect
  // on open; the engine records attempts under the ADOPTED id, the lanes look up
  // the SIDEBAR id — without the alias the 20-min/24h backoffs never gated the
  // lanes on this all-group fleet and a failing chat churned every scan).
  const videoAttBlocked = (videoAtt, id, now) => {
    const one = (k) => {
      const att = (videoAtt || {})[k];
      return !!(att && att.failAt && now - att.failAt < backoffFor(att)); // (v0.21.40) short backoff only — no 24h pause
    };
    return one(id) || (adoptedAlias[id] != null && one(adoptedAlias[id]));
  };
  // Is any OTHER buyer waiting for a reply right now? Same evidence lane 0/1 use
  // (overdue ledger, or unread + buyer-attributed snippet). The streaming video
  // engine consults this between clips so a long set never makes a new buyer
  // wait for an old chat's remaining videos.
  // `overdueOnly` counts only lane-0 evidence (on the ledger longer than OVERDUE_MS).
  let lastCapN = 0; // the reply cap as of the last scan (settings are read there)
  function buyersWaitingCount(excludeId, excludeSidebarId, overdueOnly) {
    const now = Date.now();
    let n = 0;
    for (const a of safe(() => conversationAnchors(), [])) {
      const id = threadId(a);
      if (id === excludeId || id === excludeSidebarId || adoptedAlias[id] === excludeId) continue;
      if (openFailCount(id) >= 3 && now <= (cooldowns[id] || 0)) continue; // won't-open park
      if (!safe(() => snippetSuggestsBuyerLast(a), false)) continue;
      // (v0.21.41) mirror lane-0/1 eligibility exactly: a row no lane would serve
      // must not count as "waiting" — on this fleet dots never clear on minimized
      // windows, so capped / suppressed / just-opened rows kept every set yielding
      // after clip 1 and rush mode permanently on.
      if (now - (lastOpened[id] || 0) <= UNREAD_REOPEN_MS) continue;
      if (waitSuppress[id] && waitSuppress[id] > now) continue;
      if (lastCapN > 0 && Math.max(replyCounts[id] || 0, adoptedAlias[id] != null ? (replyCounts[adoptedAlias[id]] || 0) : 0) >= lastCapN) continue;
      const ws = waitingSince[id];
      const overdue = !!(ws && now - ws > OVERDUE_MS);
      if (overdue || (!overdueOnly && safe(() => isUnreadAnchor(a), false))) n++;
    }
    return n;
  }
  function buyersWaitingNow(excludeId, excludeSidebarId) {
    return buyersWaitingCount(excludeId, excludeSidebarId) > 0;
  }
  function pickTarget(anchors, now, exclude, videoAtt) {
    // LANE 0 — OVERDUE (the never-miss guarantee): any chat on the waiting ledger
    // longer than OVERDUE_MS is served BEFORE everything else, oldest first. So the
    // newest buyer gets instant service (lane 1), but a busy stream can only delay
    // an older buyer by ~OVERDUE_MS — never bury them.
    let overdue = null, overdueT = Infinity;
    for (const a of anchors) {
      const id = threadId(a);
      if (exclude.has(id)) continue;
      const ws = waitingSince[id];
      if (!ws || now - ws < OVERDUE_MS) continue;
      if (!safe(() => snippetSuggestsBuyerLast(a), false)) continue; // resolved meanwhile
      if (now - (lastOpened[id] || 0) <= UNREAD_REOPEN_MS) continue;
      // WON'T-OPEN quarantine: lane 0 deliberately ignores cooldowns, which made
      // the 30-min "parked" cooldown on unopenable threads a no-op — one broken
      // thread was retried every ~4 min for hours (a diagnostic showed 60 failed
      // opens). Honor the park ONLY for repeat open-failers; normal chats keep
      // lane 0's cooldown immunity.
      if (openFailCount(id) >= 3 && now <= (cooldowns[id] || 0)) continue;
      if (ws < overdueT) { overdueT = ws; overdue = a; }
    }
    if (overdue) return overdue;

    // LANE 1 — INSTANT, and now ABOVE the aged-video lane (v0.21.30, operator:
    // "new people first — videos + reply the moment they message"): the NEWEST
    // genuinely-waiting buyer (topmost matching row — the sidebar is
    // recency-sorted) is served before any old chat's queued video visit. Their
    // visit delivers everything at once anyway (staged clips + reply in one
    // message), so prioritizing them costs old chats at most one ~1-min slot.
    // Two conditions, not just the dot: unread AND the preview reads like the
    // BUYER's message. A dot with OUR preview ("You: …") is a STALE dot — on
    // minimized windows FB often never clears dots after we reply, and those
    // ghosts were re-opened forever, eating the queue.
    // LANE 0.5 candidate — AGED PENDING VIDEOS (anti-starvation), computed BEFORE
    // lane 1 (v0.21.41 fairness): on busy accounts lane 1 is never empty during
    // business hours, so queued/partial sets were never revisited (a diagnostic
    // showed 21 pending, the oldest for 19 h). Rule: a brand-new buyer still goes
    // first — unless the oldest queued set has itself waited longer than
    // OVERDUE_MS; then that set takes this slot (one ~1-min visit), and lane 1
    // gets the next. Lane 0 (overdue buyers) stays absolute above both.
    let agedPick = null;
    if (now - lastAgedVideoAt > AGED_VIDEO_EVERY_MS) {
      let avT = Infinity;
      for (const a of anchors) {
        const id = threadId(a);
        if (exclude.has(id)) continue;
        const t = videoPending[id];
        if (t == null) continue;
        if (now - (agedVideoTried[id] || 0) < AGED_VIDEO_RETRY_MS) continue; // a stuck chat can't wedge the lane
        if (videoAttBlocked(videoAtt, id, now)) continue; // engine would refuse instantly — don't waste the slot
        if (t < avT) { avT = t; agedPick = a; }
      }
      if (agedPick && now - avT > OVERDUE_MS) {
        lastAgedVideoAt = now;
        agedVideoTried[threadId(agedPick)] = now; // stamped BEFORE the visit (safe direction)
        return agedPick;
      }
    }
    for (const a of anchors) {
      const id = threadId(a);
      if (exclude.has(id)) continue;
      if (!safe(() => isUnreadAnchor(a), false)) continue;
      if (!safe(() => snippetSuggestsBuyerLast(a), false)) continue; // stale dot → not lane 1
      if (now - (lastOpened[id] || 0) <= UNREAD_REOPEN_MS) continue;
      if (openFailCount(id) >= 3 && now <= (cooldowns[id] || 0)) continue; // won't-open park (see lane 0)
      // (v0.21.41) a reply-CAPPED chat is resolved by policy — its lit dot must not
      // take lane 1 every 4 min forever (that alone kept lane 1 non-empty all day).
      if (lastCapN > 0 && Math.max(replyCounts[id] || 0, adoptedAlias[id] != null ? (replyCounts[adoptedAlias[id]] || 0) : 0) >= lastCapN) continue;
      return a; // first match = newest buyer → instant videos + reply
    }

    // LANE 0.5 (fallback position): the oldest queued set was not yet overdue, so
    // lane 1 had its chance above; no brand-new buyer → the queued set goes now.
    if (agedPick) {
      lastAgedVideoAt = now;
      agedVideoTried[threadId(agedPick)] = now; // stamped BEFORE the visit (safe direction)
      return agedPick;
    }

    // LANE 1.5 — PENDING VIDEOS (guaranteed delivery): sets deferred during a busy
    // queue are serviced the moment no fresh buyer needs a reply — BEFORE idle
    // rotation, oldest first. This is what makes deferral a postponement, not a
    // cancellation ("latest version not sending videos at all" = this lane missing).
    {
      let pv = null, pvT = Infinity, evicted = false;
      for (const a of anchors) {
        const id = threadId(a);
        if (exclude.has(id)) continue;
        const t = videoPending[id];
        if (t == null) continue;
        // Stuck >24h → evict from the priority lane. NOT a cancellation: every
        // idle/already-replied/cap visit still runs maybeSendVideo, so the chat
        // gets its set on normal rotation once sending works again.
        // >24h stuck → RE-STAMP to the back of the queue (still lane-visible),
        // never evict: eviction dumped the chat onto slow idle rotation, which on
        // busy machines meant "never". Wedge protection stays via videoAttBlocked.
        if (now - t > 24 * 3600 * 1000) { videoPending[id] = now - (AGED_VIDEO_MIN_AGE_MS + 60000); evicted = true; continue; }
        // Never churn a chat the video engine would refuse instantly — mirrors the
        // 3-fail/24h pause and the retry backoff exits exactly.
        if (videoAttBlocked(videoAtt, id, now)) continue;
        // Won't-open park applies here too — the 15-min cooldown bypass below used
        // to override it, so one unopenable pending chat was retried every scan.
        if (openFailCount(id) >= 3 && now <= (cooldowns[id] || 0)) continue;
        // (v0.21.41) no cooldown gate here: every visit writes a cooldown (90 s or
        // 10 min), which turned a parked tail into a 10-min-per-clip cadence even on
        // an idle machine; failure pacing is videoAttBlocked's job.
        // (v0.21.42) …but never the SAME chat twice within a minute: an exit that
        // re-queues without recording a fail must not become an 8-s loop.
        if (now - (lastOpened[id] || 0) < 60 * 1000) continue;
        if (t < pvT) { pvT = t; pv = a; }
      }
      if (evicted) persistDedup(); // batched: one write per scan max, only on state change
      if (pv) return pv;
    }
    let target = null, bestT = Infinity, bestIdleT = Infinity, idleTarget = null;
    for (const a of anchors) {
      const id = threadId(a);
      if (exclude.has(id)) continue;
      const cd = cooldowns[id] || 0;
      if (now <= cd) continue;
      if (safe(() => snippetSuggestsBuyerLast(a), false)) {
        if (cd < bestT) { bestT = cd; target = a; }
      } else if (cd < bestIdleT) { bestIdleT = cd; idleTarget = a; }
    }
    return target || idleTarget;
  }
  // DEEP-SCAN: Facebook's sidebar is virtualized — only ~20 conversation rows exist
  // in the DOM; anything below the scroll fold is INVISIBLE to the bot. When the tab
  // is minimized (nobody is watching, so moving the scrollbar disturbs no one) and a
  // scan found nothing to do, page the sidebar down one step so deeper conversations
  // get rendered (and picked up by the next scans), then wrap back to the top.
  function sidebarScroller() {
    const a = conversationAnchors()[0];
    if (!a) return null;
    let el = a.parentElement;
    for (let i = 0; i < 15 && el; i++) {
      if (el.scrollHeight > el.clientHeight + 50) return el;
      el = el.parentElement;
    }
    return null;
  }
  function deepScanStep() {
    const sc = sidebarScroller();
    if (!sc) return;
    if (sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 60) {
      sc.scrollTop = 0; // reached the bottom → wrap to top (newest chats stay covered)
      setStatus({ lastAction: "deep-scan: back to newest conversations" });
    } else {
      sc.scrollTop += Math.max(200, Math.floor(sc.clientHeight * 0.8));
      setStatus({ lastAction: "deep-scan: checking older conversations…" });
    }
  }

  async function scan() {
    // Stop instantly if (a) a newer injection took over this tab, or (b) the
    // extension was reloaded and this context is orphaned (chrome.* is dead). Either
    // way, terminate this stale loop so it can't double-scan or spam dead-context
    // errors — the fresh instance (re-injected by the background on update) runs on.
    if ((safe(() => window.__subsellGen, MY_GEN) !== MY_GEN) || !safe(() => chrome.runtime && chrome.runtime.id, null)) {
      if (scanTimer) { clearInterval(scanTimer); scanTimer = null; }
      return;
    }
    // Claim the lock SYNCHRONOUSLY before any await, so two scans (interval +
    // heartbeat) can never both get past here (no check/set gap).
    if (busy) {
      // Watchdog: a hung cycle (stuck await) used to freeze the bot until the page
      // was reloaded. If busy for longer than any legit cycle, force-recover.
      if (busySince && Date.now() - busySince > BUSY_MAX_MS) {
        console.warn("[SubSell] watchdog: scan stuck for >6min — force-recovering");
        setStatus({ lastError: "watchdog: previous cycle hung — recovered automatically" });
        busy = false;
        busySince = 0;
      }
      return;
    }
    // An update is sitting on disk: stop STARTING new chats so the background
    // can restart onto the new version the moment we go idle. The in-flight
    // send (busy above) always finishes untouched. 10-min failsafe: if no
    // restart arrives (files turned out identical), resume normally.
    if (pausedForUpdate) {
      if (Date.now() - pausedForUpdate < 10 * 60 * 1000) {
        setStatus({ lastAction: "paused — installing update…" });
        return;
      }
      pausedForUpdate = 0;
    }
    busy = true;
    busySince = Date.now();
    try {
      refreshPowerFlags(); // (v0.21.53) per-machine power switches (never the shared cloud row)
      await sweepStagedClip("scan"); // (v0.21.48) obligatory send of a clip left staged in the open chat
      const anchors = conversationAnchors();
      const settings = (await ask({ type: "GET_SETTINGS" })).settings || {};
      lastSettings = settings;
      // (v0.21.72) the dashboard's clip list changed → drop this session's "already
      // served" latches before any chat is picked (handleThread consults them
      // before it calls the video engine); the persisted marks + the clip ledger
      // decide again for every chat.
      {
        const sigS = clipListSig(settings);
        if (sigS !== videoLockedSig) { videoLockedSig = sigS; videoLocked.clear(); }
      }

      // CONSTANT VERIFICATION — every scan, every rendered row: any chat whose
      // preview reads like a waiting buyer goes on the never-miss ledger (first-seen
      // timestamp). Entries clear ONLY when the chat is actually resolved, so even a
      // reload, a failed open, or a flood of new buyers can't make one disappear.
      const nowT = Date.now();
      // TTL sweep (ongoing): kill ledger ghosts >24h old BEFORE the stamp loop so a
      // rendered, still-waiting buyer re-stamps in this same pass (no off-ledger gap).
      for (const k of Object.keys(waitingSince)) {
        if (typeof waitingSince[k] !== "number" || nowT - waitingSince[k] > 24 * 3600 * 1000) delete waitingSince[k];
      }
      let unread = 0, waiting = 0, purgedStale = false;
      const capN = Math.max(0, Number(settings.maxRepliesPerConvo) || 0);
      lastCapN = capN;
      for (const a of anchors) {
        if (safe(() => isUnreadAnchor(a), false)) unread++;
        // (v0.21.71) remember Facebook's own "You sent a video." while the row shows it
        if (safe(() => WE_SENT_VIDEO_RE.test(rowText(a)), false)) {
          const vid = threadId(a);
          if (vid && (sidebarVideoSeen[vid] == null || nowT - sidebarVideoSeen[vid] > 30 * 24 * 3600 * 1000)) { sidebarVideoSeen[vid] = nowT; purgedStale = true; }
        }
        if (safe(() => snippetSuggestsBuyerLast(a), false)) {
          waiting++;
          const wid = threadId(a);
          // REPLY-CAPPED chats are resolved BY POLICY — the bot may not answer, so
          // holding them on the never-miss ledger jammed lane 0 (oldest-first) and
          // kept overdueNow true, force-queueing every video. The popup's unread
          // count still shows them; serving them is the operator's call.
          // replyCounts keys on the ADOPTED id for redirected group threads — check
          // through the alias too, or capped group chats (this whole fleet) would
          // keep re-stamping forever.
          const effReplies = Math.max(replyCounts[wid] || 0, adoptedAlias[wid] != null ? (replyCounts[adoptedAlias[wid]] || 0) : 0);
          if (wid && capN > 0 && effReplies >= capN) {
            if (waitingSince[wid] != null) { delete waitingSince[wid]; purgedStale = true; }
          } else if (wid && waitSuppress[wid] && waitSuppress[wid] > nowT) {
            // Chat repeatedly read idle in-chat despite the lit sidebar nudge —
            // keep it OFF the ledger until the suppression lapses (see waitSuppress).
            if (waitingSince[wid] != null) { delete waitingSince[wid]; purgedStale = true; }
          } else if (wid && waitingSince[wid] == null) waitingSince[wid] = nowT;
        } else if (safe(() => (a.innerText || "").split("\n").filter((s) => s.trim()).length >= 2, false)) {
          // Row is FULLY RENDERED (name + snippet) and reads not-buyer-last — the
          // exact condition under which lane 0 refuses to serve it, so its ledger
          // entry is unservable noise. A buyer who writes again flips the snippet
          // and is re-stamped this same loop. Mid-render rows never purge.
          const wid = threadId(a);
          if (wid && waitingSince[wid] != null) { delete waitingSince[wid]; purgedStale = true; }
        }
      }
      if (purgedStale) persistDedup(); // batched: at most one local write per scan, only on change
      setStatus({ marketplaceAnchorCount: anchors.length, unreadCount: unread, waitingCount: waiting, videoQueueCount: Object.keys(videoPending).length, lastAction: settings.enabled ? "scanning" : "off" });
      if (!settings.enabled || !onMarketplace()) return;

      // RESUME-MARK RESCUE: a crash mid-set leaves {done, resumeFrom, resumeTotal}
      // with no pending-queue entry (the lock cleared it), and the tail then waited
      // for an organic revisit that busy machines never make. Queue it explicitly.
      // Marks live under the ADOPTED id for redirected group threads; rendered rows
      // give the sidebar id, so look through the alias too.
      {
        const vtScan = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
        let queuedResume = false;
        for (const a of anchors) {
          const rid = threadId(a);
          if (!rid) continue;
          const adKey = adoptedAlias[rid];
          const mk = vtScan[rid] || (adKey != null ? vtScan[adKey] : null);
          if (!mk) continue;
          // (v0.21.41) a BARE lock (no sent, no resume index) older than the in-flight
          // window is a crash between lock and first attach — queue it so the
          // engine's heal (i) runs on the next visit instead of waiting for rotation.
          const bareStale = mk.via === "lock" && !mk.sent && typeof mk.resumeFrom !== "number" && nowT - (mk.at || 0) > VIDEO_INFLIGHT_MS;
          if (!bareStale) {
            if (typeof mk.resumeFrom !== "number") continue;
            if (typeof mk.resumeTotal === "number" && mk.resumeFrom >= mk.resumeTotal && !mk.unverifiedTail) continue; // nothing left to send
            if (mk.via === "lock" && nowT - (mk.at || 0) < VIDEO_INFLIGHT_MS) continue; // in-flight — leave it alone
          }
          if (videoPending[rid] == null && (adKey == null || videoPending[adKey] == null)) {
            videoPending[rid] = nowT;
            queuedResume = true;
          }
        }
        if (queuedResume) persistDedup();
      }

      // BACKLOG CATCH-UP: while armed (operator pressed "Catch up videos"), queue
      // replied-to chats that have no CONFIRMED video for a video visit. Delivery
      // runs through the normal aged-video lane (paced, reply-safe) and the same
      // chatAlreadyHasOurVideo() guard that prevents duplicates. Self-disarms.
      if (videoCatchUp.armed) {
        if (nowT - (videoCatchUp.at || 0) > 3 * 24 * 3600 * 1000) {
          videoCatchUp = { armed: false, at: 0 }; persistDedup();
        } else {
          const doneMap = (await getLocal(["videoSentThreads"])).videoSentThreads || {};
          let queued = 0;
          for (const a of anchors) {
            if (queued >= 30) break;
            const cid = threadId(a);
            if (!cid || videoPending[cid] != null) continue;
            // NOTE: no dot/unread check here — stuck-lit dots on minimized windows
            // made the old check skip the ENTIRE sidebar (queued 0 forever). The
            // snippet test below already leaves every truly-waiting buyer to the
            // reply lanes; a dotted "You:" row is exactly the backlog to queue.
            if (safe(() => snippetSuggestsBuyerLast(a), false)) continue; // buyer last → not a we-replied chat
            const dm = doneMap[cid];
            if (dm && dm.done) continue; // confirmed sent (real / DOM-seen) — never re-queue
            videoPending[cid] = nowT - (AGED_VIDEO_MIN_AGE_MS + 60000); // immediately aged-eligible
            queued++;
          }
          if (queued > 0) { catchUpDry = 0; persistDedup(); }
          else if (Object.keys(videoPending).length === 0 && (catchUpDry = (catchUpDry || 0) + 1) >= 6) {
            videoCatchUp = { armed: false, at: 0 }; catchUpDry = 0; persistDedup(); // backlog drained
          }
        }
      }

      // AUTO-RECOVER from Facebook's error page ONLY. Guarded so it can never touch a
      // working page: requires 0 conversations AND Facebook's literal error wording AND
      // two scans in a row AND a 4-min cooldown. On that error screen the bot is already
      // stuck doing nothing, so navigating back to the Marketplace inbox is pure upside.
      if (anchors.length === 0) {
        if (onFacebookErrorPage()) {
          zeroAnchorStreak++;
          if (zeroAnchorStreak >= 2 && Date.now() - lastRecoverAt > RECOVER_COOLDOWN_MS) {
            lastRecoverAt = Date.now();
            zeroAnchorStreak = 0;
            setStatus({ lastAction: "Facebook error page — reloading Marketplace to recover", lastError: null });
            safe(() => { location.href = MP_INBOX; });
          }
        } else {
          zeroAnchorStreak = 0;
        }
        return;
      }
      zeroAnchorStreak = 0;

      // NEVER open a chat when a reply is impossible (outside business hours, hourly
      // or daily cap hit). Opening marks the chat READ on Facebook, so the old flow —
      // open → "skip: outside business hours" — silently destroyed every "buyer
      // waiting" signal overnight, and those chats were forgotten by morning. Now the
      // dots survive until the bot is actually allowed to answer.
      const st = await ask({ type: "GET_STATUS" });
      if (st && st.ok) {
        if (st.withinHours === false) {
          setStatus({ lastAction: "paused — outside business hours (chats stay unread until open)" });
          return;
        }
        if (st.hourlyCap && st.hourCount >= st.hourlyCap) {
          setStatus({ lastAction: "paused — hourly cap reached (chats stay unread)" });
          return;
        }
        const dCap = st.fullDailyCap != null ? st.fullDailyCap : st.dailyCap;
        if (dCap && st.dayCount >= dCap) {
          setStatus({ lastAction: "paused — daily cap reached (chats stay unread)" });
          return;
        }
      }

      // Handle ONE chat per scan (the proven, reliable model from v0.16.0). The v0.16.1
      // "burst" — handling several chats per wake when the tab was hidden — caused the
      // bot to go dead while the operator was away (long busy periods on a throttled,
      // minimized tab collided with the watchdog), so it was reverted. Throughput when
      // minimized is best solved by keeping a window un-minimized (scans every 8s).
      // Lane 1.5 needs fail-backoff visibility so it never churns an unsendable chat.
      // Read videoAttempts ONLY when the pending queue is non-empty (local storage,
      // no network; queue is empty in the steady state so this is normally free).
      const vAtt = Object.keys(videoPending).length ? ((await getLocal(["videoAttempts"])).videoAttempts || {}) : {};
      const target = pickTarget(anchors, Date.now(), new Set(), vAtt);
      // BURIED-PENDING RESCUE: a chat owed its video can scroll out of the sidebar's
      // ~20 rendered rows and become unpickable by ANY lane. When minimized and only
      // idle work (or nothing) is on deck, page the virtualized list toward it so it
      // re-renders and the normal lanes can serve it. Buyer-facing picks are never
      // preempted — only discretionary idle rotation gives up its turn.
      if (safe(() => document.visibilityState === "hidden", false)) {
        const nowR = Date.now();
        const idleOnly = !target || (!safe(() => isUnreadAnchor(target), false) && !safe(() => snippetSuggestsBuyerLast(target), false) && videoPending[threadId(target)] == null);
        if (idleOnly && nowR - lastOrphanScrollAt > 30 * 1000) {
          const rendered = new Set(anchors.map((a) => threadId(a)));
          let orphan = null;
          for (const pid of Object.keys(videoPending)) {
            if (nowR - videoPending[pid] < 20 * 60 * 1000) continue;
            if (rendered.has(pid)) continue;
            if ((orphanRescueTries[pid] || 0) >= ORPHAN_RESCUE_MAX) continue;
            orphan = pid;
            break;
          }
          if (orphan) {
            orphanRescueTries[orphan] = (orphanRescueTries[orphan] || 0) + 1;
            lastOrphanScrollAt = nowR;
            setStatus({ lastAction: "deep-scan: paging to a buried pending-video chat…" });
            deepScanStep();
            return;
          }
        }
      }
      if (!target) {
        // Nothing eligible among the RENDERED rows. If minimized, use the free cycle
        // to reveal deeper (virtualized) conversations so none stay invisible forever.
        if (safe(() => document.visibilityState === "hidden", false)) deepScanStep();
        return;
      }
      const tid = threadId(target);
      // Cross-tab lease so a second window in this profile can't process the same chat.
      // NOTE: lastOpened is stamped only AFTER winning the lease — stamping before it
      // meant a lock collision ALSO burned the 4-min unread floor, deferring a hot
      // buyer ~5 minutes. Now a blocked chat is simply retried on the next 8s scan
      // (the lease goes stale in ≤2 min if its holder died in a reload/update).
      if (!(await acquireThreadLock(tid))) {
        setStatus({ lastAction: "waiting — another tab/window holds this chat (auto-retries)", currentThread: anchorName(target) });
        return;
      }
      lastOpened[tid] = Date.now(); // lease won — NOW it counts as an open
      try {
        await handleThread(target);
        // (v0.21.41) a visit that cleared the chat's queue entry (set done, or in
        // flight) releases its aged-lane retry stamp — the stamp is for STUCK chats.
        {
          const tid0 = threadId(target);
          if (tid0 && videoPending[tid0] == null && (adoptedAlias[tid0] == null || videoPending[adoptedAlias[tid0]] == null)) delete agedVideoTried[tid0];
        }
      } finally {
        await releaseThreadLock(tid);
      }
    } catch (e) {
      setStatus({ lastError: "error: " + e.message });
    } finally {
      busy = false;
      busySince = 0;
    }
  }

  // Arm the backlog catch-up: clear only AMBIGUOUS done-marks (old-bug era),
  // KEEPING confirmed sends (`sent` count), DOM-seen marks (via:"dom") and
  // partial-set resume markers (resumeFrom/resumeTotal — clearing those would
  // re-send the already-delivered head clips). Then the scan-loop enqueuer +
  // aged-video lane deliver, each send still passing every duplicate guard.
  async function armVideoCatchUp(extraSet) {
    // Transactional: the one-shot boot flag (extraSet) commits in the SAME write as
    // the cleared map — a failed read/write leaves the flag unset so the next boot
    // retries; a landed write means the arm ran exactly once. Read rejects on error
    // instead of silently defaulting to {} (which would "clear" nothing but still
    // consume the one-shot).
    const st = await new Promise((resolve, reject) => {
      try {
        chrome.storage.local.get(["videoSentThreads", "videoAttempts"], (r) => {
          if (chrome.runtime.lastError || !r) return reject(new Error("catch-up read failed"));
          resolve(r);
        });
      } catch (e) { reject(e); }
    });
    const vt = st.videoSentThreads || {};
    const am = st.videoAttempts || {};
    let cleared = 0;
    for (const k of Object.keys(vt)) {
      const e = vt[k];
      const confirmed = e && e.done && (e.sent || e.via === "dom" || e.via === "cloud" || e.resumeFrom != null || e.resumeTotal != null); // (v0.21.71) a cloud-memory mark is confirmed too
      // A bare via:"lock" younger than the in-flight window is a set being sent
      // RIGHT NOW in some pass — clearing it (and its claim) would let a second
      // full set go out in parallel. Skip; a genuinely orphaned lock ages past
      // the window and is healed/cleared by the normal paths.
      const inFlight = e && e.via === "lock" && Date.now() - (e.at || 0) < VIDEO_INFLIGHT_MS;
      if (e && (e === true || (e.done && !confirmed && !inFlight))) {
        delete vt[k];
        // (v0.21.54) KEEP blindTries. v0.21.52 stopped the pre-send rebuild from
        // dropping it, but the catch-up arm still deleted the whole videoAttempts
        // entry — and the catch-up is exactly what the operator triggers (three boot
        // one-shots plus the popup button) when videos are missing. That reset the
        // bounded retry to 1/2 for every re-queued chat and pushed the link fallback
        // back out of reach, so a machine that cannot attach churned instead of
        // falling through to the link.
        if (am[k] && am[k].blindTries) am[k] = { blindTries: am[k].blindTries }; else delete am[k];
        videoLocked.delete(k);
        cleared++;
      }
    }
    videoCatchUp = { armed: true, at: Date.now() };
    catchUpDry = 0;
    await setLocal(Object.assign({ videoSentThreads: vt, videoAttempts: am, videoCatchUp }, extraSet || {}));
    return cleared;
  }

  /* ---------------- popup / heartbeat messages ---------------- */
  chrome.runtime.onMessage.addListener((msg, _sender, send) => {
    if (msg && msg.type === "TICK_NOW") {
      scan(); // background heartbeat — keeps us going while the tab is in the background
      send({ ok: true });
      return true;
    }
    if (msg && msg.type === "PING") {
      // Health-check from the background. `busy` lets it avoid reloading this tab
      // mid-send; a missing response at all means the script is dead → auto-reload.
      send({ ok: true, url: location.href, anchorCount: conversationAnchors().length, busy });
      return true;
    }
    if (msg && msg.type === "PAUSE_SCANS") {
      // Background has an update on disk — hold off on NEW chats so the restart
      // isn't blocked by nonstop activity. Current send finishes untouched.
      pausedForUpdate = Date.now();
      send({ ok: true, busy });
      return true;
    }
    if (msg && msg.type === "RESUME_SCANS") {
      pausedForUpdate = 0;
      send({ ok: true });
      return true;
    }
    if (msg && msg.type === "DIAG_PROBE") {
      // Popup 🩺 button — READ-ONLY live probe of THIS tab: what the scanner sees
      // in the sidebar right now (per-row unread/buyer verdicts + queue ages) and
      // what the video detectors say about the OPEN chat. Nothing is mutated.
      (async () => {
        try {
          const now = Date.now();
          const ageM = (t) => (typeof t === "number" && t > 0 ? Math.round((now - t) / 60000) + "m" : "-");
          const det = (fn) => { try { return fn() ? "Y" : "n"; } catch (e) { return "err"; } };
          const st = await getLocal(["videoSentThreads", "videoAttempts"]);
          const vt = st.videoSentThreads || {};
          const am = st.videoAttempts || {};
          const anchors = conversationAnchors();
          let overdue = 0;
          for (const a of anchors) {
            const ws = waitingSince[threadId(a)];
            if (ws && now - ws > OVERDUE_MS && snippetSuggestsBuyerLast(a)) overdue++;
          }
          const L = [];
          L.push("TAB " + location.href.replace(/[?#].*$/, ""));
          L.push(
            "state: busy=" + (busy ? "Y(" + ageM(busySince) + ")" : "n") +
            " pausedForUpdate=" + (pausedForUpdate ? "Y(" + ageM(pausedForUpdate) + ")" : "n") +
            " catchUp=" + (videoCatchUp && videoCatchUp.armed ? "ARMED dry=" + catchUpDry : "off") +
            " | mem: waiting=" + Object.keys(waitingSince).length +
            " vidPending=" + Object.keys(videoPending).length +
            " sessionLocked=" + videoLocked.size +
            " cooldowns=" + Object.keys(cooldowns).length
          );
          L.push("sidebar: anchors=" + anchors.length + " overdueNow=" + overdue + " — rows (first 12):");
          anchors.slice(0, 12).forEach((a, i) => {
            const id = threadId(a);
            const lines2 = (safe(() => a.innerText || "", "")).split("\n").map((s) => s.trim()).filter(Boolean);
            const ve = vt[id];
            const ae = am[id];
            L.push(
              " #" + i + " " + (trunc(anchorName(a), 13) || "?") +
              " unread=" + (isUnreadAnchor(a) ? "Y" : "n") +
              " buyerLast=" + (snippetSuggestsBuyerLast(a) ? "Y" : "n") +
              " wait=" + ageM(waitingSince[id]) +
              " vidQ=" + ageM(videoPending[id]) +
              " cool=" + (cooldowns[id] && cooldowns[id] > now ? Math.round((cooldowns[id] - now) / 60000) + "m" : "-") +
              " replies=" + (replyCounts[id] || 0) +
              " vmark=" + (ve
                ? (ve.sent ? "sent" + ve.sent : ve.via || "done") +
                  (typeof ve.resumeFrom === "number" ? "+r" + ve.resumeFrom + "/" + (ve.resumeTotal != null ? ve.resumeTotal : "?") : "")
                : "-") +
              " att=" + (ae && (ae.fails || 0) >= 3 ? "PAUSED-" + (ae.why || "load") : ae && ae.fails ? "f" + ae.fails : "-") +
              (suspiciousReads[id] ? " susp=" + suspiciousReads[id] : "") +
              (waitSuppress[id] && waitSuppress[id] > now ? " SUPP" : "") +
              " \"" + (trunc(lines2.slice(1).join(" "), 48) || "") + "\""
            );
          });
          const m = location.href.match(/\/t\/([^/?#]+)/);
          if (m) {
            const convo = safe(() => readConversation(), []) || [];
            const last = convo.length ? convo[convo.length - 1] : null;
            L.push(
              "open chat: id=…" + m[1].slice(-6) +
              " composer=" + (findComposer() ? "Y" : "NO") +
              " msgs=" + convo.length + " last=" + (last ? last.role : "-") +
              // (v0.21.73) title= the chat's label is known to the reader; dropped= blocks it removed as the chat's own title
              " title=" + (openThreadName() ? "known" : "UNKNOWN") + " dropped=" + (convo.legacy ? convo.legacy.length - convo.length : 0) +
              " | detectors: hardened=" + det(chatAlreadyHasOurVideo) +
              " legacyVideo=" + det(legacyChatVideoDetect) +
              " legacyBadge=" + det(legacyBadgeDetect) +
              " | mark=" + (vt[m[1]] ? JSON.stringify(vt[m[1]]).slice(0, 90) : "-")
            );
          } else {
            L.push("open chat: none");
          }
          try { L.push("doctor: " + await videoDoctor()); } catch (e) { L.push("doctor: error " + ((e && e.message) || e)); }
          send({ ok: true, text: L.join("\n") });
        } catch (e) {
          send({ ok: false, error: String((e && e.message) || e) });
        }
      })();
      return true;
    }
    if (msg && msg.type === "CLEAR_VIDEO_MARK_OPEN_CHAT") {
      // Popup maintenance button: clear the "video already sent" mark for the chat
      // the operator has OPEN and verified by eye. Single-chat, manual-only —
      // refuses when a sent video is actually visible in the conversation.
      (async () => {
        const m = location.href.match(/\/t\/([^/?#]+)/);
        const id = m ? m[1] : null;
        if (!id) return send({ ok: false, error: "no chat open" });
        if (chatAlreadyHasOurVideo()) return send({ ok: false, error: "a sent video is visible in this chat — not clearing" });
        const st = await getLocal(["videoSentThreads", "videoAttempts"]);
        const vt = st.videoSentThreads || {};
        const am = st.videoAttempts || {};
        const had = !!vt[id];
        delete vt[id];
        // (v0.21.71) the operator's eyes outrank every memory for the next 10 min:
        // the engine's cloud stop and the remembered sidebar words both yield to
        // this flag (the live DOM/sidebar checks still apply — see the refusal above).
        am[id] = { manualResend: Date.now() };
        await setLocal({ videoSentThreads: vt, videoAttempts: am });
        // (v0.21.72) …and the clip ledger for this chat: the operator has looked and
        // no video of ours is here, so every clip is due again. Without this the
        // engine would step over every clip ("already held") and send nothing.
        {
          const vc = (await getLocal(["videoClips"])).videoClips || {};
          let chg = false;
          for (const k of [id, adoptedAlias[id]].concat(Object.keys(adoptedAlias).filter((x) => adoptedAlias[x] === id))) {
            if (k && vc[k]) { delete vc[k]; chg = true; }
          }
          if (chg) await setLocal({ videoClips: vc });
        }
        videoLocked.delete(id); // mandatory: the in-memory lock short-circuits before storage
        delete sidebarVideoSeen[id];
        if (adoptedAlias[id] != null) delete sidebarVideoSeen[adoptedAlias[id]];
        for (const k of Object.keys(adoptedAlias)) if (adoptedAlias[k] === id) delete sidebarVideoSeen[k];
        persistDedup();
        send({ ok: true, cleared: had });
      })();
      return true;
    }
    if (msg && msg.type === "SEND_VIDEOS_OPEN_CHAT") {
      // Popup: run the video engine on the OPEN chat right now (all duplicate
      // guards intact — a chat already marked served exits in milliseconds; use
      // "Resend video to OPEN chat" first to clear a mark). Progress shows in the
      // popup's video status line. Refused while a scan visit is in progress.
      (async () => {
        const m = location.href.match(/\/t\/([^/?#]+)/);
        const id = m ? m[1] : null;
        if (!id) return send({ ok: false, error: "no chat open" });
        if (busy) return send({ ok: false, error: "the bot is in the middle of a visit — try again in a minute" });
        send({ ok: true });
        busy = true; busySince = Date.now();
        try {
          const nm = safe(() => (document.title || "").replace(/\s*[|·—-]\s*Messenger.*$/i, "").trim(), "") || id;
          setStatus({ lastAction: "manual: sending demo videos to the open chat…", currentThread: nm });
          await maybeSendVideo(id, nm, true, id);
        } catch (e) {
          setStatus({ lastError: "video error: " + ((e && e.message) || e) });
        } finally {
          busy = false;
          busySince = 0;
        }
      })();
      return true;
    }
    if (msg && msg.type === "CATCH_UP_VIDEOS") {
      // Popup catch-up button (kept for re-runs). Same engine as the automatic
      // boot-time arm — delivery + duplicate-safety are the normal pipeline's.
      (async () => {
        const cleared = await armVideoCatchUp();
        send({ ok: true, cleared });
      })().catch((e) => send({ ok: false, error: String((e && e.message) || e) }));
      return true;
    }
    if (msg && msg.type === "SEND_FOLLOWUP") {
      // Background's follow-up alarm fired. Open the thread and nudge — but ONLY if
      // we still spoke last (if the buyer already replied, the normal loop handles it).
      (async () => {
        if (busy) return send({ ok: false, error: "busy" });
        const anchor = conversationAnchors().find((a) => threadId(a) === msg.threadId);
        if (!anchor) return send({ ok: false, error: "thread not found" });
        busy = true;
        busySince = Date.now();
        if (!(await acquireThreadLock(msg.threadId))) {
          busy = false;
          return send({ ok: false, error: "another tab is handling this chat" });
        }
        try {
          safe(() => anchor.click());
          await sleep(2200);
          const composer = await waitForComposer();
          if (!composer) return send({ ok: false, error: "no composer" });
          await sleep(600);
          if (buyerSpokeLast()) {
            setStatus({ lastAction: "follow-up skipped — buyer already active", currentThread: anchorName(anchor) });
            return send({ ok: true, skipped: true });
          }
          // Enforce the SAME anti-spam cap the smart-follow-up path uses, so the
          // alarm path can't post a 3rd consecutive bot message.
          const tail = botTailCount();
          const settings = (await ask({ type: "GET_SETTINGS" })).settings || {};
          const maxCount = Math.max(0, Number(settings.smartFollowupMaxCount) || 1);
          if (tail === 0 || tail - 1 >= maxCount) {
            setStatus({ lastAction: "follow-up skipped — cap reached", currentThread: anchorName(anchor) });
            return send({ ok: true, skipped: "cap" });
          }
          if (!stillOnThread(msg.threadId)) {
            setStatus({ lastAction: "follow-up aborted — you switched chats", currentThread: anchorName(anchor) });
            return send({ ok: false, error: "user navigated away" });
          }
          const ok = await typeAndSend(composer, msg.text);
          if (ok) {
            rememberSent(msg.text); // never read our own follow-up back as a buyer message
            cooldowns[msg.threadId] = Date.now() + COOLDOWN_MS;
            persistDedup();
          }
          setStatus({ lastAction: ok ? "follow-up sent ✓" : "follow-up failed", currentThread: anchorName(anchor) });
          // (v0.21.71) this path never reached the Activity feed — same row as the smart follow-up
          if (ok) ask({ type: "LOG_EVENT", entry: { thread: anchorName(anchor), threadId: msg.threadId, buyer: msg.kind === "visitconfirm" ? "(visit check)" : "(timed follow-up)", action: "followup", reply: msg.text } });
          send({ ok });
        } catch (e) {
          send({ ok: false, error: e.message });
        } finally {
          await releaseThreadLock(msg.threadId);
          busy = false;
          busySince = 0;
        }
      })();
      return true;
    }
    if (msg && msg.type === "SCAN") {
      // popup "Scan now" — show what we currently see in the list
      const anchors = conversationAnchors();
      send({
        ok: true,
        dump: {
          anchorCount: anchors.length,
          capturedCount: anchors.length,
          fingerprints: anchors.map((a, i) => ({
            index: i,
            name: anchorName(a),
            unread: "",
            signal: "",
            ariaLabel: safe(() => a.getAttribute("aria-label"), ""),
          })),
        },
      });
      return true;
    }
    return false;
  });

  /* ---------------- boot ---------------- */
  log("loaded (simple mode) on", location.href);
  setStatus({ lastAction: "loaded" });
  setTimeout(scan, 2500);
  scanTimer = setInterval(scan, SCAN_MS);
})();
